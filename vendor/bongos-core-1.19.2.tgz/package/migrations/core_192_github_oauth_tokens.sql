-- core_192_github_oauth_tokens.sql — short-lived, encrypted GitHub repo tokens for
-- the onboarding wizard (task 1002099, ADR 0143).
--
-- The wizard (public-landing/create.html) opts into `public_repo` at GitHub sign-in
-- so it can LIST the signed-in user's repos (adopt) and CREATE an empty repo (fresh)
-- — things `read:user` cannot do. That user-to-server GitHub token is held here
-- BRIEFLY: one row per builder, the token encrypted with secret-box (master key in
-- server env only — a DB dump alone decrypts nothing), with a short expires_at (one
-- wizard sitting). It is read back by the repo picker/creator over the next few
-- minutes and deleted on use; getGithubToken lazily sweeps an expired row so the
-- table self-cleans without a cron. ON DELETE CASCADE ties a token to its builder.
--
-- This is the AUTH system's OWN handshake token (not a feature's third-party API
-- key like the art module's Gemini key, ADR 0102), so it lives in core. When
-- secret-box is unconfigured no row is ever written and the wizard falls back to
-- manual repo entry (ADR 0143).
--
-- Idempotent: safe to re-run.

CREATE TABLE IF NOT EXISTS github_oauth_tokens (
  builder_id  bigint PRIMARY KEY REFERENCES builders(id) ON DELETE CASCADE,
  token_enc   text NOT NULL,
  scope       text,
  created_at  timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz NOT NULL
);

-- The read/sweep hot path filters on expiry.
CREATE INDEX IF NOT EXISTS idx_github_oauth_tokens_expires
  ON github_oauth_tokens (expires_at);

INSERT INTO schema_migrations (version) VALUES ('core_192_github_oauth_tokens')
  ON CONFLICT (version) DO NOTHING;
