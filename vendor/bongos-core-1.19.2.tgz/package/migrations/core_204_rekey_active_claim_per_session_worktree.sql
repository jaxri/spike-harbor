-- core_204_rekey_active_claim_per_session_worktree.sql
-- Applied under claim 1002172 (task 1002570 -- parallel worktrees can't claim:
-- migration 180's index still keys on the auth session). Number 204 reserved by
-- the claim. A CORE migration, not a lifecycle_ module one, by rule: it drops
-- an index on the shared pre-module `claims` table, and module migrations must
-- stay additive within their own <key>_ tables (ADR 0083 section Decision #5 -- the
-- fitness gate enforces both).
-- Idempotent on re-run.
--
-- THE PROBLEM. The authoritative app guard (shouldRefuseSessionClaim,
-- modules/lifecycle/routes/claims.js) keys the one-active-claim rule on the
-- WORKING TREE: one auth session may hold several active bound claims as long
-- as each lands in its own worktree (one worktree = one branch = one HEAD; only
-- same-tree claims commingle a ship). Migration 180's backstop index was never
-- updated to match -- keyed on creator_session_id ALONE, it refused at the DB
-- layer the parallel second-worktree claim the app layer had just approved, so
-- the documented worktree-per-task parallel workflow was broken.
--
-- THE FIX. Re-key the partial unique index to
-- (creator_session_id, COALESCE(worktree_name, '')). COALESCE rather than
-- PG15's NULLS NOT DISTINCT, and it is load-bearing: in a plain multi-column
-- unique index NULLs are DISTINCT, so two worktree-less claims (worktree_name
-- NULL -- one shared clone whose single branch genuinely commingles) would BOTH
-- insert and re-open the hole task 1642 closed. Folding NULL to '' keeps the
-- shared-clone case self-colliding on every supported Postgres. (Degenerate
-- corner: a claim named '' collides with the NULL group -- the same "no worktree
-- info, assume one shared clone" answer the app guard gives.)
--
-- The predicate is unchanged from 180: released_at IS NULL is the claims-table
-- "active" convention (there is no status column), and NULL sessions
-- (bind_session=false web claims -- many may coexist, adoptable by any of the
-- builder's CLI sessions) stay excluded.
--
-- The error surface survives the swap: claimUniqueViolationError
-- (modules/lifecycle/db.js, task 1002589) matches the OLD and NEW index names,
-- so a 23505 from either generation renders as session_already_has_bound_claim,
-- never the false ALREADY_CLAIMED.

BEGIN;

-- Step 1 -- heal before CREATE (the migration 174/180 shape): a unique index
-- fails to create if existing rows already violate it, which would block
-- deploy. Under the old session-only index no session can hold two bound
-- active claims at all, so this normally closes nothing -- it only bites on a
-- DB whose old index was dropped by hand. Keep the EARLIEST active bound claim
-- per (session, folded worktree) and close the rest, exactly as 180 did.
WITH ranked AS (
  SELECT c.id,
         ROW_NUMBER() OVER (
           PARTITION BY c.creator_session_id, COALESCE(c.worktree_name, '')
           ORDER BY c.claimed_at, c.id
         ) AS rn
    FROM claims c
   WHERE c.released_at IS NULL
     AND c.creator_session_id IS NOT NULL
)
UPDATE claims c
   SET released_at = now(),
       outcome     = COALESCE(c.outcome, 'abandoned')
  FROM ranked r
 WHERE c.id = r.id
   AND r.rn > 1;

-- Step 2 -- swap the index. The old name goes away entirely rather than staying
-- alongside: keeping it would re-refuse exactly what the guard (and the new
-- index) deliberately allow.
DROP INDEX IF EXISTS uniq_active_claim_per_session;

CREATE UNIQUE INDEX IF NOT EXISTS uniq_active_claim_per_session_worktree
  ON claims (creator_session_id, (COALESCE(worktree_name, '')))
  WHERE released_at IS NULL AND creator_session_id IS NOT NULL;

-- (The index name in claimUniqueViolationError's SESSION_CLAIM_INDEXES set and
-- this file must stay in lockstep -- tests/one_active_claim_per_session.mjs pins
-- both sides.)

COMMIT;
