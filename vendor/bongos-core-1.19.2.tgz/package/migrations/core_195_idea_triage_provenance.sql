-- core_195_idea_triage_provenance.sql — give a triage VERDICT somewhere to
-- record what it decided (task 1002447).
--
-- Triage has three verbs; only two of them had storage. `status` records THAT an
-- idea was discarded or merged, and `promoted_to_task_id` records the task a
-- promotion produced — but nothing recorded WHICH idea a merge folded into, or
-- WHY a discard happened. `promoted_to_task_id` cannot stand in for the merge
-- target: it is `REFERENCES tasks(id)`, so writing an idea id there either trips
-- the FK or silently points at an unrelated task. BOTH callers that documented
-- or performed that write are corrected alongside this migration — the
-- /idea-triage skill doc and the interactive walker `scripts/gds/triage.js`.
-- Without a target, "merge" is just "discard" wearing a different label.
--
-- CORE, not modules/ideas/migrations/, even though the ideas module owns every
-- query against this table: `idea_inbox` is a CORE table, and a module migration
-- may only touch its own <key>_-prefixed objects — `fitness.js`
-- checkModuleMigrationsAdditive hard-fails an `ALTER TABLE idea_inbox` from a
-- module (ADR 0083 §Decision #5). The module's "new ideas migration goes in
-- modules/ideas/migrations/" note applies to objects the module OWNS, and it
-- owns none.
--
-- Two additive, nullable columns. Forward-safe by construction: every existing
-- reader SELECTs an explicit column list, so old code on the new schema neither
-- sees nor needs these (tests/migrations_forward_safe.mjs).

BEGIN;

ALTER TABLE idea_inbox
  ADD COLUMN IF NOT EXISTS merged_into_idea_id bigint REFERENCES idea_inbox(id);

ALTER TABLE idea_inbox
  ADD COLUMN IF NOT EXISTS triage_note text;

-- A target exists IFF the idea is merged. Without this, two ordinary PATCHes
-- build a merge CHAIN: set A's target while leaving A open, then merge C into A
-- — whose status still reads 'open', so a status-based no-chains check waves it
-- through. One direction only (`target IS NULL OR status='merged'`), because
-- every pre-existing merged row has a NULL target and must stay valid.
-- CHECK constraints have no ADD ... IF NOT EXISTS, so guard the add (the
-- migration 042 idiom) and keep the file replay-safe.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conrelid = 'idea_inbox'::regclass
       AND conname = 'idea_inbox_merge_target_needs_merged_status'
  ) THEN
    ALTER TABLE idea_inbox
      ADD CONSTRAINT idea_inbox_merge_target_needs_merged_status
      CHECK (merged_into_idea_id IS NULL OR status = 'merged');
  END IF;
END $$;

INSERT INTO schema_migrations (version) VALUES ('core_195_idea_triage_provenance')
  ON CONFLICT DO NOTHING;

COMMIT;
