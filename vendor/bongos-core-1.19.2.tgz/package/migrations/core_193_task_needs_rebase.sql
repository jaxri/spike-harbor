-- core_193_task_needs_rebase.sql — ADR 0120 part 2: the `needs_rebase` flag.
--
-- A confirmed task whose land the publish-reconciler cannot complete after the
-- normal auto-land grace (its retries + the ADR 0082 generated-file self-heal)
-- is flagged needs_rebase=true. It is a SIGNAL, not a status change: the task
-- stays 'confirmed' (its work is done) — it is simply marked as awaiting *its
-- builder's* rebase. Attribution to the builder who did the work is derived from
-- tasks.shipped_by (confirmTask/applyGrade/decideOverrideRequest all COALESCE it
-- to the claim holder), so no separate owner column is needed.
--
-- The claim gate (core claimTask, ADR 0120 part 3) refuses that builder's NEW
-- claims while any of their tasks is needs_rebase; landing the task (shipTask)
-- or releasing it clears the flag. This is a CORE migration (not a lifecycle
-- module migration) because it ALTERs the core `tasks` table — the module
-- migration namespacing rule forbids a module migration touching non-namespaced
-- core objects (the discord precedent).
--
-- Safe DDL: ADD COLUMN ... NOT NULL DEFAULT <constant> does not rewrite the
-- table on Postgres 11+ (the default is stored in the catalog).

ALTER TABLE tasks ADD COLUMN IF NOT EXISTS needs_rebase boolean NOT NULL DEFAULT false;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS needs_rebase_reason text;
ALTER TABLE tasks ADD COLUMN IF NOT EXISTS needs_rebase_at timestamptz;

-- The claim gate + hall/CLI ask "does builder B own any needs_rebase task?",
-- keyed on shipped_by. Partial index keeps that lookup cheap (only the handful
-- of flagged rows are indexed).
CREATE INDEX IF NOT EXISTS idx_tasks_needs_rebase ON tasks (shipped_by) WHERE needs_rebase;
