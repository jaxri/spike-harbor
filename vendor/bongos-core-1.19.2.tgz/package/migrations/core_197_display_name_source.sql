-- core_197_display_name_source.sql — "your name wins, always" (task 1002568).
--
-- THE DEFECT. `upsertBuilder` (src/bongos/db-kernel.js) runs on EVERY sign-in,
-- not just at account creation, and its ON CONFLICT (github_id) DO UPDATE
-- unconditionally re-set `display_name = EXCLUDED.display_name` — where EXCLUDED
-- carries the GitHub-derived name. So a builder who renamed themselves in hall
-- Settings (PATCH /me/display-name) saw the value save, then silently revert at
-- the next authentication. All four login paths clobber it (pollDeviceFlow,
-- completeWebFlow, completeIdpFlow, completeDeviceExchange).
--
-- THE FIX needs one bit of state the row does not currently carry: WHO last set
-- this name. With it, the upsert keeps seeding + re-syncing GitHub's name for
-- builders who never renamed (a GitHub rename still propagates), and stops
-- overwriting the name of anyone who set their own. See ADR 0156.
--
-- WHY THIS IS A CORE MIGRATION, NOT modules/builder-settings/migrations/. The
-- column sits on the CORE `builders` table and is read by CORE code — the guard
-- lives inside db-kernel.js's upsert, on the auth path. A module migration may
-- only touch its own <key>-namespaced objects (ADR 0083 §Decision #5), and core
-- schema must never depend on whether a module happens to be enabled. Same
-- placement as the other builders-table preference columns (037, 075, 119, 164).
--
-- 'github' is the correct default for every existing row: before this migration
-- there was no durable user-set name — whatever is stored survived the last
-- sign-in, which means it IS the GitHub-derived value. A builder who wants their
-- own name re-saves it once and it sticks from then on.
--
-- Safe DDL: ADD COLUMN ... NOT NULL DEFAULT <constant> does not rewrite the
-- table on Postgres 11+ (the default is stored in the catalog). Forward-safe:
-- every existing reader SELECTs an explicit column list, so old code on the new
-- schema neither sees nor needs this column.
-- Idempotent: safe to re-run.

ALTER TABLE builders
  ADD COLUMN IF NOT EXISTS display_name_source text NOT NULL DEFAULT 'github';

-- Only two values are meaningful, and the upsert guard keys on 'user' exactly —
-- a typo'd third value would silently fall through to "GitHub wins", which is
-- the bug this migration exists to close. CHECK constraints have no
-- ADD ... IF NOT EXISTS, so guard the add (the migration 042 idiom) and keep the
-- file replay-safe.
DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint
     WHERE conrelid = 'builders'::regclass
       AND conname = 'builders_display_name_source_check'
  ) THEN
    ALTER TABLE builders
      ADD CONSTRAINT builders_display_name_source_check
      CHECK (display_name_source IN ('github', 'user'));
  END IF;
END $$;

INSERT INTO schema_migrations (version) VALUES ('core_197_display_name_source')
  ON CONFLICT DO NOTHING;
