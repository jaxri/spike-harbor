-- core_196_session_reward_topup.sql
-- Let a multi-ship session be paid for ALL of its cost, not just its first ship.
--
-- WHY THIS IS A CORE MIGRATION, NOT modules/economy/. credit_log is a CORE table — the
-- economy module owns the queries against it, not the table itself (ADR 0083 §Decision #5;
-- modules/economy/CLAUDE.md "Tables: None owned"). A module migration may only touch its own
-- economy_-namespaced objects, so this shipped as economy_002_* and reddened the fitness gate
-- three ways (destructive DDL + index + alter on a non-namespaced table). The real defect was
-- placement, not DDL: as a module migration these columns only existed when the economy module
-- happened to be ENABLED, which makes core schema depend on module enablement — the exact
-- coupling the rule forbids. Relocated per the core_195 precedent (task 1002447).
--
-- schema_migrations is stem-keyed, so this re-applies once under its new stem. That is safe
-- BECAUSE every statement below is IF [NOT] EXISTS — the re-run is a no-op on any database
-- that already had it as economy_002.
--
-- THE DEFECT. Migration 091 made the cost-plus session reward idempotent with a
-- PARTIAL UNIQUE INDEX on credit_log (session_id) WHERE reason='session.token_reward'
-- — "the hard DB-level backstop against a double payout". That is correct and stays.
-- But it was the ONLY control, so once a session booked its first reward row, every
-- later ship in the same session was a hard no-op. A session's cost keeps growing
-- after its first ship, and that increment had nowhere to land.
--
-- Measured: three tasks shipped from one session, priced $14.30 / $27.76 / $40.32,
-- paid 17 drachmae where the whole session was worth round(40.32 × 1.20) = 48.
-- Roughly 65% of real, shipped, graded work went unrewarded. Multi-ship sessions are
-- normal — one claim at a time, but ship -> new worktree -> claim again.
--
-- THE FIX is watermark accounting: each landed ship books the DIFFERENCE between what
-- the whole session is now worth and what it has already been paid. That needs more
-- than one row per session, so uniqueness moves from (session_id) to
-- (session_id, reward_basis) — still scoped to the same reason.
--
-- WHY A CUMULATIVE BASIS AND NOT THE DELTA. Two concurrent uploads at the SAME cost
-- level must still collide and DO NOTHING. reward_basis is the CUMULATIVE owed total
-- at the moment of the row, so it is monotonic and identical for a racing pair. A bare
-- delta would be wrong: two genuine increments that happened to be equal would
-- collide and one payment would be silently lost.
--
-- Additive and non-destructive. No historical row changes value.

-- (a) The cumulative cost-plus total this session was owed when the row was written.
--     NOT NULL DEFAULT 0 (rather than nullable) so the unique index below has clean
--     semantics: Postgres treats NULLs as DISTINCT in a unique index, so a nullable
--     basis would let two legacy rows share a session_id and would WEAKEN the very
--     backstop 091 added.
--
--     Existing rows therefore land on reward_basis = 0, which is the marker for
--     "booked before top-ups existed". The application refuses to top those up: doing
--     so would be an uncontrolled retroactive payout across every historical session.
--     Reconstructing what past sessions are owed is a deliberate, owner-signed-off
--     backfill, tracked separately.
ALTER TABLE credit_log
  ADD COLUMN IF NOT EXISTS reward_basis integer NOT NULL DEFAULT 0;

-- (b) Swap the uniqueness key. CREATE the replacement BEFORE dropping the original so
--     the double-pay backstop is never absent, not even inside this transaction.
--
--     For legacy rows (all at basis 0) the new index is exactly as strict as the old
--     one — (session_id, 0) is unique per session — so nothing already paid can be
--     paid twice.
CREATE UNIQUE INDEX IF NOT EXISTS uniq_credit_session_token_reward_basis
  ON credit_log (session_id, reward_basis)
  WHERE reason = 'session.token_reward';

DROP INDEX IF EXISTS uniq_credit_session_token_reward;

-- Counter hygiene: as a core migration this consumes core number 196 (next free after
-- core_195), so the core allocator floor advances with it.
