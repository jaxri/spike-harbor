-- core_194_confirmed_backlog_clawback.sql — ADR 0120 part 4: one-time clawback
-- + re-gate of the confirmed backlog that accrued under the OLD pay-on-confirm
-- rule (parts 1-3 moved BOTH the pay and the queue gate to the LAND).
--
-- For every task still at status='confirmed' (verified but NOT yet merged to
-- main) this migration:
--   1. Reverses its task.confirmed per-task credit — a compensating NEGATIVE
--      credit_log row (reason='task.confirmed_reversal') per (task, builder), so
--      the builders.total_credits trigger nets it back to 0. The reward is fully
--      RE-EARNABLE: when the task finally lands, part 1a books a fresh
--      'task.shipped' credit. Achievements already unlocked are LEFT INTACT
--      (reversing gamification is punitive + messy — ADR 0120 §Consequences).
--   2. Flags the task needs_rebase=true (reason 'clawback:confirmed_backlog') so
--      the part-3 claim gate applies the new incentive to the work that stranded
--      under the old rule, rather than grandfathering it.
--
-- Idempotent: a task already carrying a task.confirmed_reversal row is skipped,
-- and needs_rebase is only set where still false — a re-run is a no-op. It runs
-- ONCE per DB (schema_migrations), at the deploy that first carries it; that is
-- WHERE the retroactive sting lands, so it hits real builders (the owner
-- included) only when this version is actually deployed.
--
-- Deliberately NOT reversed: the idea-promotion bonus and the net-negative
-- bonus. The ADR names only the 'task.confirmed' delta; the idea bonus stays
-- with its capturer (it is not double-paid on re-land — maybeAwardIdeaPromotion
-- Bonus guards on the existing 'idea_promotion_bonus' row), and the net-negative
-- bonus derives from grade-time signals that never moved off confirm.
--
-- DML only (no schema change): safe to run inside one transaction.

BEGIN;

-- 1. Compensating reversal of the task.confirmed credit for still-confirmed tasks.
INSERT INTO credit_log (builder_id, task_id, delta, reason, description)
SELECT cl.builder_id,
       cl.task_id,
       -SUM(cl.delta),
       'task.confirmed_reversal',
       'ADR 0120 clawback: reverse premature task.confirmed credit for still-confirmed (unlanded) task ' || cl.task_id
  FROM credit_log cl
  JOIN tasks t ON t.id = cl.task_id
 WHERE t.status = 'confirmed'
   AND cl.reason = 'task.confirmed'
   AND NOT EXISTS (
     SELECT 1 FROM credit_log r
      WHERE r.task_id = cl.task_id
        AND r.builder_id = cl.builder_id
        AND r.reason = 'task.confirmed_reversal'
   )
 GROUP BY cl.builder_id, cl.task_id
HAVING SUM(cl.delta) <> 0;

-- 2. Re-gate: flag every still-confirmed task needs_rebase for its builder
--    (attribution via tasks.shipped_by), so the claim gate (part 3) bites.
UPDATE tasks
   SET needs_rebase = true,
       needs_rebase_reason = 'clawback:confirmed_backlog',
       needs_rebase_at = COALESCE(needs_rebase_at, now()),
       updated_at = now()
 WHERE status = 'confirmed'
   AND needs_rebase = false;

COMMIT;
