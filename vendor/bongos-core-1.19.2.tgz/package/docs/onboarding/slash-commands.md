# Slash commands: which are Claude's, which are this project's

*A reference page. Skim it once, come back when a command surprises you.*

When you type `/` in Claude Code you get one list, but the commands in it come from **two different places** and are maintained by two different people. Claude Code ships some of them; this project ships the rest. They look identical in the menu, which is why a few of them trip people up — see [Easy mix-ups](#easy-mix-ups) at the bottom.

## The 10-second rule

| | **Claude Code's own** | **This project's** |
|---|---|---|
| Who ships it | Anthropic, inside the Claude Code app | This repository |
| Where it lives | Inside the app — nothing in this repo | [`.claude/skills/<name>/`](../../.claude/skills/) |
| What it acts on | Your *session* — context, model, config, account | The *build system* — tasks, claims, ships, ideas |
| Works in any repo? | Yes, everywhere | No — only in a folder that holds this code |
| Authoritative list | Type `/help` | The folder listing linked above |

**The short version:** if it changes your Claude session, it's Claude's. If it changes project state — a task, a claim, a ship — it's ours. If you can run it in an unrelated repo, it's Claude's.

> This is also why the commands "appear by magic" when you clone: they aren't a plugin or a download, they're files in `.claude/skills/` that Claude Code reads when a session **starts** on the folder. Clone mid-session and they won't show up until you start a fresh session — the wrinkle the [primer](primer.md) calls out in step 3.

## This project's commands

Every one of these talks to the build system. They're grouped by when you'd reach for them, not alphabetically.

### The work loop — the ones you'll use every session

| Command | What it does |
|---|---|
| `/builder-start` | List the tasks you can claim right now, filtered for parallel-safety |
| `/builder-claim N` | Lock task N to your session |
| `/builder-ship` | Grade, merge, and deploy your claimed task (credits land here) |
| `/builder-release` | Cancel a claim — the task returns to `ready`, no credits |
| `/builder-stage` | Preview your work-in-progress on your own sandbox before shipping |
| `/builder-end` | Close out the session safely — resolve the claim, seal the log |
| `/status` | Version / criterion progress — "what's left for C8?" |
| `/recall` | Search the docs + project knowledge before re-solving something |

### Your account and your machine

| Command | What it does |
|---|---|
| `/builder-setup` | One-time enrolment — signs you in and registers you |
| `/builder-reauth` | Refresh an expired session |
| `/builder-key` | Check / set your own API key status |
| `/builder-box` | Your dev box control panel — wake, create, check cost |
| `/builder-connect` · `/builder-sync` · `/close-box` | Connect to, re-sync, and tear down that box |
| `/builder-cost` | Log a cost entry against your claim |
| `/builder-backup` | Check or trigger a database backup before risky work |
| `/builder-exit` | Offboard or reactivate a builder *(Archon only)* |

### Triage and planning *(Metic and above)*

| Command | What it does |
|---|---|
| `/idea-triage` | Walk the idea inbox — promote, discard, or merge each |
| `/blocker-review` · `/blocker-solve` | Walk open blockers, or drive one to done |
| `/goal-create` | Plan and create one goal — scope wall, criteria, seed tasks |
| `/goal-review` | Confirm criteria that are flagged met-pending-review |
| `/planning-session` | Scope an upcoming version and seed its task list |
| `/priority-session` | Reweight the inbox from a few plain-speech answers |
| `/merge-mode` | Manual fallback when a confirmed task didn't land |

### Discipline modes

`/dev` (engineering — the default loop), `/paint` (art), `/ideate` (ideation). A claimed task's discipline routes you to one of these.

### Design and art pipeline

`/design-sync` and `/figma-design-sync` round-trip the UI design system. The `/otb-*` family — `otb-tile-generate`, `otb-design-review`, `otb-character-review`, `otb-feedback-capture`, `otb-figma-sync` — is the reference instance's pixel-art pipeline; it's only meaningful on an instance that runs that pipeline.

### Session and meta

| Command | What it does |
|---|---|
| `/session-handoff` | Emit a paste-ready prompt to start a fresh session with |
| `/read-session-export` | Read a past session's `/export` zip |
| `/feedback` | Pull in the latest recorded walkthrough bundle |
| `/new-project` | Zero-to-live runbook for a brand-new instance |
| `/builder-redteam` | File a security / vulnerability report |

## Claude Code's own commands

These work in **any** repository — they have nothing to do with this project. `/help` prints the live, authoritative list for your version; the ones below are simply the ones you'll actually meet.

| Command | What it does |
|---|---|
| `/help` | List every command available right now — **the authoritative list** |
| `/clear` · `/compact` | Wipe or condense the conversation context |
| `/model` · `/config` | Switch model; change app settings |
| `/login` · `/logout` | Sign in to your **Anthropic** account |
| `/init` | Write a `CLAUDE.md` for the current codebase |
| `/cost` · `/usage` · `/context` | Token spend, plan usage, context window |
| `/doctor` | Diagnose the **Claude Code install** |
| `/memory` | Edit Claude's memory files |
| `/mcp` · `/agents` · `/hooks` · `/permissions` | Configure MCP servers, subagents, hooks, tool permissions |
| `/export` · `/resume` · `/rewind` | Save the transcript; resume or roll back a session |
| `/review` | Review a GitHub pull request |
| `/status` | **Claude Code's** session/auth status — see the warning below |

## Easy mix-ups

These are the ones that actually cause confusion.

**`/status` — the genuine collision.** Both sides define it. Claude Code's `/status` shows your session and auth state; this project's shows version and criterion progress. Which one wins depends on your Claude Code version and how it resolves the name. If you get the wrong one, say *"what's left for C8"* in plain English, or run `node scripts/gds/status.js` directly.

**`/login` is Anthropic, not us.** It signs you into your Claude account. To sign into a Cloud Bongos instance, use `bongos login <instance-url>`, or `/builder-setup` for a first-time enrolment.

**`/init` writes a `CLAUDE.md`.** It does *not* scaffold a new instance — that's `bongos init`, wrapped by `/new-project`. Running `/init` in this repo would overwrite the project's own `CLAUDE.md`.

**`/doctor` checks Claude Code.** For the build system's health — your session, toolchain, git plumbing, environment — run `node scripts/gds/doctor.js`.

**`/cost` is Claude's token spend.** To record a project cost against your claim, that's `/builder-cost`.

**`/export` vs `/read-session-export`.** Claude's `/export` *writes* a transcript zip; our `/read-session-export` *reads* one back.

**`/review` reviews a GitHub PR.** The project's review commands are `/goal-review`, `/blocker-review`, and `/idea-triage` — different jobs entirely.

## Two more things worth knowing

**Every command has a plain-English twin.** Each skill lists trigger phrases, so *"what can I work on"* reaches `/builder-start` and *"ship it"* reaches `/builder-ship`. You never have to memorise the slash form.

**Same commands, outside Claude.** The work-loop commands are also a terminal CLI: `bongos start`, `bongos claim N`, `bongos ship`. Same actions, same API — usable from any terminal, a Chromebook, or CI. Run `bongos help` for the verb list.

**Rank gates are real.** Some commands above refuse below a certain rank — that's enforced by the server on every request, not by the presence of the file on your disk. See [`canonical-permissions.md`](../canonical-permissions.md).
