# Recipe — live-updating docs on a STANDALONE instance

**Read before:** standing up / debugging a standalone instance whose `docs/` is empty or stale.
**Decision of record:** [ADR 0147](../adr/<redacted>.md) (builds on [ADR 0110](../adr/<redacted>.md) / [ADR 0108](../adr/<redacted>.md)).

## The mental model — which doc refreshes where

A standalone instance (its own repo + `@bongos/core` vendored in `node_modules`) has several *generated* docs. They do **not** all refresh the same way:

| Doc | Kind | Refreshes | Committed? |
|---|---|---|---|
| `docs/session-log-index.md` | whole-file, instance content | **deploy** (`regen-instance-docs.js`) + `bongos upgrade` + init seed | **gitignored** |
| `docs/api/openapi.json`, `docs/api-reference.md`, `docs/routes-permissions.md` | generated from routes | `bongos init` + `bongos upgrade` | tracked/committed |
| `docs/file-map.md` | hybrid (prose + generated sections) | ship-time | tracked/committed |
| `docs/repo-map.md` | CORE symbol map | shipped with `@bongos/core` (core-scoped) | gitignored |
| onboarding diagrams (`.svg`/`.png`) | rendered | package/CI time (headless browser) | gitignored renders, tracked `.mmd` |

Only `session-log-index.md` is regenerated **on deploy** — it's the one whole-file doc whose content (the instance's own session logs) changes as work ships. Everything else is committed-at-ship, shipped-with-core, or rendered-at-package.

## Wiring a standalone deploy to keep docs live

The one-liner every standalone deploy script must run **after** `git reset --hard origin/main` + migrate:

```bash
node node_modules/@bongos/core/scripts/gds/regen-instance-docs.js
```

Run it with `cwd` = the instance repo root (or set `CLOUDBONGOS_INSTANCE_ROOT=<instance-dir>`). It resolves the instance root, regenerates `docs/session-log-index.md` there, is **best-effort** (always exits 0), and is **LOUD** on failure (`::ERROR::` → journald). A stale nav doc is tolerable; a failed deploy is not (ADR 0110 §2 "accepted staleness").

`provision.js` already runs this on its standalone deploy path, and `bongos init` / `bongos upgrade` run it at standup / on a core bump. You only wire it by hand into a **bespoke** pull-deploy script (e.g. cloudbongos.com's `/home/lars/deploy.sh`).

## `.gitignore` requirement

The instance repo must gitignore the whole-file docs so `git reset --hard` never wipes the regenerated copy and no branch can diff it:

```
docs/session-log-index.md
docs/repo-map.md
```

`provision.js`'s `INSTANCE_GITIGNORE` seeds these for new instances; an older instance (pre-ADR-0147) needs them added by hand.

## Debugging "my instance's docs are empty / stale"

1. **Empty `docs/` (only the 3 API files)?** The nav-doc seed never ran. Run `regen-instance-docs.js` once, and confirm the deploy script calls it (above).
2. **`session-log-index.md` indexes the *core's* sessions, not the instance's?** You're on a core older than the ADR 0147 fix (`gen-session-index.js` hardcoded the core root). `bongos upgrade` to a fixed core.
3. **The file keeps disappearing after deploy?** It isn't gitignored — `git reset --hard` wipes it. Add the `.gitignore` lines above.
4. **`::ERROR:: regen-instance-docs` in journald?** A generator threw — the deploy still succeeded, but the doc is stale. Check the generator output; the instance must have `docs/session-logs/` and a resolvable instance root.
