# Work on a task from your dev box

> Your dev box is **task-scoped**: claim a task and the box pulls **only the code
> that task needs** — the module(s) its work touches, on top of a small base
> instance — never the whole repo. Your GitHub token never leaves the server; the
> box fetches its slice through the control plane. See
> [ADR 0148](../adr/<redacted>.md) (the scope model) and
> [ADR 0150](../adr/<redacted>.md) (how the box
> comes up).

## TL;DR

In your dev box's terminal:

```bash
/builder-start          # see what you can claim
/builder-claim <N>      # claim task N (locks it to your session)
/builder-sync           # pull task N's code onto the box now (re-scopes in place)
# …work in /workspace…
/builder-ship           # smoke + review, then land + deploy — awards credits
```

That's the whole loop. `/builder-sync` is the new step: it materializes the claimed
task's code within seconds instead of waiting for the box's ~10-minute refresh.

## The model — what's on your box

A task-scoped box carries two layers:

1. **The base instance** — always present, whatever you've claimed: the methodology
   (`CLAUDE.md`, `.claude/`), the build tooling (`scripts/`, `src/bongos/`),
   `docs/`, `infra/`, and the **test suite** (`tests/`). Enough for Claude to hold
   context and run the `/builder-*` CLI, and to run your module's tests.
2. **Your claimed task's code** — the module directories the task's goal scopes
   (`goals.scope_modules` → globs, [ADR 0086](../adr/<redacted>.md)). Claim a `dev-box` task → you get
   `modules/dev-box/`; claim a `game` task → you get the game world too. Nothing
   else.

What you do **not** get: other builders' modules, the product/game runtime (unless
your task is game-scoped), and — the point — **no GitHub credential on the box**.
The box asks the control plane (`GET /box/source-access`) for its slice on each
fetch; the server holds the token and returns a scoped, cone-mode sparse-checkout
spec. Lose the claim or a rank, and the next fetch is cut off at the server.

## Step by step

### 1. Connect to your box

If you haven't yet, run **`/builder-connect`** (or follow the
[dev-box lifecycle recipe](builder-box-lifecycle.md)) to raise and connect to your
box, then **`/builder-setup`** once on the box to sign the GDS CLI in. The browser
terminal drops you into `/workspace` — the one working folder.

> **`bongos shell` / `bongos code` re-scope on connect (BV1.R101).** Connecting with
> either verb runs the sync for you first, so you land in `/workspace` already scoped
> to your active claim — no manual `/builder-sync` needed just to arrive. (The browser
> terminal drops you straight into `/workspace`; run `/builder-sync` there if you
> claimed or switched since your last sync.)

### 2. See what you can claim — `/builder-start`

Lists the tasks that are `ready` and parallel-safe against everyone else's active
claims. Pick one.

### 3. Claim it — `/builder-claim <N>`

Locks task N to your session. **This is what drives your box's scope:** source
access is computed from your **active claim** — its task → goal → `scope_modules`.

### 4. Pull the code now — `/builder-sync`

Re-runs the box's source-fetch immediately, so `/workspace` re-scopes to task N's
modules within seconds. (A ~10-minute cron does this on its own as a backstop — you
just don't want to wait for it.) Off a box there's nothing to sync — your source is
your local checkout — and the command tells you so.

### 5. Work — in `/workspace`

`/workspace` now holds the base instance **plus** task N's module code. One folder:
when you switch tasks it **re-scopes in place**, so there are no per-task folders to
manage.

### 6. Ship — `/builder-ship`

Runs the smoke tests and the review gate, then lands + deploys and awards credits.

## Switching tasks

One box, one working folder, one active claim at a time (the server enforces
one-claim-per-session). To move to a different task:

1. `/builder-ship` (or `/builder-release`) the current claim.
2. `/builder-claim <M>` the new one.
3. `/builder-sync` — the box re-scopes to task M in place.

## Notes + gotchas

- **`tests/` is always in the base** — so a module's tests run on the box (they
  live in the top-level `tests/`, not inside `modules/<key>/`).
- **Idle boxes rest.** A box with no activity is reclaimed after ~10–15 min; the
  next connect re-provisions a fresh one and re-fetches your scope. **Uncommitted
  work on a reaped box is lost** — ship or commit before you step away.
- **`/builder-sync` is idempotent** — safe to re-run; it just does, on demand, what
  the cron does on its schedule.
- **A fresh box comes up with the base already cloned.** If a box ever comes up
  *bare* (no code, no terminal), that's the packaging bug
  [ADR 0150](../adr/<redacted>.md) fixed on the
  control plane — flag it rather than working around it.
