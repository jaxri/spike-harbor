# Recipe — the core release pipeline: how a change to Cloud Bongos reaches a live instance

> **The map.** Three sibling recipes each cover one leg — [packaging-the-core](packaging-the-core.md) (build the artifact), [private-npm-distribution](private-npm-distribution.md) (publish it), [upgrading-the-core](upgrading-the-core.md) (consume it). This file is the thing that connects them, and it exists to state one fact loudly:
>
> ## **Merging to `main` ships nothing.**
>
> A change that has landed on `main` is running on **zero** instances. It reaches users only after someone bumps `CORE_VERSION`, cuts an artifact, and moves an instance's pin. Those are three separate acts by design ([ADR 0137](../adr/<redacted>.md)) — and every layer around them reports success in the meantime.

## Why this file exists

Between 2026-07-24 and 2026-08-03, **93 work commits (171 counting merges) — including the entire governance permission system — sat on `main` unreleased for ten days** while the live platform served the previous version. Nothing was broken. `/builder-ship` printed success, the publish-reconciler flipped `confirmed → shipped`, credits paid out. Every signal a builder could see said "delivered"; nothing compared live against `main` (blocker 1000097, task [1002521](https://example.com/builders#/task/1002521)).

A second failure followed from the same gap: a builder filed a careful, well-evidenced "prod has been serving stale code for days" report whose central measurement was taken against **the wrong instance**, and which prescribed the npm `--registry` upgrade path for an instance that pins a **vendored tarball** — where it would have moved nothing at all.

Both were documentation failures, not code failures. This is the missing document.

---

## The three gates

A change crosses three independent gates. **None of them implies the next**, and each has its own actor, action, and proof.

| # | Gate | What it means | Who | Proof it happened |
|---|---|---|---|---|
| **0** | **Included** | your change is inside the publishable subtree at all | the allowlist | `isPublishable('<path>')` → `true` |
| **1** | **Landed** | the commit is on core `main` | any builder, via `/builder-ship` | task status `shipped` |
| **2** | **Released** | a `CORE_VERSION` exists that *contains* the commit, and an artifact was cut from it | a builder bumps + packages; **the owner publishes** | the version is published / a `.tgz` exists |
| **3** | **Deployed** | a specific instance moved its pin to that version | per instance | that instance's `/version` reports the new `coreVersion` |

The GDS vocabulary collides with gate 1 in a way worth naming: **task status `shipped` means "merged to `main`"** — it does not mean released, and it does not mean live. `ship.js` says so in its own comment and, since task 1002521, prints a divergence warning at the end of every ship.

---

## Gate 0 — does your change ship at all?

The core is not "this repo." It is exactly the subtree [`isPublishable()`](../../scripts/gds/publish-manifest.js) selects ([ADR 0098](../adr/<redacted>.md)) — a **default-deny, two-layer** gate:

```
isPublishable(p)  ==  matchesDeny(p) ? false : matchesAllow(p)
```

A path publishes only if it falls in `PUBLISH_ALLOWLIST` **and** escapes `PUBLISH_DENYLIST`. A new, unclassified top-level surface therefore never leaks by omission — it is simply not published.

**A change under a denied path reaches no instance at any version.** The four denial rationales:

| Rationale | Examples |
|---|---|
| **Topology** — prod infra, deploy machinery, CI, local gate hooks | `infra/`, `scripts/deploy/`, `.github/`, `.claude/hooks/` |
| **Read-sensitive docs** — the security/audit corpus | `docs/security/`, `docs/audits/` |
| **Content / copyright** — the instance's product layer and all art | `modules/game/`, `modules/art-pipeline/`, `public/`, `brand/` |
| **Host-module tests** — tests that statically import an excluded module | see the list in `publish-manifest.js` |

Note the deliberate non-exclusion: the rank / trust-boundary / ship-grade machinery **is published** — it is the open-source methodology ([ADR 0065 §4](../adr/<redacted>.md)). Only the *topology* subset of the protected surfaces is held back.

Check a path before you assume:

```bash
node -e "console.log(require('./scripts/gds/publish-manifest').isPublishable('docs/recipes/core-release-pipeline.md'))"
```

## Gate 1 — land it on `main`

The ordinary claim→ship loop: `/builder-claim N` → build → `/builder-ship`. That chains `completed` → `confirmed` → `shipped`, and credits land at `shipped` ([ADR 0120](../adr/<redacted>.md)).

Landing is CI-gated (tasks 1002610/1002611/1002619, ADR 0159): every PR runs the **`unit`** check — the DB-free suite plus the fitness gates, via `npm test` — and branch protection **requires** it, so a red suite blocks the merge. PRs touching the hard-floor safety surfaces ([`CODEOWNERS`](../../CODEOWNERS)) additionally need the owner's review. The owner kill-switch is `node scripts/gds/gating.js on|off|status` — reversible by construction, snapshot-restored.

**Stop here and nothing happens to any user.** This is the gate that feels like the finish line and is not.

## Gate 2 — cut a release

Three steps. The first two are ordinary claimed work; only the publish (2c) is owner-gated — and 2c is skipped entirely for a vendored-tarball instance.

### 2a. Bump `CORE_VERSION` — the step with no automation behind it

`CORE_VERSION` lives in [`src/module-api.js`](../../src/module-api.js) and is bumped **by hand, inside a claimed task**, with a changelog line in the same file. It is never auto-bumped: the version's provenance stays in git history + changelog ([ADR 0137](../adr/<redacted>.md) §2).

Semver here is not decoration — it decides **who receives the change automatically** ([ADR 0136](../adr/<redacted>.md)):

| Bump | Reaches `patch` subscribers (the default) | Reaches `minor` subscribers |
|---|---|---|
| **patch** — a fix; the doorway surface is byte-identical | ✅ | ✅ |
| **minor** — an added export / additive surface | ❌ **invisible to them** | ✅ |
| **major** — never automatic for anyone | ❌ | ❌ |

The practical trap: a **MINOR is silently withheld from every patch-only instance**, which is the default channel. If a fix must reach the fleet, it belongs behind a *patch* bump — so an additive export shipped alongside a needed fix will strand that fix. The changelog convention is to justify the level explicitly ("the doorway surface is byte-identical to X, so despite the volume this is → PATCH").

**A bump is mandatory even for a one-file fix.** `bongos upgrade` refuses an equal version, and npm rejects a duplicate — a natural guard, and the reason "carrier bumps" exist to sweep up commits that landed with no bump behind them.

### 2b. Build the artifact

```bash
node scripts/gds/package-core.js --ref main            # → dist/bongos-core-<v>.tgz + .manifest.json
node scripts/gds/package-core.js --ref main --self-verify
```

`package-core` archives the **committed** tree at `--ref`, never your working tree, and stamps the version from `CORE_VERSION` *at that ref*. Full mechanics — the fail-closed no-leak gate, the `tree_sha256` integrity pin, the pruned lockfile — in [packaging-the-core](packaging-the-core.md).

> ⚠️ **Packaging a mid-flight `main` produces a stale version number.** If `CORE_VERSION` at your ref is still the previous value, your tarball is stamped with a version the fleet may already have. `bongos upgrade` refuses only the **equal** case (`already on <v>`, and `--force` bypasses even that) — it has **no downgrade guard**, so a target *below* what is installed proceeds and silently installs older code. Confirm the bump is actually in your ref before packaging.

### 2c. Publish — only for the registry path

Publishing to npm is a **manual, owner-gated step**; merges do not auto-publish and **no npm write token exists in CI or the repo** ([ADR 0137](../adr/<redacted>.md) §3).

```bash
node scripts/gds/package-core.js --publish          # DRY-RUN — runs the no-leak gate, previews
node scripts/gds/package-core.js --publish --live   # permanent
```

**`--publish` is not needed for a vendored-tarball instance** — see gate 3. Chasing an npm publish to move a `file:`-pinned instance is a documented dead end.

## Gate 3 — move the instance's pin

Each instance decides, independently, when to take a release. **Which mechanism it uses is a per-instance fact you must establish before prescribing anything** — read its `package.json`:

| Pin in `package.json` | Path | How it updates |
|---|---|---|
| `"@bongos/core": "file:vendor/bongos-core-<v>.tgz"` | **vendored tarball** | ship the `.tgz` to the instance and run `bongos upgrade --from <tgz>`; npm's published version is irrelevant |
| `"@bongos/core": "^<v>"` | **npm registry** | `bongos upgrade --to <v> --registry`; requires the version to be published and a token to read it |

The mechanics of the bump itself — pre-flight, pin-verify, migrate, `.claude/` materialize, restart, the mandatory health check, and auto-rollback — are in [upgrading-the-core](upgrading-the-core.md). Two portable traps that bite hardest here:

- **`PGDATABASE` is load-bearing.** `migrate.sh` has a default; on a co-tenant host that default is *someone else's database*. Always set `PGDATABASE=<instance-db>` explicitly or you migrate the wrong DB (the usual outcome is a clean auto-rollback, which then reads as "the upgrade failed").
- **Never hand-edit `package-lock.json`'s `@bongos/core` entry.** Editing `version` + `resolved` while leaving `integrity` at the old tarball's hash makes `npm ci` resolve the *old* content from the content-addressable cache — the deploy reports healthy and runs old code. Run `npm install file:vendor/bongos-core-<v>.tgz` instead, and verify after: `node -e "console.log(require('./node_modules/@bongos/core/package.json').version)"`.

Also: an instance can have **more than one plane to update** (e.g. a web instance plus a control plane that resolves its tooling from its own vendored core). Updating one does not update the other.

---

## Detecting divergence

[`scripts/gds/deploy-divergence.js`](../../scripts/gds/deploy-divergence.js) is the comparison that was missing during the ten-day incident. It runs **warn-only at the end of every ship** and can be run by hand any time:

```bash
node scripts/gds/deploy-divergence.js --url https://<instance-host>
```

It reports the two gaps **separately**, because they have different fixes:

- **UNRELEASED** — commits on `main` past the last `CORE_VERSION` bump. *No instance can take these at any pin* — no version contains them. Fix: bump + land (gate 2a).
- **UNDEPLOYED** — the live instance's `coreVersion` is behind `main`'s. A release exists; this instance has not moved its pin. Fix: gate 3.

Exit codes: `0` aligned, `1` diverged, `2` undetermined.

> ### ⚠️ Do not trust its numbers without checking the anchor
>
> The tool has a **known anchor defect** — reproduced live on 2026-08-08, where it named `1.18.19` as the last bump while printing `origin/main 1.19.0` two lines above, then counted 70 UNRELEASED commits from that wrong anchor.
>
> The mechanism is one compound failure. It locates the bump with `git log <ref> -1 -G"^const CORE_VERSION = "`. `git log` shows no diff for merge commits, so `-G` **cannot match the merge** that lands a bump on `main` — the only candidate is the original commit on the branch, carrying that branch's earlier **commit date**. `-1` then picks the newest *by date*, so a bump authored earlier on a long-lived branch loses to a later-authored one, even when the earlier one is the higher version. Every count downstream inherits the wrong anchor.
>
> Separately and by design, it measures from the last *bump commit*, not from what was actually **packaged** — so work landing between the bump and `package-core` reads as UNRELEASED even though the tarball contains it. Comparing against the `core-v*` release tag would be more accurate.
>
> Treat a divergence warning as **"look closer"**, never as a precise commit count. The direction is reliable; the arithmetic is not.

**Before acting on any "prod is stale" report, establish which instance was measured.** `curl` the `/version` endpoint of each candidate host yourself. Instances that serve different products are pinned at different versions *correctly* — a game-only instance needs no platform release. A report that names the wrong host will read as authoritative regardless of how carefully it was written.

---

## Who can do what

| Act | Gate | Who |
|---|---|---|
| Land a change on `main` | 1 | any builder holding a claim, behind the required `unit` check (protected paths are Metic+; hard-floor paths need owner review per [`CODEOWNERS`](../../CODEOWNERS); [canonical-permissions](../canonical-permissions.md)) |
| Bump `CORE_VERSION` | 2a | a builder, inside a claimed task |
| Build the artifact | 2b | any builder — `package-core` is tokenless and network-free |
| Publish to npm | 2c | **owner only** — needs `npm login` + 2FA; no write token exists anywhere else |
| Move an instance's pin | 3 | whoever operates that instance |

Automating gate 2c (a tag-triggered CI publish) is deliberately deferred until a real fleet makes the manual step a bottleneck — see [ADR 0137](../adr/<redacted>.md) "When to revisit".

## Where to go next

| You want to… | Read |
|---|---|
| build / verify / inspect the artifact | [packaging-the-core](packaging-the-core.md) |
| publish it, or set up private npm access | [private-npm-distribution](private-npm-distribution.md) |
| move an instance from N → N+1, or subscribe it to updates | [upgrading-the-core](upgrading-the-core.md) |
| know *why* publishing is manual | [ADR 0137](../adr/<redacted>.md) |
| know *what* an unattended upgrade is allowed to take | [ADR 0136](../adr/<redacted>.md) |
| know what counts as "the core" | [ADR 0098](../adr/<redacted>.md) · [ADR 0103](../adr/<redacted>.md) |
