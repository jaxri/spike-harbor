# Running a goal as parallel worktree waves

How to take a goal with ~20 tasks and ship it with several agents building at once, one worktree per claim.

Written from the 2026-07-30 session that shipped 14 tasks off goal 1000030 (Governance — configurable roles & permissions). **This records what actually worked, which differed from the plan we started with.** The differences are the point.

---

## The one-paragraph version

Dependencies tell you what must **ship** first. They tell you nothing about what can be **edited** at the same time. Work out the file-conflict graph yourself, run the disjoint set in parallel worktrees, and serialise anything that touches the same file. Claim the parallel set with `POST /claims/batch` (`claim.js` can only hold one claim per machine). Expect the plan's own dependency edges to be wrong somewhere, and expect one shared doc file to become the merge-conflict tax.

---

## 1. Read the DAG, then don't trust it

Start by pulling the real graph — status, `dependencies[]`, `dependents[]`, and `requires_rank` for every task on the goal:

```
node scripts/gds/api.js GET "/api/gds/tasks?goal_id=<goal>&limit=100"
node scripts/gds/api.js GET "/api/gds/tasks/<id>"     # includes dependencies + dependents
```

> **Gotcha (cost us ~40 minutes).** The generated API client wraps responses as `{status, ok, data:{...}}`. Reading `res.tasks` gives `undefined` and every dependency array silently looks empty — which reads as "this goal has no dependencies at all". Unwrap `.data` first. An empty dependency graph should make you suspicious, not relieved.

Then **audit the edges for direction errors before scheduling anything**. Two of goal 1000030's edges were backwards, and each cost a full task cycle:

- **The checker recorded as depending on the thing it checks.** R109 (teach the CI fitness gate to understand the new gate form) was recorded as depending on R104 (migrate the gates). But migrating gates without teaching the checker made every migrated route classify as `any-builder` — a silent downgrade that tripped exact-rank pins. R104 could not pass its grade until R109 shipped, and R109 could not be claimed until R104 shipped. **Deadlock.** Fix: `PUT /tasks/:id/dependencies` to reverse it. The heuristic — *if task B validates task A's output, B is usually A's prerequisite, not its dependent.*
- **A migration racing ahead of a missing writer.** The plan migrated ~80 authority gates onto a new resolver, but nothing ever wrote the table the resolver reads outside a one-shot backfill. Any account created or re-ranked afterwards would have resolved to zero permissions — and a demoted account would have kept its old powers. Found only because one task's agent reported it instead of coding around it. Fix: file the missing work as a task, then `PUT /tasks/:id/dependencies` to gate the migration tasks behind it.

**Do not let a wrong edge stand because fixing it feels like process work.** A backwards edge deadlocks a whole chain, and the deadlock presents as an unexplained grade failure several hours later.

---

## 2. Build the file-conflict graph — this is the real gate

`dependencies[]` is a *ship* ordering. Parallel safety is a *file* question, and `touches[]` is advisory and frequently empty. So derive it yourself: read each task's description and predict the files it will edit.

Then group:

- **Parallel-safe** — no file overlap with anything else in the wave.
- **Serialised** — two tasks edit the same file, so they run back-to-back regardless of what the DAG says.

Worked example from goal 1000030:

| Wave | Ran in parallel | Why the rest was held |
|---|---|---|
| 0 | resolver + kernel port ‖ config loader | disjoint: new module files vs `config/*.json` |
| A | the gate primitive ‖ the protected-surface registry | both touched different core files; three others all edited `catalog.js`+`resolver.js` and were serialised behind them |
| B | a proof test ‖ the core-route migration | test files collide with nothing |
| C | module-route migration alone | it owns every `modules/*/routes/*.js`, so nothing else in that tree could move |

**Heuristics that held up:**
- A task whose whole output is a new test file is parallel-safe with everything. Schedule these freely.
- A task that "migrates all X" owns its entire tree for the duration. Run the narrow, specific tasks in that tree **first**, then let the sweep absorb the remainder and rebase onto them. Running the sweep first forces every narrow task to conflict with it.
- Two tasks extending the same registry/catalog file always serialise, even when their subject matter is unrelated.

---

## 3. Claiming a parallel set

Concurrent bound claims from one machine **used to be impossible**: the app-layer guard permits one claim per *worktree*, but migration 180's `uniq_active_claim_per_session` was keyed on `creator_session_id` alone — worktree-blind — and the stricter of the two won, so the second `claim.js` failed. Worse, it failed with a misleading message: `claimTask` mapped any Postgres `23505` to `ALREADY_CLAIMED` — *"Task #N was just claimed by another session"* when nothing was claimed (filed as idea 1000617; two agents burned a full investigation each). Both halves are fixed now: task 1002589 made the refusal honest (`session_already_has_bound_claim`, naming the in-flight claim), and task 1002570 (`core_204`) re-keyed the index to `(session, worktree)` — **one bound claim per worktree just works**, matching the guard. The batch endpoint below remains a fine way to claim a whole wave in one call.

**Use the batch endpoint**, which was built for exactly this:

```
node scripts/gds/api.js POST /api/gds/claims/batch \
  --body-file batch.json     # {"task_ids":[111,222,333],"bind_session":false}
```

`bind_session:false` stores each claim with a NULL session, which is the supported web-claim mode; many NULLs coexist. The safety property that matters — one task per worktree, one branch per ship, no commingled commits — is preserved, because you still give each task its own worktree.

```bash
git worktree add .claude/worktrees/task-<id> -b worktree-task-<id> origin/main
```

Always branch from a **freshly fetched `origin/main`**, not from local `main`.

---

## 4. Briefing an agent per worktree

Each agent gets one task, one worktree, and an explicit **do-not-touch list** naming the files its siblings own. That list is what makes parallelism safe, so keep it accurate as the wave progresses.

Include in every brief:

- the absolute worktree path, and "never edit the main checkout, never `git push origin main`, never merge to main yourself"
- the claim is **already held** — tell them not to run `claim.js` (it will fail, per §3)
- the **known-red test baseline**, by name. If the suite is red on `main` for environmental reasons, an agent that doesn't know will either chase ghosts or quietly assume its own regressions are pre-existing. Give them the exact list and the technique: `git stash push -u`, re-run the suspect test on the clean tree, compare.
- **report findings, don't fix them.** An agent that patches a defect in a sibling's file creates a conflict and hides a bug. Several of this session's most valuable findings came from agents that stopped and reported.
- **mutation-test your own tests.** The highest-value defect class here is a test that passes while proving nothing — one agent shipped a first draft where both sides of the comparison read the same field, so mutating it moved both sides together and nothing went red. Require: break the thing deliberately, confirm red, revert, report that you did it.

---

## 5. The merge-conflict tax

One file will become the contention point. Here it was the module's nested `CLAUDE.md`: four agents each appended to the same "build plan" line, and the resulting conflicts stalled two ships and needed manual recovery.

**Mitigations, best first:**

1. **Don't share the file.** The task that avoided the problem entirely needed a new kernel port, and registered it from a **new** file rather than editing the contended one. Prefer adding a file over editing a shared one.
2. **Assign disjoint regions.** If several agents must edit one doc, give each a *specific* slot ("one bullet appended at the end of the Gotchas list", "one paragraph immediately after the R95 block") and forbid reflowing anything else. Different regions usually auto-merge.
3. **Accept and recover.** A conflict is a bail, not a corruption — the task parks at `confirmed` and nothing is lost.

**Generated files: always resolve by regenerating, never by picking a side.**

```bash
git checkout --theirs <file>
node scripts/gds/gen-repo-map.js      # or gen-api-docs.js, gen-diagrams.js
git add <file> && git commit --no-edit
```

Picking a side leaves the artefact inconsistent with source, and the freshness fitness check fails on the *next* task instead of yours. The generated symbol blocks and the OpenAPI spec both bit us this way.

> If `ship.js` says *"auto-merge: bailed; task stays at confirmed"*, don't reach for `/merge-mode` first. Merge `origin/main` into the **task's own branch**, resolve there, re-run `fitness.js`, then re-run `ship.js <id>` — it resumes from `confirmed`. `/merge-mode` is an operator procedure that mutates the main worktree and assumes a bash/SSH environment.

---

## 6. Treat the ship grade as a noisy signal

The subagent grader gates on **forwarded confidence**, not just scores. A worker that times out returns no vote, which collapses confidence and fails work that has **no defect finding against it**.

Observed in one session: two tasks failed on a worker `SUBAGENT_TIMEOUT` and passed on retry **with zero code change**; another failed three times at 8.5–9.5/10 against a threshold of 6 with 4 of 5 workers passing every time.

Practical rules:

- **Capture the full grader output.** Do not pipe `ship.js` through `tail` — you will lose the finding and have to pay for another run. Redirect to a file.
- **Read the per-worker table before reacting.** "4/5 PASS, verdict CONCERNS, confidence 0.3" is an infrastructure failure. "1 worker FAIL" is a real defect.
- **A re-grade is the right first response** to a timeout-shaped failure. It is also not free — budget for it.
- **A pass is not evidence either.** A gate this noisy can wave things through. Run a separate adversarial review over the finished work.
- When the grader repeatedly flags a deliberate architecture decision, that is a signal to **record the decision** (an ADR or a triaged idea) rather than to keep re-litigating it per task — each re-grade costs real money.

---

## 7. Run an adversarial review at the end

Fan reviewers out over surfaces, then have **every finding attacked by an independent skeptic prompted to refute by default**. On this goal that pass killed 6 of the top 8 findings — including three that were confidently written and wrong. Two survived, both reproduced end-to-end against the live module, and both were real.

What made it work:

- Tell reviewers explicitly **not to inherit the ship grades' verdicts**, and to re-derive security claims from the code.
- Give the skeptics the failure modes to check: is the path actually reachable? is there a compensating control? is this a documented deliberate decision?
- Name the highest-value defect class up front. Here it was tests whose expectation derives from the same code under test.
- Findings that are never adversarially verified should be **recorded as unverified**, not reported as defects. With a 6-of-8 refutation rate, an unverified finding is more likely wrong than right.

---

## Checklist

```
[ ] Pull the real DAG; unwrap .data; be suspicious of an empty dependency graph
[ ] Audit edge DIRECTION — does anything validate its own prerequisite?
[ ] Predict files per task; build the conflict graph; group parallel vs serialised
[ ] Narrow tasks in a tree BEFORE the sweep that owns that tree
[ ] git worktree per task, branched from a fresh origin/main
[ ] POST /claims/batch with bind_session:false (NOT claim.js)
[ ] Brief each agent: worktree path, do-not-touch list, known-red baseline,
    report-don't-fix, mutation-test your tests
[ ] Assign disjoint regions in any shared doc; prefer a new file
[ ] Regenerate generated files on conflict; never pick a side
[ ] Capture full grader output to a file; read the per-worker table
[ ] Adversarial review at the end; record unverified findings as unverified
```

---

## Provenance

Goal 1000030 (Governance — configurable roles & permissions), 2026-07-30. 14 tasks shipped; 5 defects found that were outside any task's scope, the most serious being that a demoted builder retained their previous powers because nothing kept role assignments in sync with rank.

Related ideas: 1000617 (session-claim guard vs index), 1000618 (legacy ranks resolve to zero permissions), 1000624 (uncached per-request resolve — ADR 0016 tension), 1000625 (`guards` prose has no oracle), 1000626 (unverified review backlog).
Related tasks: 1002550, 1002551, 1002552, 1002553, 1002554.
