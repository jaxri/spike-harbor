# Run a project on your own machine — `bongos dev`

> The one-command path from a freshly-cloned **standalone instance repo** (one whose
> `config/branding.json` points at `http://localhost:<port>`) to a running, signed-in
> instance on your Mac. This is the local counterpart of `bongos onboard` (which
> stands an instance up in the **cloud**) — see [ADR 0149](../adr/<redacted>.md).

## TL;DR

```bash
gh repo clone <owner>/<project>
cd <project>
npm install
npx bongos dev
```

`bongos dev` starts the database, creates this project's database, builds its tables,
launches the server on the port in `config/branding.json`, and signs you in. Re-running
it is safe (idempotent). Stop it with `bongos dev stop`.

## Prerequisites (one-time, per machine)

- **Node.js ≥ 22** — `node --version`
- **PostgreSQL 16** — `psql --version`. Install on a Mac with Homebrew:
  ```bash
  brew install postgresql@16
  brew services start postgresql@16   # bongos dev will also try to start it for you
  ```
- macOS or Linux (migrations use `bash`). On **Windows**, use WSL, or the Docker path in
  [`self-host.md`](self-host.md).

## What `bongos dev` does (and why it's needed)

A cloned project ships the code but nothing *running*. The server reads its port from an
env var and **not** from branding, the migrator and the server default to **different**
database names, and node-pg defaults to a Linux socket that doesn't exist on a Mac — so a
by-hand standup is a six-step assembly with three silent mismatches. `bongos dev` does all
of it from one source of truth (your `config/branding.json`):

1. Ensures Postgres is running (starts it if it isn't).
2. Creates the project's database if it doesn't exist.
3. Runs migrations to build/refresh the tables.
4. Starts the server on the branding port (e.g. `http://localhost:3006`).
5. Signs you in to this instance (`--no-login` to skip).

## Commands

```bash
npx bongos dev                 # stand it up (idempotent) + sign in
npx bongos dev status          # is it running? what URL? is sign-in configured?
npx bongos dev stop            # stop the background server this launched
npx bongos dev --foreground    # run attached instead (Ctrl-C stops it)
npx bongos dev --no-login      # stand it up but don't sign in
npx bongos dev --skip-migrate  # skip the migration step (already migrated)
npx bongos dev --port 3011 --db my_scratch   # override the port / database name
```

The server runs in the **background but managed** — `bongos dev status`/`stop` always find
it, and a second `bongos dev` is a no-op if it's already up. (This is deliberate: an
*unmanaged* leftover server is how you end up accidentally signing a new project into an
old one's server.)

## The one step that can need you: a GitHub OAuth App

Sign-in uses a GitHub OAuth App. If your machine already ran another Cloud Bongos instance,
the credentials are usually already present and `bongos dev` just works. If not, it prints
exact steps: create an OAuth App (Homepage `http://localhost:<port>`, callback
`http://localhost:<port>/api/gds/auth/web/callback`, tick **Enable Device Flow**), then save
the Client ID + secret to `~/.config/<configDir>/gds-github.json` as
`{ "client_id": "…", "client_secret": "…" }` and re-run `bongos dev`.

## Notes

- **Sign in as the owner.** `config/branding.json`'s `firstAdmin` is the GitHub account
  auto-seated as owner on first sign-in — `bongos dev` tells you which one.
- **Switching instances.** Signing in to a local project points your CLI session at it; to
  go back to a hosted instance later, `bongos login https://<that-instance>`.
- **Multiple projects at once** each get their own database + port, so their `bongos dev`
  servers don't collide.
- **Prefer the cloud?** `bongos box` + `bongos code` give you a remote dev box instead — no
  local database or server to run.
