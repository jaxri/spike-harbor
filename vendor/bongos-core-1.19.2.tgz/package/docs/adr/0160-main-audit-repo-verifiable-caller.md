# 0160 — The authoritative main audit gets a repo-verifiable caller

- **Status:** Accepted
- **Date:** 2026-08-08
- **Deciders:** jaxri (Archon), Claude
- **Track:** `internal` (build pipeline / governance)
- **Task:** [1002612](https://cloudbongos.com/builders#/task/1002612), under goal [1000024](https://cloudbongos.com/builders#/goal/1000024) (Build-pipeline integrity)

**Builds on:** [ADR 0043](<redacted>.md) (designates the post-push audit the authoritative layer — **unchanged**), [ADR 0159](<redacted>.md) (the merge-gate reconciliation this is the detective-lane companion to), [ADR 0158](<redacted>.md) (findings G-3, G-8, S-1).

---

## Context

`scripts/gds/main-audit.js` reads the real git history on `main` and the real builder ranks
and flags sub-Metic edits to permission-sensitive surfaces — the layer ADR 0043 calls
**authoritative**. Both of its declared invokers (`.claude/scheduled-tasks/main-audit/`,
`infra/deploy.sh`) have never existed in this repository (G-3). The honest limit S-1 stands:
the production droplet may run it from an untracked deploy script, which cannot be settled
from this checkout — so the remedy is a caller that **is** verifiable from the repo, not an
assumption about the droplet either way. Same shape, same pass (G-8):
`scripts/gds/audit-authorship.sh` — the no-hardcoded-Archon-identity enforcer named by
CLAUDE.md and canonical-permissions.md — also had no programmatic caller, and turned out to
be red with 340 pre-existing hits on untouched main (idea 1000653).

## Decision

1. **A `main-audit` workflow runs on every push to `main`** (plus `workflow_dispatch`),
   auditing exactly the pushed range via `OTB_AUDIT_RANGE=before..after` from the push
   event, falling back to the script's clamped first-parent window when `before` is a zero
   or unknown SHA. It is a **detective lane, not a merge gate** — it must not join the
   required PR contexts (`unit` / `secret-scan` / `gate-review`, ADR 0159).

2. **The roster comes from the public leaderboard when no session exists.**
   `fetchRankMap` falls back to `GET /api/gds/public/leaderboard` — server-authoritative,
   unauthenticated, and it carries exactly the two fields the audit keys on
   (`github_login`, `rank` — login-only keying per the anti-aliasing rule). A builder
   absent from the leaderboard resolves as *unresolved* ('review' finding), never as
   falsely trusted.

3. **`--require-roster` makes an empty roster a loud DID-NOT-RUN (exit 2).** With no
   ranks, every author is unresolved and a blocker can never fire — a green exit there is
   a check that did not execute wearing the costume of a clean audit. The CI caller always
   passes this flag; local best-effort reads keep the old warning behavior.

4. **The lane runs non-strict.** The script's own #863 calibration: a *resolved* sub-Metic
   author on a protected path is the zero-false-positive blocker; an *unresolved* author
   (the operator's display-name commits, deploy automation) is a review note. `--strict`
   in CI would make the lane permanently red on routine operator commits — and a
   permanently red detective lane rots into wallpaper.

5. **`audit-authorship.sh` gets its caller in the same workflow, as an advisory job**
   (`continue-on-error: true`) — it is red on untouched main today, and enforcement
   before the idea 1000653 triage would wedge the lane. Advisory makes the rot visible on
   every push instead of nonexistent; flip it to enforcing when the triage lands.

## Consequences

- The authoritative layer now runs somewhere any repo reader can verify, on every push to
  main. S-1 stays open exactly as written — this neither proves nor disproves a droplet
  caller.
- The known-failing ratchet caught task 1002611's publish_manifest fix (the lane's first
  red on main was `known_failing_ratchet` — the pairing working as designed): its entry is
  removed and the ceiling ratchets 3 → 2. The two remaining entries now name task 1002617
  as owner. Idea 1000542 (which owned the publish_manifest failure) is superseded — discard
  at triage.
- A blocker finding on this lane is a *revert conversation*, not an automatic revert — the
  ADR 0158 rule that a finding never executes its own remedy.

## Rejected

- **A GDS token secret for the authenticated roster route** — an owner dependency the
  devcontainer lane already warned about ("half-wiring it would fail silently"); the public
  surface carries the same two fields with no secret to rot.
- **`--strict` in CI** — see 4; permanent red is how a detective lane stops being read.
- **Wiring `audit-authorship.sh` as enforcing now** — 340 pre-existing hits would wedge
  every push; visibility first, enforcement after triage.
