# 0144 — Federated single-logout: hub-initiated back-channel session revocation

- **Status:** Accepted — built in task 1002238.
- **Date:** 2026-07-15
- **Deciders:** Lars (owner/Archon) chose the back-channel approach; Claude designed + built.
- **Task:** [#1002238](https://cloudbongos.com/builders#/task/1002238) · **Goal:** 41 (cross-site identity). Follow-up to [ADR 0141](<redacted>.md).

## Context

Cross-site identity ([ADR 0141](<redacted>.md)) gave single sign-**on**: one hub login (cloudbongos.com) reaches every federated project's hall with no second GitHub sign-in. But sign-**off** stayed local. When a federated instance completes the SSO handshake it mints its **own** local session (`completeIdpFlow` → `createSession`) with its own cookie on its own domain. `POST /auth/logout` revokes only *that* instance's session + clears *that* apex cookie — so signing out of the hub left every federated project (e.g. demo) still signed in. Owner request (2026-07-14): make sign-out universal.

Three approaches were weighed (the task's options):

- **(a) Back-channel SLO** — on hub logout the hub server calls each entered instance's revoke endpoint (server-to-server).
- **(b) Front-channel SLO** — the browser is bounced through each instance's logout URL (classic OIDC front-channel).
- **(c) Soft sessions** — federated instances stop holding durable sessions and re-check the hub continuously.

## Decision

**Take (a) — back-channel single-logout — per the owner's explicit call.** It is the robust, browser-independent choice for a session-lifecycle security feature, and it reuses the federation machinery ADR 0141 already built.

1. **A hub-signed, purpose-tagged EdDSA logout token.** The hub mints (`platform-identity/hub-keys.js` `mintHubLogoutToken`) a compact Ed25519 JWT — the **same envelope + asymmetric key + ~120s TTL + audience-binding** as the login assertion (`mintHubAssertion`), so a token minted for instance A can't be replayed against instance B, and a compromised instance (holding only the public key) can't forge one. The payload carries **only** `{ iss, aud:<client_id>, sub:<github_id>, purpose:"backchannel-logout", iat, exp, jti }` — never identity, a rank, or a session token. The **`purpose` marker is load-bearing**: a login assertion has no `purpose` (rejected by the logout verifier) and a logout token has no `github_login` (rejected by the login verifier `verifyHubAssertion`), so the two token types are **mutually non-interchangeable** — a captured login assertion can't trigger a logout, and a logout token can't mint a session. The instance verifier (`auth.js verifyHubLogoutToken`) is the boundary-mirrored sibling of `verifyHubAssertion` (ADR 0091 §2), alg **hardcoded to Ed25519** (no algorithm-confusion), signature verified **before** any claim is trusted.

2. **Kernel-mediated seam event, so core stays module-agnostic.** `POST /auth/logout` (core) revokes the local session as before, then **emits** a `builder.logout` seam event (fire-and-forget). On a non-hub instance nothing listens → no-op. On the hub, the `platform-identity` module (enabled only there) reacts. Core never references the module (ADR 0083 one-way rule); the switchboard (`src/module-seams.js`) is the seam.

3. **The hub fans out; the instance revokes.** The module's listener looks up the builder's entered projects and POSTs a per-project logout token to each `{origin}/api/gds/auth/backchannel-logout`. That endpoint (core `auth.js`/`routes/auth.js`, **dormant unless the instance federates** — `idpConfigured()`, else a plain 404) verifies the token against the hub public key it already trusts (`/sso/pubkey`), resolves the builder by `github_id`, and calls `revokeAllSessionsForBuilder` — killing **all** of that builder's local sessions (web + CLI).

4. **Entered-instance list = memberships (ADR 0141 §3).** The hub uses `listMembershipsForAccount(github_id)` — the projects the builder is known to build on — as the fan-out target list, per the task's sanctioned V1 signal. **Over-notifying is safe:** an instance with no live session for that builder just revokes nothing (revoke is idempotent). A precise per-SSO-session entry ledger (notify *only* instances with a live federated session) is a deliberate follow-up, not V1.

5. **Best-effort, bounded, isolated fan-out.** The user's hub session is revoked **synchronously** (the part they experience); the cross-instance sweep runs server-side off the fire-and-forget event, each POST bounded by a 4s timeout, all under `Promise.allSettled` — a slow or down project can never wedge the sweep or the logout, and the fan-out never throws. **Accepted limitation:** if an instance is unreachable at logout time, its local session survives until its own TTL; a retry/queue is out of scope for V1 (logged, not retried).

6. **Anti-replay on the instance side.** A logout token's `jti` is honored **once** (`logoutTokenJtiSeenAndRecord`, symmetric with the CLI-assertion path): the first use revokes, a replay within the ~120s TTL is an idempotent no-op. Without this, a captured token would stay a repeatable "log this builder out" primitive for its whole life — it could keep killing sessions the builder legitimately creates *after* the token was minted (revoking already-dead sessions is otherwise harmless).

## Consequences

- **Trust boundary preserved (ADR 0016 / 0141).** The logout token, like every other hub→instance message, carries **identity only** (a subject to sign out) — never authority. The instance decides locally what "sign this github_id out" means (revoke its own sessions). Authority stays local.
- **Deploys to both sides.** The instance half (`/auth/backchannel-logout`, `verifyHubLogoutToken`, the `builder.logout` emit) ships in **core** (dormant on non-federated instances); the hub fan-out ships in the **platform-identity** module. So this go-live re-vendors **both** the hub (cloudbongos.com) and every federated instance (demo). Core `1.18.5 → 1.18.7` (the `1.18.6` cut on `main` is the unrelated task 1002241 `?return=` fix, carried along).
- **No new schema.** Reuses the existing `<redacted>` + `sso_clients` (origin) rows and the existing Ed25519 hub keypair. No migration.
- **Not front-channel (b):** modern third-party-cookie / iframe restrictions (Safari ITP, Chrome's trajectory) make browser-driven cross-site logout unreliable, and it doesn't complete if the tab closes mid-chain. Rejected for a security guarantee.
- **Not soft sessions (c):** re-checking the hub per-request adds latency to every request and makes a federated instance's sign-in fail whenever the hub is down (a hard runtime dependency) — too heavy for a bootstrapped setup.
- **V1 scope:** hub-initiated logout only. A federated instance's own logout does **not** yet propagate back to the hub + siblings (it has no client registry); that's a follow-up if wanted.
- **Known limitation — a membership-spoof presence oracle (security review, medium).** The fan-out targets a builder's `<redacted>`, and `POST /sso/membership/check-in` (ADR 0141 §3) trusts a caller-named `github_id` under any active `client_secret`. So a client-secret holder can assert a membership for an arbitrary `github_id` and thereafter receive a hub-signed logout callback naming that builder on each of their hub logouts — a cross-account presence/existence oracle. It is **contained** (the token is `aud`-bound to the attacker's own `client_id`, so it can't be replayed against the victim's real instances — no session compromise) and **gated** (an `sso_client` is registered only by the operator-run `provision.js`, never a public route, so today every secret-holder is an operator-provisioned, trusted instance — the only client is `demo`). The root cause predates this ADR; this feature newly turns it into an active signed callback. **The proper fix — bind the fan-out to evidence of a real federated session for that `github_id` (a per-SSO-session ledger), or prove user consent at check-in — is the deferred follow-up (task [#1002244](https://cloudbongos.com/builders#/task/1002244)); it must land before federation opens to untrusted third-party clients.**
