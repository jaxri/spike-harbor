# 0145 — The Dev Box app becomes a branding-driven module (one source, per-instance builds)

- **Status:** Accepted — Phase 1 built in task [#1002255](https://cloudbongos.com/builders#/task/1002255). Downloads (1002257), CI + releases repo + signing (1002258), and end-to-end verify (1002256) follow.
- **Date:** 2026-07-15
- **Deciders:** Lars (owner) — "re-set up the dev box app so it's properly installable for cloudbongos; the design should not be linked to a specific project but to the Cloud Bongos design; it should live on cloudbongos and be maintained there as a module, and Example should borrow it."
- **Extends:** ADR 0045 (the Dev Box desktop app), ADR 0072 (app signing posture), ADR 0083 (module system), ADR 0004/0062 (brand discipline — no hardcoded host identity), [branding contract](../branding-contract.md).

## Context

The Dev Box desktop app (ADR 0045 — an Electron menu-bar/tray switch that pairs sign-in, flips the box on/off, and wires the local SSH + Claude-Desktop last mile) was **built for Example and lived outside the Cloud Bongos core**:

- Its source was only in the OTB monolith (`~/dev/Claude-OTB/devbox-app/`), never in the neutral core.
- It was **hardcoded to Example/OTB**: `src/brand.js` (`CIV_NAME: 'Example'`, `PRODUCT_NAME: 'OTB Dev Box'`, `example.com` origins), `appId com.offtheboats.devbox`, artifact names `OTB-Dev-Box-*`, the renderer's parchment/ancient-Greek theme (Cinzel/EB Garamond, tan `#ece0c2`) and an archaic "thy/thee" voice ("a gift of Hermes").
- cloudbongos already ships the *download-redirect server* (`src/devbox-downloads.js`) but with no `config/devbox-app.json` and no Cloud-Bongos app to point it at — so a cloudbongos builder had **no installable app**, only the browser terminal + manual SSH.

## Decision

Vendor the app into the dev-box module and make **every brand input a build-time value read from the instance branding**, so one source tree builds any instance's app.

1. **House it in the module:** `modules/dev-box/app/` (40 files, ~600K; `node_modules`/`dist` excluded). The desktop app is not a formal module `contributes` type (the manifest schema has no "app" — routes/pollers/uiSections/webSurfaces only), so it lives as **source inside the module**; `module.json` is unchanged. The generic `src/devbox-downloads.js` stays in core and reads the instance's `config/devbox-app.json` (Phase 2).

2. **Build-time brand generator** — `scripts/gen-brand.js` reads `config/branding.json` (→ `branding.neutral.json` fallback, the Cloud Bongos pack) and emits three generated, committed artifacts:
   - `src/brand.generated.json` — `PRODUCT_NAME`, `APP_ID` (`com.<worldslug>.devbox`), `PRODUCT_SLUG` (artifact filenames), origins, `DESKTOP_ENV_NAME`, `COPYRIGHT`, `CONFIG_DIR`, `BG_COLOR`, `TAGLINE`. `src/brand.js` is now just `module.exports = require('./brand.generated.json')`.
   - `renderer/theme.generated.css` — the `:root` design tokens (palette + fonts) from `theme.ui`; `styles.css` keeps only layout and consumes the vars, so the panel re-skins entirely from branding.
   - `electron-builder.yml` — rendered from `electron-builder.tmpl.yml` (appId/productName/copyright/artifact slug substituted; electron-builder's own `${version}/${arch}` left literal).
   It runs in `prep` (→ `prestart`/`pretest`/`predist:*`), so every build regenerates for the building instance. Same source → **"Cloud Bongos Dev Box" here, "Example Dev Box" there** — the ADR 0004 posture generalised to every instance, enforced by the `no hardcoded host identity` fitness gate (which this now passes).

3. **Example borrows it as a module** — it enables `dev-box` and its build runs `gen-brand` against its own `config/branding.json`, producing the OTB-branded app from the shared source. No forked copy.

4. **Functional cross-component constants stay** (not "design", so not rebranded): the ttyd terminal user `otb` and the SSH key filename `~/.ssh/otb_builder` are contracts with the box image (`box-terminal.service`, the authorized-keys fetch, `/builder-connect`); the `window.otb` renderer↔preload bridge is an internal namespace. The session file dir, however, **is** branding-driven now (`~/.config/<configDir>/gds-session.json`) so pairing the app still signs in the instance's own `/builder-*` CLI.

## Consequences

- The neutral core now carries a **Cloud-Bongos-branded** Dev Box app by default (warm palette, Baloo 2/Quicksand, plain modern voice, `com.cloudbongos.devbox`). Committed generated defaults come from `branding.neutral.json` (Cloud Bongos brand pack; `localhost` origins are the neutral dev default — a real instance build bakes its own origins + the runtime session/API base overrides them anyway).
- Verified Phase 1: `gen-brand` renders cleanly; the app's 56 unit tests pass (the one OTB-hardcoded assertion is now brand-agnostic); `node --check` clean; the client-vendor path fixed for the two-levels-deeper location; **all architecture fitness checks pass** (module→doorway-only, no hardcoded host identity, repo-map fresh).
- The **API/builders origins the distributed app pairs against must be baked from the instance branding at build time** — so the real cloudbongos installer must be built with the cloudbongos instance `config/branding.json` (`cloudbongos.com`), not the neutral core's `localhost`. This shapes Phase 3 (where the branded build runs).

## Follow-ups (open)

1. **Downloads (task 1002257) — DONE 2026-07-17.** `config/devbox-app.json` pushed to the instance repo → `cloudbongos.com/downloads/devbox/*` 302 to the v1.0.10 release assets (all targets verified through Caddy). ⚠ **Vendored-config quirk:** `serve-internal.js` reads the config via a naive `require('../../config/devbox-app.json')` that in a *vendored* instance resolves to `node_modules/@bongos/core/config/`, **not** the instance root where the file lives (unlike branding/modules). Workaround: copied the config there on the host + restarted `cloudbongos.service` — **lost on next core upgrade / `npm ci`**. Proper instance-root-resolve fix = **task 1002371** (same class as ADR 0144's `infra/`).
2. **Distribution (task 1002258) — DONE 2026-07-17.** CI `.github/workflows/build-devbox-app.yml` builds **signed + notarized** mac (arm64+x64) + win (x64+arm64); public releases repo `example-owner/cloudbongos-devbox-releases` hosts them; **v1.0.10 published**. Release origins baked via CI repo variables `DEVBOX_PUBLIC_ORIGIN`/`_BUILDERS_ORIGIN` (= cloudbongos.com). Gotcha found live: notarization 403'd until the owner accepted a lapsed **Apple Developer Program License Agreement** — then the signed+notarized build went green. Publishing = download CI artifacts → `gh release create/upload` (manual, no cross-repo CI token; ADR 0045).
3. **App icon still OTB art.** `scripts/gen-icons.js` draws the app/tray/DMG icons from **pixel grids in the script** (currently the OTB design); the committed PNGs are OTB. Regenerating them from the Cloud Bongos bongo motif (edit the grids + re-run `npm run icons`) is a distinct art follow-up — the app's *name/colors/voice* are Cloud Bongos, but the *icon* is not yet.
4. **Dev/CI env-var names** (`OTB_DEVBOX_API_BASE`/`_SCREENSHOT_DIR`/`_AUTOFLOW`) keep the `OTB_` prefix — harmless dev hooks, not user-visible; prefix-neutralising them is optional polish.
5. **ADR number collision:** `0144` is used twice on this branch (`devbox-rehome` + `federated-single-logout`, from a parallel merge). Cosmetic; a renumber is worth a follow-up.
