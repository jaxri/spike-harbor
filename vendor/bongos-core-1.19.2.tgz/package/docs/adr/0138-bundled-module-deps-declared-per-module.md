# 0138 — A core-bundled module's external npm deps are declared per-module; the consumer composes them (core stays lean)

- **Status:** Accepted
- **Date:** 2026-07-10
- **Deciders:** example-owner (owner/Archon), Claude. Presented the fork (keep core lean + declare per-module vs. hoist the dep into `@bongos/core`); the owner chose to keep core lean.
- **Task:** [#2160](https://example.com/builders#/task/2160) (BONGOS-V1, goal 26) — rehearsal finding **F2** from the R89 cutover rehearsal ([`docs/reviews/<redacted>.md`](../reviews/<redacted>.md)).
- **Builds on:** [ADR 0108](<redacted>.md) (core consumed as a pinned npm dep; core deps = express+pg), [ADR 0083](<redacted>.md) (the module manifest contract).

## Context

The R89 cutover rehearsal converted the example monolith into a `@bongos/core` consumer and surfaced **F2**: with `dependencies: { "@bongos/core" }` alone the consumer boots and then crashes on `Cannot find module 'colyseus'` — and, more subtly, on `Cannot find module 'discord.js'`. The game/art deps (`colyseus`, `phaser`, `sharp`) are obviously the host's. But `discord.js` is different: the **discord module ships INSIDE `@bongos/core`** (it's one of the ~15 bundled core modules), yet `package-core.js` synthesizes only `express` + `pg` as the core's `dependencies` ([ADR 0108](<redacted>.md) §Context). So the core ships the discord module's *code* but declares none of its *runtime dep* — the consumer is silently expected to provide `discord.js`, with a boot crash as the only feedback.

Two facts frame the decision:

- **`discord.js` is the only such case today.** A scan of every bundled core module found exactly one external npm require beyond `express`/node built-ins: `discord.js`, in the discord module.
- **The discord module is opt-in** (`module.json` `default: false`). Most instances never enable it.

So the open question (rehearsal F2, "separately decide"): should `@bongos/core` declare its bundled-module deps (e.g. `discord.js`) itself — as `optionalDependencies`/`peerDependencies` — or should the consumer provide them?

## Decision

**`@bongos/core` stays lean (`express` + `pg`). A bundled module that needs an external npm dependency declares it in its own `module.json` `dependencies`, and the consumer composes the deps of the modules it ENABLES.**

1. **Core deps unchanged.** `package-core.js` continues to synthesize `dependencies: { express, pg }` (+ the undici pin). We do **not** hoist `discord.js` (or any future module dep) into the core package.
2. **Manifest field.** `module.json` gains an optional `dependencies: { "<npm-name>": "<semver-range>" }` block ([`src/module-loader/manifest-schema.js`](../../src/module-loader/manifest-schema.js) validates it — a typo'd range is caught, not silently ignored). The discord manifest declares `{ "discord.js": "^14.26.4" }` — the honest home for the fact.
3. **Consumer composition.** Greenfield `bongos init` composes the ENABLED modules' declared deps into the instance `package.json` ([`scripts/gds/init.js`](../../scripts/gds/init.js) `enabledModuleDeps` → `buildInstancePackageJson`), so turning a module on brings its npm deps. Precedence: module deps fill gaps, an explicit pre-existing instance pin wins, `@bongos/core` is always set.
4. **The cutover preserves.** The example R89 cutover re-authors the consumer `package.json` from the monolith's **existing** dependency closure ∪ `@bongos/core` (runbook §2) — the monolith already carries `discord.js` + the game/art deps, so preserving is sufficient there. `enabledModuleDeps` is the greenfield/adopt path, not the conversion path.

## Why lean-core over hoisting (the trade-off)

- **Hoisting bloats the common case.** `optionalDependencies` still install by default, so declaring `discord.js` in core makes **every** consumer download it (and its transitive `undici`, WebSocket stack, …) for a module that is **off by default**. That directly cuts against [ADR 0108](<redacted>.md)'s deliberate lean-core choice.
- **`peerDependencies` don't fix the crash.** An *optional* peer dep is not auto-installed by npm, so the boot crash would remain; a *required* peer dep is just hoisting with extra warnings.
- **Per-module declaration is honest and scales.** The dep lives with the code that needs it, the manifest stays the single source of truth for "what this module is," and the pattern generalizes to any future module without re-touching core.
- **`--omit=optional` is opt-out, not opt-in.** Relying on consumers to prune an unwanted dep is the wrong default; composing only enabled modules' deps is opt-in by construction.

## Consequences

- **`@bongos/core`'s dependency surface stays minimal + auditable** — the property [ADR 0108](<redacted>.md) and `package_core.mjs` (`dependencies == { express, pg }`) already lock in.
- **A bundled module with an external dep MUST declare it** in `module.json` `dependencies`, or a consumer that enables it crashes at boot. Documented in [`docs/modules-contract.md`](../modules-contract.md).
- **Greenfield/adopt** instances that enable a module get its deps automatically; the **R89 cutover** stays a preserve-existing-closure step.
- **No new standing credential or CI machinery** — this is authoring-time composition, not an install-time core change.

## When to revisit

If a bundled module ever becomes `default: true` AND carries a heavy external dep, revisit whether that module belongs in the core bundle at all (vs. an opt-in add-on) — the dep-posture question would then be downstream of a module-bundling question.
