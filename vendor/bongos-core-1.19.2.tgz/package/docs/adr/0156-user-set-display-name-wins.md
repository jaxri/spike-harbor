# 0156 — A builder's own display name wins, always

- **Status:** Accepted
- **Date:** 2026-08-04
- **Deciders:** Lars (owner / Archon), Claude

**Track:** `internal` (GDS / builder experience). Task [1002568](https://cloudbongos.com/builders#/task/1002568), under the **Builder experience** goal [1000025](https://cloudbongos.com/builders#/goal/1000025).

---

## Context

A builder sets their display name in the hall's Settings page. It saves — the toast confirms it, the sub-header updates, the row really is written — and then it silently reverts to their GitHub account name the next time they sign in.

The write path was never the problem. `PATCH /me/display-name` validates via `modules/builder-settings/display-name.js`, writes through `modules/builder-settings/db.js`, and every read surface (hall header, leaderboard, work feed) already prefers `display_name` over `github_login`.

The problem is that `upsertBuilder` (`src/bongos/db-kernel.js`) is named for account creation but runs on **every authentication**. Its conflict branch re-synced the whole identity row from GitHub:

```sql
ON CONFLICT (github_id) DO UPDATE
  SET github_login = EXCLUDED.github_login,
      display_name = EXCLUDED.display_name,   -- ← the clobber
      avatar_url   = EXCLUDED.avatar_url
```

`EXCLUDED.display_name` is whatever the caller just read off GitHub. All four login paths feed it: `pollDeviceFlow` (CLI setup/re-auth), `completeWebFlow` (browser hall sign-in), `completeIdpFlow` and `completeDeviceExchange` (federated hub). So the builder's own name survived exactly until their next sign-in — and because CLI re-auth counts, that is often the same working day.

That re-sync is not a bug on its own. It is why a builder who changes their name on GitHub sees the change reflected here without doing anything. Keeping that is a real requirement; the row is seeded from GitHub in the first place.

## Decision

**Once a builder sets their own display name, GitHub never overwrites it. Builders who never renamed keep syncing from GitHub.**

The row records *who last set the name*. A new core column, `builders.display_name_source text NOT NULL DEFAULT 'github'` (migration `<redacted>`, CHECK-constrained to `'github' | 'user'`), carries that one bit:

- `setBuilderDisplayName` (the only path a builder can rename themselves through) stamps `display_name_source = 'user'` alongside the name.
- `upsertBuilder`'s conflict branch guards the assignment:

  ```sql
  display_name = CASE WHEN builders.display_name_source = 'user'
                      THEN builders.display_name
                      ELSE EXCLUDED.display_name END
  ```

`github_login` and `avatar_url` keep re-syncing unconditionally — neither is user-editable, and `github_login` is identity, not a label.

`'github'` is the correct default for every pre-existing row: before this change there was no durable user-set name, so whatever is stored *is* the GitHub-derived value. A builder who had been fighting the revert re-saves once and it sticks.

### The rejected alternative: just delete the line

The one-line fix is to drop `display_name = EXCLUDED.display_name` from the conflict branch entirely. No migration, no new column, no new state.

It was rejected because it fixes one builder's problem by taking a feature away from everyone else. `display_name` would then be frozen at whatever GitHub reported the day the account was created. A builder who renames themselves on GitHub — or who had no GitHub display name at signup and so was seeded with their bare login — would be stuck with a stale label forever, with the hall Settings editor as the only way out. The revert bug affects builders who deliberately renamed; the frozen-name bug would affect everyone who never touched Settings, which is most of them. Trading a visible bug for a silent one is a bad trade.

The chosen fix costs one boolean-shaped column and keeps both behaviours correct.

## Consequences

- **New core column.** `builders.display_name_source`. Core, not `modules/builder-settings/migrations/`: the column sits on the core `builders` table and the guard that reads it lives in core `db-kernel.js` on the auth path. A module migration may only touch its own namespaced objects ([ADR 0083](<redacted>.md) §Decision #5), and core schema must not depend on whether a module is enabled. Same placement as the other `builders`-table preference columns (037, 075, 119, 164).
- **Not surfaced in the API.** `GET /me/display-name` and `docs/api/openapi.json` are unchanged. The flag is internal persistence state; no UI copy branches on whether a name is GitHub-derived, so exposing it would be surface with no consumer.
- **The federated hub needs no matching guard.** `modules/platform-identity/platform-identity.js`'s `upsertAccount` does the same unconditional re-sync on `platform_identity_accounts`, and its `display_name` reaches an instance through `completeIdpFlow`. It does not need changing: the `CASE` above runs regardless of what `EXCLUDED` carries, so an instance's `builders.display_name` is protected no matter which login path supplied the value. And `platform_identity_accounts` is identity-only with no self-service editor — there is no user-set value there to protect.
- **Regression-tested where it broke.** `tests/display_name.mjs` previously covered only the pure validator, which is exactly why this shipped: the half that was correct was the half under test. It now also reads the real SQL both halves emit and asserts the conflict branch's behaviour — a renamed builder keeps their name against a different incoming GitHub name, and a never-renamed builder still picks up a GitHub rename.
