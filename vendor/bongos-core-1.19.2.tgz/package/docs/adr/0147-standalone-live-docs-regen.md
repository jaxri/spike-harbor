# ADR 0147 — Carry ADR 0110's deploy-regen of generated docs to STANDALONE instances

- **Status:** Accepted
- **Date:** 2026-07-17
- **Track:** internal
- **Builds on:** [ADR 0110](<redacted>.md) (untrack + deploy-regen the whole-file nav docs), [ADR 0108](<redacted>.md) (standalone instance = own repo + pinned `@bongos/core`), [ADR 0062](<redacted>.md) §8 (`gen-session-index.js`), [ADR 0063](<redacted>.md) (`gen-repo-map.js`)
- **Task:** [#1002314](https://cloudbongos.com/builders#/task/1002314)

## Context

The owner's report: *"All of the docs in cloudbongos.com did not transfer well from primea. Make sure any new project is also set up with live-updating docs."*

The generated navigation docs (`repo-map.md`, `session-log-index.md`, `file-map.md`, the onboarding diagrams, the API reference) stay fresh on the **example monorepo** because ADR 0110's regen-on-deploy is wired into `scripts/deploy/deploy-prod.sh` + `infra/box-source-fetch.sh`. **STANDALONE instances (ADR 0108) never got that step.** A standalone instance is its own lean repo with `@bongos/core` vendored in `node_modules`; it deploys via a bespoke pull script and updates the core via `bongos upgrade`. Two concrete defects left its `docs/` frozen and nearly empty (cloudbongos.com had only the 3 API-doc files):

1. **`gen-session-index.js` hardcoded the core root** — `REPO_ROOT = path.resolve(__dirname,'..','..')`, the exact ADR 0108 configurable-root bug `gen-repo-map.js`/`gen-file-map.js` warn against. On a standalone instance it read/wrote `node_modules/@bongos/core/docs/session-logs`, never the instance's own sessions. It was left behind in the configurable-root migration.
2. **No standalone regen-on-deploy path.** The bespoke pull-deploy (`git reset --hard origin/main` → migrate → restart) regenerated *nothing*; `bongos init` + `bongos upgrade` only regenerated the API docs (`regenerateApiArtifacts`). So the whole-file nav docs were never seeded and never refreshed on a standalone box.

There is no `scripts/deploy/` in the neutral core — `deploy-prod.sh` is the monorepo's, not something a standalone instance runs.

## Decision

Carry ADR 0110's model to the standalone path — the standalone analogue of the `deploy-prod.sh` regen block.

1. **Fix the root bug.** `gen-session-index.js` resolves `REPO_ROOT = resolveInstanceRoot()` (mirrors `gen-file-map.js`), so it indexes the instance's own `docs/session-logs/` and writes the instance's `docs/session-log-index.md` + the instance-root `CLAUDE.md` §13 snippet. On the monorepo/at-ship it still resolves via the cwd fallback.
2. **A shared regen seam.** `upgrade.regenerateNavDocs({instanceDir, coreRoot})` runs the whole-file nav generators against the instance root, best-effort + LOUD (a broken generator prints `::ERROR::` but never fails the deploy/bump — ADR 0110 §2 "accepted staleness"). A thin CLI, `scripts/gds/regen-instance-docs.js`, is the one-liner a standalone deploy calls.
3. **Wired at every refresh point.** `bongos init` seeds it at standup; `bongos upgrade` refreshes it on a core bump; `provision.js`'s standalone deploy runs it after migrate; a bespoke pull-deploy (e.g. cloudbongos.com's `deploy.sh`) calls the CLI after `git reset --hard` + migrate.
4. **Gitignored on the instance.** `provision.js`'s `INSTANCE_GITIGNORE` ignores `docs/session-log-index.md` (+ `docs/repo-map.md` for parity), so `git reset --hard` never wipes the regenerated file and no branch can ever diff it — the same reasoning ADR 0110 applies on the monorepo.

**Scope — deliberately `session-index` only.** It is the one *gitignored, whole-file, instance-content* nav doc. Explicitly excluded:

- **`repo-map.md`** — CORE-scoped: `gen-repo-map` writes to `resolveCoreRoot()` (the platform-code map), not the instance. A pure standalone instance runs the core from `node_modules` and has ~no code of its own to map, so an instance-level repo-map is empty/meaningless; the core ships its own. An instance-scoped map for **brownfield/adopted** repos (which *do* carry their own code) is a separate enhancement (task 1001655).
- **`file-map.md` + the API docs** — TRACKED/committed (seeded at init, refreshed at ship/upgrade). Regenerating them on the box would perpetually dirty the tree that `deploy.sh` `git reset --hard`es. `file-map` is also HYBRID (hand-written prose + generated sections) so it cannot leave git; **seeding a fresh instance's `file-map.md` at standup is a follow-up** (it needs a scaffolded `file-map.md` skeleton with the section markers + a `file-map.notes.json`).
- **Diagrams** — the headless-browser + authed-GDS-session exception (same as ADR 0110 / task 1001641). They do not migrate to the box; they are rendered at package/CI time and shipped.

## Consequences

- A freshly-init'd standalone instance seeds `session-log-index.md`, and its deploy + `bongos upgrade` keep it live against the *instance's* sessions — the "docs didn't transfer" gap is closed for every new project, not just cloudbongos.com.
- **Accepted staleness (inherited from ADR 0110 §2):** the served whole-file doc is fresh only after a deploy/upgrade, not at merge — tolerable for a navigation index. A generator that breaks leaves a stale/absent file with no *blocking* backstop; the `::ERROR::` line is the alarm.
- **Follow-ups:** (a) seed `file-map.md` at standup (scaffold skeleton + notes); (b) an instance-scoped `repo-map` for brownfield/adopted repos (task 1001655); (c) productize a continuous pull-deploy timer for standalone instances (today only cloudbongos.com has a bespoke one) so content-only commits redeploy without a manual pull.
