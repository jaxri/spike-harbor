# ADR 0136 — Update-channel subscription policy (patch-only, health-gated, opt-in, autonomy-gated)

**Date:** 2026-07-10
**Status:** Accepted.
**Context:** [task 2150](https://example.com/builders#/task/2150) (BONGOS-V1, goal 26). The last piece of the update-consumption workstream: [ADR 0100](<redacted>.md) §2 / [task 1690](https://example.com/builders#/task/1690) gave a consumer the manual `bongos upgrade` channel; [ADR 0134](<redacted>.md) / [task 2090](https://example.com/builders#/task/2090) added the private-registry source; [task 2149](https://example.com/builders#/task/2149) added auto-rollback; [task 2157](https://example.com/builders#/task/2157) proved rollback live on the demo instance. What was missing is the **subscription** — how a consumer instance takes new releases *on a cadence, unattended*, rather than a human running `bongos upgrade` each time. Builds on the scheduled-routines portability contract ([ADR 0115](<redacted>.md)).

## Problem

"How do projects subscribe to regular updates?" needs a policy, not just a mechanism. Left unspecified, an auto-updater is a footgun: it could take a breaking major unattended, upgrade an instance nobody meant to enroll, or leave an instance down after a bad release. Two questions had to be answered together: **(1)** how far may an unattended upgrade jump, and **(2)** what has to be true before anything moves on its own. A third question — who *publishes* the releases the subscription consumes — is related but separable, and conflating it would have blocked (1) and (2) behind a publishing-automation decision.

## Decision

Adopt the owner-chosen policy (2026-07-09): **patch-only by default, health-gated with auto-rollback, opt-in, and autonomy-gated.**

**1. Update channels bound the blast radius.** Each subscribed instance carries an `update_channel`:

- `pinned` — never auto-upgrade (manual `bongos upgrade` only).
- `patch` — take a higher **patch** within the same `major.minor` (`1.17.1 → 1.17.4`, never `1.18.0`). **The default.**
- `minor` — take a higher **minor** within the same major (`1.17.1 → 1.18.0`, never `2.0.0`).

A **major** bump is never automatic under any channel — a breaking change wants a human. Prereleases (`1.17.2-rc.1`) are never auto-targeted. This math is the pure, unit-tested core [`scripts/gds/update-channel.js`](../../scripts/gds/update-channel.js) (`resolveChannelTarget` / `channelAllows`), so the "what should this instance move to?" decision is testable in isolation from any I/O.

**2. The registry is the source of truth for "what's newest."** A subscription needs a live feed of published versions — `npm view @bongos/core versions` against the private registry (ADR 0134), not a vendored tarball. The vendored path stays the manual-bump fallback.

**3. Every auto-upgrade is health-gated with auto-rollback.** The routine drives `bongos upgrade --to <v> --registry` with auto-rollback **ON** (task 2149): a patch that fails install/migrate/health reverts its pin, reinstalls the previous core, restarts, and records a `rolled_back` ledger row. The DB is left intact (core migrations are additive/forward-safe). So "unattended" never means "unsafe."

**4. Triple-gated before anything moves.** The scheduled routine [`core-update-subscription`](../../.claude/scheduled-tasks/core-update-subscription/) is:

- **Autonomy-gated** — `requiresAutonomy: true` in [`config/scheduled-routines.json`](../../config/scheduled-routines.json), a no-op until the instance arms `<PREFIX>_AUTONOMY_ENABLED`. Default **OFF** (ADR 0115's rule for autonomous-action routines).
- **Opt-in** — the roster [`config/update-subscriptions.json`](../../config/update-subscriptions.json) ships **empty**; an instance is touched only after an operator lists it (with its dir, systemd unit, health URL, channel, and an optional `env` map so `migrate` hits the right DB).
- **Health-gated** — per (3).

The routine is `mode: deterministic` (System 4, [ADR 0078](<redacted>.md)) — it runs as plain `node` with no model session — and **instance-wide** (ADR 0115): one run per instance iterating the roster, not one cron per instance-being-watched.

**5. Upstream auto-publish is explicitly split out, not decided here.** For a subscription to deliver anything, new patches must be *published*. Today that is a gated owner step (`package-core.js --publish --live`, ADR 0134). This ADR deliberately scopes the subscription to **consume whatever the owner has published** and does **not** decide whether merges to `main` auto-publish a patch. That is its own decision (publishing cadence, provenance, who holds the token) and is filed as [task 2158](https://example.com/builders#/task/2158). Splitting it lets goal 26 close on the consumption half, which is what the switchover needs.

**6. Scope: local, same-host instances.** The routine upgrades instances reachable from the control plane on the same host (the co-hosted shape — e.g. the demo instance beside the control plane). Multi-host / SSH orchestration across a real fleet is the deferred managed-fleet-control-plane epic ([task 1948](https://example.com/builders#/task/1948) / idea 303, "no fleet registry exists"); this routine is the per-instance consumption half that epic will call.

## Alternatives considered

- **A `provisioning_instances` DB column for the roster + channel.** Rejected for now: the provisioning module models a *request→standup* lifecycle, not a subscription; coupling the subscription to it presumes the fleet-registry schema that is still being designed. A config manifest is migration-free (matches the task's `needs_migration:false`), matches the ADR-0115 "operator configures via a manifest" pattern, and is trivially superseded later by a `loadSubscriptions()` seam swap.
- **Auto-take minors by default.** Rejected: minors can carry behavior changes; patch-only is the conservative default an operator can widen per instance.
- **No dry-run / apply-always.** Rejected: `subscribe.js` is dry-run by default (the box-sweep convention); the scheduled step passes `--apply`. A hand run previews safely.
- **Deciding auto-publish here.** Rejected — see (5); it would have blocked the consumption half behind an orthogonal publishing decision.

## Consequences

- **`config/update-subscriptions.json` is the portability surface** for subscriptions — the one place an operator opts an instance in and sets its channel. A vanilla instance boots subscribed to nothing.
- **The policy is enforced by a pure, tested core**, not prose: [`tests/update_channel.mjs`](../../tests/update_channel.mjs) pins the channel matrix (majors/prereleases never auto, patch stays on its minor, pinned/unknown → no-op).
- **A follow-up task owns upstream auto-publish** — [task 2158](https://example.com/builders#/task/2158) (whether/how `main` merges publish a patch: cadence, version-bump provenance, token custody, the pre-publish no-leak gate). Until it lands, the subscription simply picks up whatever the owner publishes, which is safe and useful on day one.
- **No behavior change until armed.** OTB (and any fresh instance) ships this OFF with an empty roster; nothing auto-upgrades until an operator both arms autonomy and enrolls an instance.
