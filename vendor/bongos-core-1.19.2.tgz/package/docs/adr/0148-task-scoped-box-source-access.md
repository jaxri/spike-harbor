# 0148 — Task-scoped box source access (rank-scope → claim-scope)

- **Status:** Accepted (spike R90 / task 1002378 — the architecture pass for goal 1000051). Confirms the build shape of R92–R95.
- **Date:** 2026-07-18
- **Deciders:** Lars (owner) — "claim a task → the box pulls only that module's code, on a base Bongos instance; the GitHub token stays on the server." Corrected the earlier "bring-your-own-GitHub" framing.
- **Extends:** ADR 0031 §6 (box source-access, task 600), ADR 0086 (goals + `scope_modules` scope wall), ADR 0093 (the `lifecycle` port), ADR 0052 (sandbox-for-everyone starter scope). Spec: [`docs/specs/<redacted>.md`](../specs/<redacted>.md).

## Context

A builder's dev box already pulls **scoped** source from the control plane — the GitHub token stays server-side (`box-credential.js`), the box calls `GET /box/source-access` authenticated as the builder, and **git cone-mode sparse-checkout** materializes only the returned folders (`infra/box-source-fetch.sh`, cron `*/10`). Today the scope is a coarse **rank** bucket: `boxScopeForRank(rank)` → `full` (Metic+, whole repo) or `starter` (a fixed `STARTER_SPARSE_PATHS` slice). We want the box to instead carry **the code the builder's claimed task needs**, on top of a base instance — moving the scope from *rank* to *task/module*.

The question this spike answers: **how does `box-access` derive the sparse paths from the builder's active claim(s) without breaking the dev-box↔core module boundary**, and what exactly do R92–R95 build.

## Decision

**Scope = `BASE ∪ (union of the builder's active claims' goals' `scope_modules`, mapped to globs)`.** The claimed task's **goal** is the unit of "what code this work needs" — its `scope_modules` is the already-declared module footprint (the ADR 0086 scope wall), so we reuse it rather than inventing a new per-task field. Union across active claims (owner decision). The transport (`/box/source-access` → `cloneSpecForScope` → sparse-checkout) is unchanged; only *what scope is computed* changes.

**The seam — four small pieces, each already has a home:**

1. **The map is already on the doorway.** `src/module-api.js` exposes `moduleScopeMap` (since doorway `1.12.0`, BV1.R86). So `box-access` reads `api.moduleScopeMap.scopeForModule(key).globs` directly — **no new kernel edit**. The only change is dev-box's `module.json` `coreVersion` `^1.2.0` → `^1.12.0` (core is 1.18.x; satisfied).

2. **The claims read is a small lifecycle-port add.** The `lifecycle` port already exposes `<redacted>`; add a sibling **`<redacted>(builderId)`** that JOINs `claims → tasks → goals` for the builder's active claims and returns the **set-union of `goals.scope_modules`** (empty array when no active claim). dev-box resolves it via `seams.resolveOptional('lifecycle')` — the ADR 0093 module-consumes-port pattern — and adds `lifecycle` to its `consumes` (optional; a vanilla instance without it degrades gracefully to the rank fallback).

3. **`box-access` gains a pure scope→paths function.** `sparsePathsForScopeKeys(scopeKeys, moduleScopeMap)` = `BASE_SPARSE_PATHS ∪ ⋃ directoryGlobs(scopeForModule(key))`. `decideSourceAccess({rank, status, scopeKeys})` gains the optional `scopeKeys`: **present → task-scope spec; absent/empty → base-only; no lifecycle port → the existing rank fallback.** Rank still governs ALLOW/DENY and the provision floor (a below-floor/inactive builder is still 403); rank no longer picks the module *breadth* once a claim drives it.

4. **The route resolves + passes.** In `GET /box/source-access` (which already reads `gdsDb.getBuilderById` via the doorway), resolve the lifecycle port, `const scopeKeys = await lifecycle?.<redacted>(req.builder.id)`, and pass it into `decideSourceAccess`. One added read on an existing handler.

**`BASE_SPARSE_PATHS`** (the "pre-existing Bongos instance" — always present so Claude has context + can run `/builder-*`): the non-product subset of today's `STARTER_SPARSE_PATHS` — `.devcontainer`, `.claude`, `scripts`, `src/bongos`, `docs`, `infra` (+ top-level files, auto by cone mode). Task-module globs layer on top.

### The cone-mode constraint (load-bearing)

Git **cone-mode** sparse-checkout accepts only **directory** entries — a file path aborts the whole `sparse-checkout set` (already documented in `box-access.js`). Module `scope_modules` → globs are of two shapes:
- **Directory globs** (`modules/dev-box/`, `devbox-app/`, `modules/onboarding/`, `modules/hall-ui/`) — cone-friendly, added directly.
- **File-list globs** (the `kernel` key = individual `src/bongos/*.js` files) — NOT cone-friendly, BUT their parent `src/bongos` is already in `BASE`, so a `kernel`-scoped task needs no extra sparse entry.

So R93 filters task globs to directory entries; file-list keys are covered by base. (A future move to non-cone sparse patterns could pull individual files, but it is out of scope — cone mode stays.)

## Consequences

- **Confirmed R92–R95 shapes** (the spike's deliverable):
  - **R92** — dev-box `module.json` `coreVersion` → `^1.12.0` + `consumes:['lifecycle']`; add `lifecycle` port read `<redacted>(builderId)` (db.js query + `lifecycle.js` delegation + a DB-integration test). *Smaller than planned — the map is already exposed.*
  - **R93** — `box-access.js`: `BASE_SPARSE_PATHS`, pure `sparsePathsForScopeKeys()`, `decideSourceAccess({…, scopeKeys})` with the three-way branch; unit tests (0/1/N keys, cone-filter, fallback).
  - **R94** — `routes/box.js`: resolve lifecycle + pass `scopeKeys`; graceful when the port is absent.
  - **R95** — folded into R93's pure decision: 0 claims → base-only; N claims → base ∪ all N goals' scopes. Kept as its own test-focused task.
- **Behavior change to flag:** an **idle Metic+** (no active claim) now gets **base-only**, not the whole-repo `full` clone they get today. That is the intent (the box is task-scoped), but it is a regression for a Metic+ who relied on an idle box holding everything. Preserving idle full-access would be a config toggle — **deferred**, not built here.
- **Security posture unchanged (C4):** the credential is still server-issued per fetch from `box-credential.js`; the box never stores the GitHub token durably. This spike does not touch the token model. The deferred hardening (short-lived per-claim credential + hard "can't over-pull" enforcement) is unaffected and still deferred — task-scope here is what the box *asks for*, not yet an *enforced* ceiling.
- **C4 verified (R102 / task 1002390):** the server-side-token posture is pinned by [`tests/box_credential.mjs`](../../tests/box_credential.mjs) (7 assertions): the credential is sourced only from the prod env (unset → `configured:false`, no fabricated token — ADR 0022); the secret lands in **no** field but `.token` (so the `source_grant` audit — now `scope=<sparse> cred=<rank> mode=…` — carries no secret); the credential scope stays **rank**-based (a separate `BOX_SOURCE_STARTER_REPO_URL` is a hard boundary that only `full` crosses, and an unexpected `task`/`base` label fail-closes to the non-full repo, never the crown jewels); the **claim-scoped `decideSourceAccess` decision carries no secret** (the token is minted *separately* by `box-credential.js`, so changing the sparse breadth never touches the token model); and an inactive/below-floor builder is denied **before** any credential is issued (instant, credential-layer revocation). The **deferred hardening** — a genuinely short-lived, per-claim-*minted* credential plus a hard "can't over-pull" isolation (physically separate per-task materialization) — remains explicitly OUT of scope for this goal; task-scope is the box's *ask*, and the token model is unchanged.
- **No new migration, no kernel/doorway change, no protected-path edit** beyond the additive lifecycle-port read — R92–R95 all sit inside the `dev-box` + `lifecycle` surface the goal is already scoped to (plus the R91 scope-map prep for the separate C2 chain).
