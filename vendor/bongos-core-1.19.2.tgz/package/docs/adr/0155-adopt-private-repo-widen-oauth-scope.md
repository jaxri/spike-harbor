# 0155 — Adopting a private repo: widen the onboarding OAuth scope to `repo`

- **Status:** Accepted — built in task [#1002561](https://example.com/builders#/task/1002561).
- **Date:** 2026-08-04
- **Deciders:** the owner chose the credential approach after being shown the trade-off; Claude diagnosed + built.
- **Amends:** [ADR 0143](<redacted>.md) §1 (its Decision 1 — scope choice). 0143 otherwise stands unchanged: opt-in per sign-in, lazy consent, encrypted short-TTL token store, personal repos only, 503-degrade. Per 0143's own append-only rule, this is a new ADR, not an edit.
- **Related:** [ADR 0121](<redacted>.md) (greenfield vs brownfield onboarding).

## Context

Standing up a project on an **existing private repo** failed. Live evidence — `provisioning_instances` id=14, `example-owner/hermeslines-marketing`, `status='error'`:

```
git -C /srv/cloudbongos/hermeslines-marketing … push https://x-access-token@github.com/…  HEAD:main
remote: Write access to repository not granted.
fatal: … The requested URL returned error: 403
```

`scopeForWebFlow()` requested `read:user public_repo`. **`public_repo` grants write to *public* repos only**, so the provisioner's scaffold push to a private repo 403s.

Three things confirm this was scope and not credentials:

1. The live `github_oauth_tokens` row was `scope='public_repo,read:user'` and **still valid** during the failure window. A dead token returns `401 Bad credentials`; `403 Write access to repository not granted` is GitHub's canonical *scope-insufficient* response.
2. Every **greenfield** project ever created worked, because `createUserRepo` hardcodes `private:false` — the platform only ever pushed to repos it had just made public. Adopt is the first flow where a private repo can be the target, so this had never been exercised.
3. The picker already renders a **"Private" badge** (`public-landing/create.html`) — UI written for a case `public_repo` made unreachable, since `/user/repos` omits private repos under that scope.

ADR 0143 §1 anticipated exactly this and named the exit: *"**Accepted limitation:** private repos can't be listed/adopted or created; revisit to `repo` only if private support is needed"*, with *"switching to `repo` (private support) is a one-line scope change"* under Consequences. This ADR takes that path.

Options weighed with the owner:

- **(A) Never let the server touch the user's repo.** For adopt, the user runs `bongos init --adopt` and pushes themselves — which the wizard already instructs — and provisioning only stands up server/DB/address. Keeps the narrow scope. Cost: a private repo still needs a read-only deploy key for the instance to *run*, and the "we set it up for you" promise weakens.
- **(B) Widen the scope to `repo` and keep pushing on the user's behalf.** One consent screen, no extra steps, adopt works for public and private alike. Cost: the persisted token can write to **every repo the user owns**.
- **(C) Public repos only.** Detect a private repo at the form and refuse early. Cheapest, but declines the feature.

## Decision

**Take (B) — `scopeForWebFlow({repos:true})` now returns `read:user repo`** — per the owner's explicit call, having been shown that this reverses 0143's least-privilege posture and enlarges what a leaked token can reach. Within that:

1. **`repo`, and only on the wizard path.** 0143 §2 is unchanged and load-bearing: the broadened scope is requested *only* via `?repos=1` from `/create`. Hall web sign-in and the CLI Device Flow stay `read:user`. `scopeForWebFlow` remains the single place the string is decided, and the unit test now asserts both that the wizard gets `repo` and that the default path carries **no** repo-acting scope.
2. **A stale-scope token must re-prompt, not degrade.** Widening the *request* does not upgrade tokens already stored. A surviving `public_repo` row still lists and creates *public* repos, so without a check the wizard would 200 while **silently omitting the user's private repos** — and the real failure would resurface minutes later as the same opaque push 403. New `grantedScopeCoversRepos()` parses GitHub's comma-separated granted scope and gates `resolveRepoToken`, which now returns the existing `repo_scope_required` (403) so the wizard's well-exercised reconnect path handles it. Parsing (not substring-matching) matters: `public_repo` *contains* `"repo"`, and a naive match would accept precisely the token this guards against.
3. **A repo *we* create stays public.** `createUserRepo` keeps `private:false`. Under `repo` it *could* create a private repo; it doesn't, because a Cloud Bongos instance is open-source / capture-resistant by design. This is now a **product** choice rather than a credential limit, it is deliberately not a parameter, and a test pins it so the widen can't silently change what we create. A user wanting a private instance adopts a private repo they made themselves.
4. **Consent is stated in our own words first.** GitHub's screen for `repo` reads as full control of all repositories. The wizard's connect copy now says plainly that this is the only scope that can write to a private repo, and what we do with it (read the repo you pick; push the setup commit), so the user does not first learn the breadth from GitHub's wording.

## Consequences

- **Security posture — the real cost.** The stored token is now a materially bigger honeypot: write access to every repo the user owns, public and private. 0143's containment still applies unchanged and is what makes this tolerable — encrypted at rest via secret-box, **1h TTL**, lazily swept, requested only on the wizard path, and never stored at all when secret-box is unconfigured. The blast radius is nonetheless larger than before, and this is the ADR to revisit first if a token ever leaks.
- **A GitHub App remains the principled fix.** 0143 §Context option (B) — a central App with fine-grained `Contents:write` on *only* the selected repo — gives adopt-private without the account-wide grant. It was rejected then for the install step, and this decision makes the case for it stronger, not weaker. A future ADR adopting it would supersede this one.
- **Returning users reconnect once.** Anyone holding a live pre-0155 token gets one `repo_scope_required` prompt. The 1h TTL means the affected window is small.
- **The picker gains private repos** — `/user/repos` returns them under `repo`, lighting up the dormant "Private" badge.
- **This alone does not make adopt work.** The second, independent defect is server-side: provisioning has no notion of adopt and unconditionally `git init`s a fresh tree and pushes to `main`, which an existing repo rejects as unrelated history. Task [#1002562](https://example.com/builders#/task/1002562) fixes that; [#1002563](https://example.com/builders#/task/1002563) verifies both live. **Because the wider scope makes a mistaken `--force` in that path a genuine data-loss route on a user's repo, the adopt push must never force, and 1002562 carries a test asserting it.**
- **Reversal.** Narrowing back to `public_repo` is a one-line change plus dropping the scope guard, and re-accepts 0143's limitation.
