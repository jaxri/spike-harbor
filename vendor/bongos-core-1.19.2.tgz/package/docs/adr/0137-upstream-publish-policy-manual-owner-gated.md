# 0137 — Upstream publish policy: `@bongos/core` patches are published manually (owner-gated), not auto-published on merge

- **Status:** Accepted
- **Date:** 2026-07-10
- **Deciders:** example-owner (owner/Archon), Claude. Presented the manual-vs-auto fork; the owner chose to keep publishing a manual, owner-triggered step.
- **Task:** [#2158](https://example.com/builders#/task/2158) (BONGOS-V1, goal 26) — the **supply** half split out of [ADR 0136](<redacted>.md) §5 / [#2150](https://example.com/builders#/task/2150).
- **Builds on:** [ADR 0134](<redacted>.md) (private-first npm, tokenless tooling), [ADR 0136](<redacted>.md) (subscription consumption policy). **Relates to:** the deferred managed-fleet-control-plane epic ([#1948](https://example.com/builders#/task/1948)).

## Context

[ADR 0136](<redacted>.md) (task 2150) built the **consumption** half of the `@bongos/core` update subscription — the channel math (`pinned`/`patch`/`minor`, never `major`/prerelease unattended) and the auto-upgrade routine that consumes published releases on a cadence. It explicitly deferred (§5) the **supply** half: *"does not decide whether merges to `main` auto-publish a patch. That is its own decision (publishing cadence, provenance, who holds the token)."* This ADR is that decision.

Today, per [ADR 0134](<redacted>.md), publishing is a **gated owner step**: `node scripts/gds/package-core.js --publish --live` requires the owner's `npm login` + 2FA, and *the repo/tooling holds no token* ("npm owns auth — this repo never stores a token"). Consumers install with a **read-only** token via an env-fed `.npmrc`. For a subscription to deliver anything, new patches must be published — so the open question was whether to **automate** that publish (on-merge, using a CI-stored write token) or keep it **manual**.

## Decision

**Publishing `@bongos/core` stays a manual, owner-gated step. Merges to `main` do NOT auto-publish.**

1. **Trigger / cadence — owner-initiated.** The owner runs `package-core.js --publish --live` when they decide to cut a release. Recommended convention: tag the released commit `core-v<version>` as the deliberate, auditable release marker. The tag *documents* the release; it does **not** trigger CI.
2. **Version-bump provenance — deliberate, in-task.** `CORE_VERSION` (`src/module-api.js`) is bumped by hand as part of a task, with a changelog line in the same file (the existing discipline — e.g. task 2148 bumped `1.17.1 → 1.17.2` with a changelog entry). It is **not** auto-bumped. A release publishes whatever `CORE_VERSION` currently is; a stale (un-bumped) version collides with the already-published npm version and npm rejects the duplicate — a natural guard against an accidental no-op republish.
3. **Token custody — no write-token at rest.** No npm **write** token is stored in CI or the repo. The owner authenticates at publish time (a Classic Automation token bypasses the interactive 2FA-OTP prompt when scripting locally; interactive `npm login` + 2FA otherwise). This preserves ADR 0134's tokenless-tooling posture. Only the **read** token (for consumer / CI installs, env-fed `NPM_TOKEN`) exists.
4. **No-leak / mirror-redact gate — already fail-closed.** `package-core.js` builds the artifact *through* the no-leak gate (docs genericized + secret-scrubbed; functional files scanned for a live-credential leak) and **produces nothing** if anything leaks, so `--publish` structurally cannot upload a leaking artifact. No extra gate is needed for the manual path — and any future automated path inherits the same fail-closed gate because it runs the same build.
5. **The subscription is unchanged.** The [ADR 0136](<redacted>.md) routine consumes whatever the owner has published. Its freshness is bounded by the owner's release cadence — intended and acceptable at current scale.

## Why manual over auto (the trade-off)

- **Security surface.** <redacted> requires a long-lived npm **automation write** token as a standing CI secret — a powerful credential that could publish to the canonical brand org from any merge. That reverses ADR 0134's deliberate tokenless-tooling posture for little near-term gain.
- **Low, deliberate volume.** Core patches are infrequent and intentional (`1.17.0 → .1 → .2` over days, each driven by a specific task). The manual publish is not the bottleneck; the consumption side already flows.
- **Bootstrapped posture** ([CLAUDE.md §4](../../CLAUDE.md)). Don't build and secure CI-publishing machinery before a real fleet justifies it.

## When to revisit

When the **managed-fleet-control-plane epic** ([#1948](https://example.com/builders#/task/1948)) stands up a real multi-instance fleet and the manual publish becomes a genuine bottleneck, re-evaluate a **tag-triggered** CI publish (a human still cuts the `core-v<version>` tag; CI runs the already-fail-closed gated publish with a narrowly-scoped token). That is deliberately out of scope here — this ADR keeps the supply side simple so goal 26 closes on the consumption half.

## Consequences

- **Owner-only step at each release** (out of a build session; capture as a blocker if it ever gates verification): bump `CORE_VERSION` + changelog in a task, then run `package-core.js --publish --live`.
- The **release ritual** is documented in [`docs/recipes/private-npm-distribution.md`](../recipes/private-npm-distribution.md) → "Cutting a core release".
- **No CI secret, no new automation** to maintain.
- A consumer on the `patch`/`minor` channel only receives an update **after** the owner publishes — the subscription's freshness is owner-paced by design.
