# 0150 — Box first-boot bring-up on vendored instances: resolve `infra/` from the instance root, fail loud on empty user-data

- **Status:** Accepted (spike BV1.R97 / task 1002385 — the C2 diagnosis for goal 1000051 / 1000052). Confirms the build shape of R98 (task 1002386) + R99 (task 1002387).
- **Date:** 2026-07-19
- **Deciders:** Lars (owner) — "continue with C2" (make cloudbongos boxes stop coming up bare). Claude diagnosed + designed the fix.
- **Extends:** [ADR 0144](<redacted>.md) (its first follow-up item root-caused this), [ADR 0108](<redacted>.md) (the `resolveCoreRoot()`/`resolveInstanceRoot()` split this fix rides), [ADR 0031](<redacted>.md) (box lifecycle), [ADR 0148](<redacted>.md) (task-scoped source access — which only matters once a box actually boots).

## Context

"cloudbongos boxes come up bare" — a freshly provisioned box reaches `active` but has **no clone, no toolchain, no browser terminal** (`term-<login>` returns Cloudflare 530). The task-scoped source-access mechanism (ADR 0148, C1) is irrelevant until a box actually boots with the base instance present — so C2 is the practical foundation.

There are two provisioning paths in the fleet's history:

- **The reference (example) path** — `scripts/gds/box.js` renders a DigitalOcean cloud-init from `infra/builder-box-cloud-init.yaml` (+ ~12 gz+b64-inlined scripts: `box-source-fetch.sh`, the cloudflared/ttyd units, `box-heartbeat.sh`, …). The cloud-init is what clones the source, installs the toolchain, and starts the terminal. A box is "non-bare" **because** its user-data ran.
- **The cloudbongos path** ([ADR 0144](<redacted>.md)) — native `cloudbongos-box-*` runners against the local DB, but the **same `box.js`** renders the same cloud-init.

## Root cause (code-grounded + live-confirmed)

The box boots bare because **`box.js` renders EMPTY user-data and no one notices**:

1. `box.js` sets `REPO_ROOT = path.resolve(__dirname, '..', '..')` ([`scripts/gds/box.js:47`](../../scripts/gds/box.js)). On a **vendored** instance `box.js` lives at `node_modules/@bongos/core/scripts/gds/box.js`, so `REPO_ROOT` resolves to the **vendored-core package root**.
2. The R89 packaging split moved `scripts/gds/` **into** `@bongos/core` but **kept `infra/` as instance content** — `infra/` is **not** in the core publish-manifest, so `node_modules/@bongos/core/infra/` **does not exist**.
3. `readCloudInit()` reads the template at `REPO_ROOT/infra/builder-box-cloud-init.yaml` ([`box.js:258`](../../scripts/gds/box.js)). Missing dir → `readFileSync` **throws** → the surrounding `try { … } catch { return null }` ([`box.js:313`](../../scripts/gds/box.js)) swallows it → **`readCloudInit` returns `null`**.
4. The caller treats `null` as *zero bytes, fine*: `const userDataBytes = userData ? … : 0` then `if (userDataBytes > MAX_USERDATA_BYTES) fail()` ([`box.js:453-455`](../../scripts/gds/box.js)). `0 > 64KiB` is false, so the **only** size guard passes and provisioning proceeds with empty user-data. DigitalOcean logs "No user-data found"; the box is bare Ubuntu.
5. Even a **partial** `infra/` half-wires a box: `fileGzB64()` ([`box.js:268-275`](../../scripts/gds/box.js)) warns on a missing inlined file but still **returns `''`** (fail-soft), so the placeholder is substituted with nothing and that component silently never boots.

**Live re-confirmation (2026-07-19, on the cloudbongos droplet):**

- `infra/` **is present at the instance root** — `/home/lars/cloudbongos/infra/builder-box-cloud-init.yaml` exists.
- `infra/` **is absent in the vendored core** — `/home/lars/cloudbongos/node_modules/@bongos/core/infra/` is gone. The ADR 0144 stopgap (hand-copying `infra/` into `node_modules`) was **wiped by a core reinstall** since 2026-07-15, exactly as that ADR warned.
- `bongos.config.json` at the instance root already declares `{"instanceRoot": "."}` — so `resolveInstanceRootExplicit()` deterministically resolves to `/home/lars/cloudbongos`, where the real `infra/` lives.
- Fleet is idle (1 box, `destroyed`), so the bug is **latent but live**: nothing is broken this instant, but the **next** provision boots bare.

So the failure is a **packaging-locality bug**, not a logic bug: `box.js` looks for `infra/` in the one place it isn't (the core package) instead of the one place it is (the instance root).

## Decision

### R98 — make the box clone the base instance on boot

**Prong A — resolve `infra/` from the instance root** (ride [ADR 0108](<redacted>.md), exactly like [`scripts/migrate.sh:35`](../../scripts/migrate.sh) resolves its roots). A new `resolveBoxInfraDir()` in `box.js` returns the first candidate that actually contains `builder-box-cloud-init.yaml`, in order:

1. an explicit `<PREFIX>_BOX_INFRA_DIR` env override (escape hatch);
2. `resolveInstanceRootExplicit()/infra` — the env / `bongos.config.json` pointer (cloudbongos: `{"instanceRoot":"."}` → `/home/lars/cloudbongos/infra`);
3. `REPO_ROOT/infra` — the dev single-checkout case (and the old node_modules workaround location, for continuity);
4. a bounded walk **up out of `node_modules`** from the core root, so a vendored `…/node_modules/@bongos/core` finds its host instance root even with no pointer set.

All `infra/` reads (`readCloudInit`'s template + every `fileGzB64`) route through this resolved dir. **The neutral core still ships no `infra/`** — this changes only how `box.js` *locates* instance-owned infra, not what the core packages.

**Prong B — fail loud, never provision empty.** Two backstops so a bare box can never be created silently again:

- `readCloudInit()` **throws** an actionable error when no `infra/` dir with the template is found (stop returning `null`);
- `cmdProvision` aborts with `fail(...)` if the rendered user-data is empty / 0 bytes, naming the candidate dirs searched and pointing at this ADR — **before** touching DigitalOcean.

(Optionally escalate `fileGzB64` to hard-fail for the load-bearing inlined files, or assert no `__…_B64__` placeholders survive the render, so a *partial* `infra/` also surfaces rather than half-wiring.)

### R99 — toolchain builds on the box

Once `infra/` resolves and `box-source-fetch.sh` runs on first boot, the base instance clones. R99 then ensures the **runtimes** are present so a pulled module is actually buildable/runnable by Claude on the box: verify the cloud-init (or the devcontainer/`box-source-fetch` bring-up) installs Node + the common build tools, and that on a fresh box a pulled module's `npm ci` / build / test commands run. Concrete scope is R99's own; this ADR only fixes *getting the code + bootstrap onto the box*.

## Consequences

- **Reinstall-proof.** The fix reads the instance's own `infra/` (or an explicit pointer), so a core `npm ci` / `bongos upgrade` can never wipe it — the fragile ADR 0144 workaround-in-`node_modules` is retired.
- **Portable.** Every vendored instance benefits: `box.js` stops assuming `infra/` ships inside the core package. This is a **core** fix (lands on core `main`), not a cloudbongos-only patch.
- **Fail-loud tradeoff (intended).** A genuinely infra-less instance can no longer provision a box — it errors clearly instead of creating a useless bare one. A bare box is worse than a legible failure.
- **Go-live gap.** The fix lands on core `main`; it reaches cloudbongos.com only via the separate release (package-core + `bongos upgrade`). The fleet is idle today, so nothing is broken this instant; the next box provision needs the fix live (or the `node_modules` workaround re-applied as a one-off) — flagged to the owner in the session handoff.
- **No new migration, no doorway/kernel change.** The fix is contained to `scripts/gds/box.js` + a unit test; it reuses the existing `src/instance-config.js` resolvers.
- **R99 landed (task 1002387) — toolchain + test-runnability.** Core-side audit: the `.devcontainer` toolchain is complete (Node 22 via features + `build-essential`/`pkg-config`/Python 3.12 in the Dockerfile, with a build-time integrity healthcheck); the root `package.json` declares **no npm workspaces**, so a task-scoped *sparse* checkout can't break `npm ci`; and the task-scoped BASE already carries the top-level `package.json` + lockfile (cone-mode ancestor inclusion), so `npm ci` has what it needs. The one real gap: a module's **tests live in the top-level `tests/` dir** (`tests/box_*.mjs` + `tests/helpers.mjs`), which was in **neither** `BASE_SPARSE_PATHS` nor `STARTER_SPARSE_PATHS` — so a task-scoped or starter box pulled the module source but **not its tests**, and "a pulled module's build/test commands run" failed. Fix: add `tests` to both scope lists (`modules/dev-box/box-access.js`) — a cone-mode dir carrying only test code, no product runtime. Pinned by the updated `tests/box_access.mjs` + `tests/box_task_scope.mjs`. **Deferred to the live proof (R104, task 1002392):** the end-to-end "fresh box → `npm ci` → a pulled module's build/test actually runs" on the cloudbongos plane — the toolchain *install* rides the instance-only cloud-init (now reachable thanks to R98) and provisioning a box is owner-gated (spends money), so the live demonstration belongs to the C5 proof, not this core change.
- **R98 landed (task 1002386).** `scripts/gds/box.js` gained `boxInfraCandidates()`/`resolveBoxInfraDir()` (the ordered instance-root-first search) + `BOX_INFRA_TEMPLATE`; `readCloudInit` now routes every `infra/` read through the resolved dir and **throws** on a missing/incomplete `infra/` instead of returning `null`; `cmdProvision` resolves the source up front (dry-run + apply, printing `cloud-init source: <dir>`), catches the throw into a clean `fail()` with box state `error`, and refuses to provision on empty user-data. Pinned by [`tests/box_infra_resolve.mjs`](../../tests/box_infra_resolve.mjs) (8 assertions: candidate ordering incl. the node_modules walk-up, first-with-template selection, `null` when none, and the two fail-loud throws). Backward-compatible: a dev single-checkout still resolves `REPO_ROOT/infra`.
