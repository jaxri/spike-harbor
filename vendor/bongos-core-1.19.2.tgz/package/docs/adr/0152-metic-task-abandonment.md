# 0152 — Metic gains task abandonment, paired with an un-abandon at the same rank

- **Status:** Accepted
- **Date:** 2026-07-27
- **Deciders:** Lars (Archon), Claude

**Builds on / amends:** [ADR 0090](<redacted>.md) (Metic task authoring — this ADR reverses one line of its "what stays Archon-only" list), [ADR 0016](<redacted>.md) (server-enforced rank boundary — unchanged), [ADR 0151](<redacted>.md) (permissions-as-atom — the `task.abandon` floor moves with the gate).

**Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability). Task [1002476](https://cloudbongos.com/builders#/task/1002476).

---

## Context

[ADR 0090](<redacted>.md) moved task **authoring** down to the trusted working rank: a Metic can create a task, edit it, promote it backlog→ready, and wire its dependencies and criterion links. Its "what stays Archon-only" list kept one lifecycle transition behind: `POST /tasks/:id/abandon`, described there as "terminal scope removal — the inverse of promote; a destructive lifecycle kill."

A year of using that split showed the asymmetry costs more than it protects. A Metic runs `/idea-triage`, decides which ideas become work, seeds the tasks, and shapes them — and then hits a wall on the one operation that cleans up after all of it. Duplicates they created, chores that a parallel session already shipped, and tasks their own re-scoping made moot all had to be handed back to the owner to retire. The Archon was not adjudicating anything in those hand-backs; they were doing janitorial work on a queue they had already delegated.

Lars's directive (2026-07-27): **"Metics should also be able to abandon tasks."**

### The real risk was not the grant — it was that abandon had no undo

Abandoning is a one-way door *through the API*: `/promote` accepted only `backlog`/`blocked`, `PATCH /tasks/:id` refuses `status` outright ([#514](https://cloudbongos.com/builders#/task/514)), and nothing else writes `status='abandoned'` back to a live value. Restoring a wrongly-retired task meant hand-SQL on prod — an Archon-with-ssh operation.

That was tolerable while abandon *was* Archon-only (the person who could break it could fix it). Handing the kill switch to Metic without an undo would not have removed the owner-cleanup burden; it would have swapped "please retire this" requests for "please un-retire this" requests, with a worse failure mode — a wrongly-abandoned task is invisible in every claimable list and every version rollup ([migration 017](../../migrations/<redacted>.sql) deliberately excludes abandoned from `version_progress`), so nobody notices the mistake until the work silently doesn't happen.

## Decision

**1. Re-rank the gate.** `POST /tasks/:id/abandon` moves from `requireRank('archon')` to `requireRank('metic', 'archon')` — the same threshold ADR 0090 gave create/edit/promote. A rank trusted to seed and shape work is trusted to retire it.

**2. Add the undo at the same rank.** `POST /tasks/:id/promote` now also accepts `abandoned`, restoring the task to **`backlog`**:

| Route | Was | Now |
|---|---|---|
| `POST /tasks/:id/abandon` | archon | **metic+** |
| `POST /tasks/:id/promote` | backlog\|blocked → ready | **+ abandoned → backlog** (metic+, unchanged rank) |

Restore lands in `backlog`, never straight to `ready`. The task was retired deliberately; bringing it back should re-enter it as un-workable and require a second, explicit promote to become claimable. The restore branch returns before the reward gate ([ADR 0096](<redacted>.md)) — that is a promote-to-*workable* concern, and `backlog` is the pre-workable state, the same reasoning `/demote` already uses.

The backing `db.restoreTask` is the mirror of `db.abandonTask`: `SELECT … FOR UPDATE`, guard, single `UPDATE`, commit, with `TASK_NOT_FOUND` / `TASK_NOT_ABANDONED` as its refusals. It clears the `value_summary = 'Abandoned: <reason>'` stamp abandon writes — and *only* that stamp (`CASE WHEN value_summary LIKE 'Abandoned: %'`) — so a restored task never carries a retire note into a later ship card or `#ship-news` broadcast, while an unrelated summary survives.

### What is unchanged

- **The abandon guards.** A `shipped` task is still refused (immutable history — retiring it would corrupt the ledger and the version rollups); a task with an **active claim** is still refused (release it first, so an abandon can never race a ship in flight); an already-abandoned task is still an idempotent no-op.
- **The audit trail.** Both the abandon and the restore are `POST`s through the writing middleware, so `audit_log` records who retired what, with the `reason`, and who brought it back.
- **Everything else on ADR 0090's Archon-only list** — setting rank, closing versions, grader-bypass confirm, cross-tier `POST|DELETE /dependencies` and goal-scope edges, `done-when` unsatisfy, newcomer-restock, peer-vote tally, override adjudication. This ADR moves exactly one row.

### Downgrade protection + the permission catalog

- `EXPECTED_RANKS`'s lifecycle pin (`src/bongos/route-rank-check.js`, `MODULE_EXPECTED_RANKS.lifecycle`) moves to `metic+archon` in lockstep, so a *further* silent downgrade (to `any-builder`) is still a hard CI fail, and the route's `// rank:` annotation matches the middleware.
- Under [ADR 0151](<redacted>.md) the `task.abandon` permission's `floor` moves `archon` → `metic`. Because `RANK_ROLE_SEED` is *derived* from floors, that one edit re-derives the seed; the live grant arrives as `modules/governance/migrations/<redacted>.sql`, since the compat seed (002) is run-once and editing it would leave every already-migrated database on the old grant. The floor change is purely **additive** (archon already holds the permission — the seeded roles are cumulative supersets), so nothing is revoked. `tests/governance_seed.mjs` was generalized to compare the **union** of all grant migrations against the catalog, and now fails loudly if a future migration ever *revokes*, which the union model could not represent.

## Consequences

- **The triage→author→retire loop closes for Metic.** The owner is out of the janitorial path for the queue they already delegated; the remaining owner-only lifecycle powers are ratification and scope-closing, which is where ADR 0090 wanted the line.
- **A mis-retire is now self-service to fix, at the rank that caused it** — and, notably, this also removes an Archon-with-ssh chore that existed *before* this grant.
- **Restore is deliberately not idempotent-friendly the way abandon is.** Calling `/promote` on a non-abandoned task still 409s `cannot_promote` with the current status; the restore path refuses rather than guessing. That keeps `/promote`'s contract honest — it is one route with two explicit source states, not a "make this task alive somehow" verb.
- **Larger trusted surface, same shape as ADR 0090's.** A Metic can now retire any non-shipped, unclaimed task in any open version, with no per-version/per-module fence. That is the same accepted "tighten later" debt: if Metic authority is ever folded into the goal-scope model ([ADR 0086](<redacted>.md)), abandon travels with it.
- **Trust boundary intact** ([ADR 0016](<redacted>.md)): enforcement stays server-side, per request, uncached. Editing a doc or `CLAUDE.md` grants nothing; `requireRank('metic','archon')` on the route is the authority.

## Alternatives considered

- **Re-rank abandon with no undo.** Rejected: it relocates the owner-cleanup burden instead of removing it, and the failure mode (a silently-invisible task) is worse than the one it fixes. The undo is ~40 lines including its guards.
- **A dedicated `POST /tasks/:id/restore` route.** Rejected as surface for its own sake: `/promote` already *is* the "move this task toward workable" verb at exactly the right rank, and the restore is a third source state on it. A separate route would need its own gate, its own pin, its own catalog permission, and its own docs row — all to express the same transition.
- **Restore straight to `ready`.** Rejected: it would make a two-keystroke mistake (abandon → restore) leave the task claimable again with no human re-read of *why* it was retired. Landing in `backlog` costs one deliberate extra call and puts the scope decision back in front of someone.
- **Fence the grant (only tasks the Metic authored, or only non-`security_sensitive` ones).** Rejected as a rule builders have to learn for a threat that isn't real here: a Metic can already `PATCH` and re-scope any task, so "abandon only your own" fences nothing they couldn't achieve by editing. ADR 0090 made the same call for authoring.
- **Promote the affected builders to Archon.** Rejected for the reason ADR 0090 gave: Archon also carries rank-setting, version-close, grader-bypass, and infra — far more than "clean up the task queue."
