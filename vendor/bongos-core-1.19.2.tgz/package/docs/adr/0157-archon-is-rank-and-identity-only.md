# 0157 — Archon is rank and identity only; the operational block delegates to Metic

- **Status:** Accepted
- **Date:** 2026-08-05
- **Deciders:** Lars (Archon), Claude

**Builds on / amends:** [ADR 0016](<redacted>.md) (server-enforced trust boundary — **unchanged**, this ADR moves floors inside it, never the enforcement point), [ADR 0151](<redacted>.md) (permissions-as-atom — this ADR is only possible because the floor is declared once, in `catalog.js`), [ADR 0090](<redacted>.md) / [ADR 0152](<redacted>.md) (the two earlier one-power delegations this generalises), [ADR 0154](<redacted>.md) (**amends** — its "unsatisfy stays Archon" carve-out is superseded), [ADR 0086](<redacted>.md) (protected-scope goals — **unchanged**, `goal.scope.manage` stays Archon).

**Track:** `internal` (GDS / methodology). Task [1002584](https://cloudbongos.com/builders#/task/1002584).

---

## Context

The Archon rank had accumulated 50 route gates. Almost none of them were about *authority*; they were about **administration** — reading the roster, listing dev boxes, viewing the audit log, adjudicating a vulnerability report, tearing down an idle droplet, reordering a queue, ratifying an idea. Each arrived Archon-gated for the same defensible reason: [ADR 0016](<redacted>.md) sets the default posture for any new privileged route to `requireRank('archon')` until a lower rank is explicitly granted — fail closed. Nothing ever came back to lower them, so "fail closed" quietly became "the owner is the only operator."

Two earlier ADRs had already delegated one power each on the same reasoning — [ADR 0090](<redacted>.md) (a rank trusted to *triage* ideas is trusted to *seed* the work they become) and [ADR 0152](<redacted>.md) (a rank trusted to author work is trusted to retire it). This ADR generalises that argument instead of relitigating it one route at a time.

Lars's directive (2026-08-05): **"Move all of these to metic, and make archon just responsible for rank and identity."**

### Why this is now a small change

The literal reading of that directive — edit 41 `requireRank('archon')` call sites — was the wrong shape, and briefly the plan. BV1.R104/R105 (jaxri, tasks [1001846](https://cloudbongos.com/builders#/task/1001846)/[1001847](https://cloudbongos.com/builders#/task/1001847)) had migrated the route gates to `requirePermission(...)` and were sitting at `confirmed` — graded, verified, unmerged — for five days. They landed mid-session.

Once every gate reads `requirePermission('<atom>')`, the rank floor is declared in exactly one place: `floor:` in [`modules/governance/catalog.js`](../../modules/governance/catalog.js). The delegation collapses from 41 call-site edits to **20 one-word floor changes in one table**. That is the ADR 0151 payoff arriving in practice, and it is worth recording as the concrete return on that refactor: the same owner decision was a 41-file diff on Monday and a 1-file diff on Tuesday.

## Decision

### 1. Archon retains rank, identity, and four escalation keys — 13 atoms

| Atom | Why it stays |
|---|---|
| `builder.rank.set` | **rank** — the single writer of `builders.rank`. The whole point. |
| `builder.status.set` | **identity** — offboard / (de)activate: who exists. |
| `access_request.review` | **identity** — who is admitted at all. |
| `auth.session.revoke` | **identity** — whose sessions are valid. |
| `task.confirm.grade_bypass` | escalation key (below) |
| `gate_approval.decide` | escalation key (below) |
| `goal.scope.manage` | escalation key (below) |
| `governance.manage` | escalation key (below) |
| `deploy.push_main`, `path.protected.modify`, `infra.ssh` | substrate-enforced (pre-push hook, `main-audit.js`), outside the HTTP boundary — [ADR 0043](<redacted>.md). Not reachable to delegate here. |
| `version.close` | see §3 |

### 2. The four escalation keys, and why a literal reading of the directive was refused

`builder.rank.set` staying Archon is **not sufficient** to keep "only the Archon sets rank" true. Four other atoms form a chain that ends in self-promotion, and every link was Archon-gated, which is why the chain was closed:

1. Create a goal scoped to a **protected** module — the permission core itself (`goal.scope.manage`).
2. Claim a task in it. **Already allowed**: `PROTECTED_GLOBS` floors at *metic*, by [ADR 0043](<redacted>.md)'s design.
3. Write code deleting the rank check, then confirm past the failed grade (`task.confirm.grade_bypass`).
4. Approve your own red CI deploy gate (`gate_approval.decide`) → it lands on `main`.

Plus `governance.manage`, whose routes R110/R111 have not built yet: it grants roles and permissions directly, so holding it means granting yourself anything — the meta-escalation.

Moving all 20 as literally asked would have opened that chain, making the delegation **self-reversible** — a Metic could reach Archon, at which point "Archon owns rank" is decoration. The concern was put to the owner with the chain spelled out; the owner chose to keep all four. Recording this because the reasoning is not visible from the floor values alone: *four of these look operational and are not.*

**This is the load-bearing invariant of this ADR:** the delegated set must contain no path to raising your own rank. A future delegation must re-run that check rather than assume it.

### 3. Two atoms held back beyond the four, each for a stated reason

- **`version.close`** — [`docs/canonical-permissions.md`](../canonical-permissions.md) has long paired closing a version with setting rank as the two powers that never delegate. Closing a version is the disposition that finalises shipped scope-truth. Kept, and flagged to the owner as a judgment call rather than a derivation. Its sibling `version.create` **did** move: authoring opens a container, disposition finalises one — the asymmetry is deliberate and is now recorded at both atoms.
- **`dependency.cross_tier.manage`** — `system: true`, and `tests/governance_catalog.mjs` enforces that no `system` permission is granted below archon. Moving it would mean clearing the `system` flag, which widens what any **custom role** can be granted — a second-order authority change nobody asked for. The flag is the wall; it was not quietly lowered to satisfy a floor change.

### 4. `gate_approval.read` is minted, splitting the Gate page's read from its write

`page.view.governance` moving to metic opens `/watch`, `/harbor`, `/gate` to the working rank. But `GET /gate-approvals` — the Gate page's only data endpoint — was still `requireRank('archon')`, one of three read routes R104/R105 deliberately skipped because their atom was declared over the module's *writes* only.

Left alone, a Metic would open `/gate` and get a page rendering nothing but a 403. So: `gate_approval.read` (metic) for the list, `gate_approval.decide` (archon, `system`) for approving a held PR. The same "the atom must name the read" step resolves the other two skipped gates — `GET /projects` (`project.curate`) and `GET /security/reports` (`security.report.adjudicate`) — whose write atoms had already moved to metic, which would otherwise have left the **read stricter than the write**: a Metic able to confirm a vulnerability report but not list one.

### 5. Pins move from ranks to atoms

`EXPECTED_RANKS` / `MODULE_EXPECTED_RANKS` in [`route-rank-check.js`](../../src/bongos/route-rank-check.js) pinned these routes to the literal rank `'archon'`. Rank pins break on every floor change; `pinMismatch` compares **atom identity** for `perm:` pins. The affected pins are now `perm:<atom>`, so the guarded invariant is *"this route gates on this permission"* — which is the property actually worth protecting — and a future owner decision to move a floor needs no pin edit.

## Consequences

**What a Metic gains.** The Watch / Harbor / Gate pages and the session log; the dev-box and provisioning fleets (including force-teardown and per-builder blocks); security-report adjudication; the audit log; the builder roster and per-builder grades; cross-builder memory reads; project curation and scouting; budget setting; idea ratification; override-request decisions; release-on-behalf; criterion un-satisfy; goal reorder; newcomer restock; peer-vote tally; version creation.

**The owner's remaining day-to-day surface** is rank changes, admissions, offboarding, session revocation, grade-bypass confirms, CI gate approvals, protected-scope goals, and version close. That is the intended shape: the owner sets *who may act and how far*; the working rank *acts*.

**Two consequences worth a second look** (both flagged to the owner, neither blocking):

1. **The exploit cookbook widened.** `security.report.adjudicate` guards `/security/docs` — the engagement-report store holding attacker-usable exploit detail — so that is now Metic-readable. Every other delegated atom widens who may *act*; this one widens who may *read*. If unwanted, the fix mirrors §4: split a `security.docs.read` at archon and let adjudication delegate. Recorded in `tests/security_docs.mjs` at the assertion that used to guard it.
2. **The backward ratchet delegated.** [ADR 0154](<redacted>.md) made "unsatisfy stays Archon" the explicit safety argument for delegating criterion *create* — the forward ratchet moved, the backward one did not. `criterion.unsatisfy` is neither rank/identity nor an escalation key, so under this directive it moved, superseding that carve-out. What still holds is the part that never depended on rank: satisfy and unsatisfy remain **separate atoms**, so confirming a criterion never confers the power to un-confirm one.

**A floor change needs a migration.** `governance_002`'s compat seed is run-once, so an edited `floor:` never reaches an already-migrated database. [`<redacted>.sql`](../../modules/governance/migrations/<redacted>.sql) grants the 20 to `metic` (+ `gate_approval.read` to both, since it is new). Lowering a floor is additive, so `tests/governance_seed.mjs`'s union model handles it and revokes nothing.

**`requireArchonPage` is now a misnomer** — it resolves `page.view.governance`, floor metic. Renaming it touches serve-internal, auth, and several test files; left deliberately to keep this diff small in authz code, and filed separately. The hall nav group was relabelled **Archon → Governance**, because a header reading "Archon" over items a Metic can open misdescribes the ladder to exactly the builders still learning it.

> **Resolved (2026-08-05, [#1002588](https://cloudbongos.com/builders#/task/1002588)).** That follow-up landed: the gate is now `requireGovernancePage`. It is a pure rename — same `page.view.governance` permission, same `deniedTo`, same audience. References to `requireArchonPage` in this ADR and in ADRs [0036](<redacted>.md) / [0058](<redacted>.md) / [0151](<redacted>.md) are left as written, since they describe what was true at the time; `src/bongos/auth.js` carries a comment naming the old spelling so a grep from any of them lands on the trail.

**What did not change.** [ADR 0016](<redacted>.md) end to end: authority is still resolved server-side, per request, uncached, from `builders.rank` via the seeded rank-roles. A builder editing their checkout still cannot grant themselves anything. This ADR moves floors *inside* that boundary; it does not touch the boundary.

**The ADR 0016 default posture still stands** for *new* routes: start at `requireRank('archon')` / an archon-floored atom and delegate deliberately. This ADR is that deliberate step taken in bulk for the accumulated backlog — not a licence to skip it.
