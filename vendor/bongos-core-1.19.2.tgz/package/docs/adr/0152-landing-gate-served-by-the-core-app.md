# 0152 — The landing gate is served by the core app, not by the front proxy

- **Status:** Accepted
- **Date:** 2026-07-27
- **Deciders:** Lars (owner / Archon), Claude
- **Track:** `internal` (platform serving / instance infra)
- **Task:** <redacted> ([#1002411](https://example.com/builders#/task/1002411)) — the cutover step of the landing-migration chain L01→L07 under the **Project creation flow** goal ([#1000035](https://example.com/builders#/goal/1000035)).
- **Builds on:** [ADR 0062](<redacted>.md) (core ↔ host split), [ADR 0108](<redacted>.md) (instance composition / pinned vendored core), [ADR 0111](<redacted>.md) (per-instance Caddy snippets), [ADR 0003](<redacted>.md) (origin certs).
- **Supersedes in practice:** the "give the landing its own Caddy config + its own deploy script" plan that L05 was scoped around. See §Decision.

---

## Context

The reference instance's landing page — the interactive orb "gate" — was historically **served off disk by the front proxy**. Caddy's apex block set `root * <checkout>/brand/cloud-bongos` and `file_server`'d `/`, `/gate/*` and `/world/*` straight out of a checkout of a *different* product repo (`example-owner/example`), while proxying every functional path to the platform app. The landing therefore had:

- **two sources of truth** — the gate bundle lived in the other repo, and a copy of the serving rules lived in that repo's `infra/Caddyfile` and `scripts/deploy/deploy-cloudbongos.sh`;
- **no deploy path of its own** — updating the landing meant pushing to the other repo and hand-running `git reset --hard origin/main` on the box;
- **a cross-product coupling** the core could not express: a Cloud Bongos instance's front page was owned by an unrelated product's repository.

L01 ([#1002407](https://example.com/builders#/task/1002407)) ported the verified gate bundle into the core as `public-landing/`, and L02 ([#1002408](https://example.com/builders#/task/1002408)) taught `src/platform-server.js` to serve it: `GET /` on the apex host 302-redirects to `/gate/`, `/gate` 301s to `/gate/`, `/gate/` serves the gate index raw, and the existing `express.static(public-landing)` already covers `/gate/*`, `/world/*` and `/assets/*`.

Once L01+L02 shipped, **the app could already serve the entire landing on its own** — but the live box was still file-serving the other repo's copy, because nothing had flipped the proxy. L05 was scoped (before L01/L02 existed) as "give cloud-bongos (a) its own Caddy config and (b) its own deploy script, then cut the box over." By the time L05 came up, both halves of that plan had dissolved.

## Decision

**The core app owns the landing end to end. The front proxy does TLS, the staging lock, and `reverse_proxy` — nothing else.**

Concretely, the apex and vanity-door site blocks drop `root` + `file_server` and proxy the landing paths to the app, exactly like every other path:

```caddy
example.com, www.example.com {
	tls /etc/caddy/origin.crt /etc/caddy/origin.key
	encode gzip zstd
	import security_headers

	# The landing surface. Identical to the catch-all except for the staging
	# lock — so lifting the lock is a one-block delete, not a re-plumb.
	@gate path / /gate /gate/* /world/*
	handle @gate {
		basic_auth {
			# optional pre-launch lock; omit once the site is public
		}
		# Caddy runs `redir` BEFORE `basic_auth`, so "/" redirects first and the
		# visitor meets the lock at /gate/. The app issues the same 302, so this
		# line stays correct after the lock is removed.
		redir / /gate/ 302
		reverse_proxy 127.0.0.1:3000
	}

	handle {
		reverse_proxy 127.0.0.1:3000
	}
}
```

Three consequences follow, and they are the actual decision:

**1. There is no separate Caddy config to "give" the landing.** The block above is the *generic* instance block — the same pure-proxy shape `provision.js`'s `caddyBlock()` already writes for every provisioned instance ([ADR 0111](<redacted>.md) §4). The landing stopped being a special case in the proxy the moment the app could serve it. Host-specific values (hostnames, cert paths, whether a lock exists) stay on the host, per [ADR 0062](<redacted>.md) §7 — the core ships the *shape*, not an instance's hostnames.

**2. There is no separate deploy script to write.** The landing ships **inside the pinned core package**, so it rides the instance's existing deploy: bump the core pin in the instance repo → the box's pull-deploy picks it up → the new landing is live. One artifact, one version number, one deploy path. A landing change is now a normal core change (edit `public-landing/`, ship, release), not an out-of-band push to a foreign repo.

**3. The proxy keeps exactly three jobs on the landing surface:** terminate TLS, enforce any pre-launch `basic_auth` lock, and hide anything the bundle ships but should not expose (the gate's own `README.md` — an `@hidden` matcher for `*.md`/`*.json`/`*.py` and the brand-pipeline `proof`/`refs`/`references` paths). These are deployment-environment concerns, correctly the proxy's; everything else is the app's.

## Consequences

**Good**

- **One source of truth.** The landing bundle exists once, in the core, versioned with everything else. The foreign-repo checkout becomes dead weight (retired by L06, [#1002412](https://example.com/builders#/task/1002412)).
- **Portable.** Any instance that ships a `public-landing/gate/` gets the gate with a stock proxy block. L02 already guards this: the apex `/` → `/gate/` redirect only engages when the instance actually ships a gate, so a gate-less instance keeps its plain placeholder.
- **Atomic + rollback-able.** The landing and the app that serves it move together on one pin. Rolling the core back rolls the landing back with it.
- **Smaller proxy config.** No `root`, no `file_server`, no filesystem path in the site block — so a moved or re-cloned checkout can no longer silently change what the front page serves.

**Costs / risks**

- **The landing is now in the app's request path.** A dead app means a dead front page, where previously Caddy could still serve static files. Accepted: the front page's whole purpose is to reach the app (sign-in, project creation, the live featured-projects feed that fills the orbs), so a dead app already meant a useless landing.
- **A landing tweak needs a core release.** Slower than pushing to a static checkout. That is the point — the landing is now under the same review and versioning as the rest of the platform.
- **The `@hidden` guard is load-bearing and hand-maintained.** It is what keeps `gate/README.md` unreachable. If the landing bundle ever gains a file that should not be public, the matcher must keep up. Better long-term fix: don't ship non-public files in `public-landing/` at all.

## Alternatives considered

- **Keep file-serving, but from the core's `public-landing/` instead of the foreign checkout.** Would have removed the cross-repo coupling with a one-line `root` change. Rejected: it hardcodes a `node_modules/@bongos/core/...` path into the proxy config, which then breaks on any packaging-layout change, and it keeps the landing a special case in a config the core cannot ship.
- **Write the landing its own Caddy config + deploy script, as originally scoped.** Rejected: it builds a second deploy path to maintain, for an artifact that already ships inside the core package and already has one.
- **Serve the landing from a CDN / object store.** Rejected: the gate is not fully static — it calls the instance's own API for the featured-projects feed and the sign-in state — and it adds a service and a cost for a page the app can serve for free.

## Verification

The cutover was verified against the live reference instance:

- Every landing path returns an identical status code before and after the flip, across the apex and both vanity doors — including the staging lock (`401` on `/gate/*`), the `@hidden` guard (`404` on `/gate/README.md`), and the proxied functional paths (`/healthz`, `/docs`, `/create`, the featured-projects feed).
- The app's redirects are **relative** (`Location: /gate/`), so proxying them leaks no internal origin.
- **Severance test:** with the foreign repo's landing folder moved aside entirely, the site continued to serve the byte-identical gate (same md5, same 34,366 bytes) and every asset, proving the dependency is genuinely cut rather than merely unused.
