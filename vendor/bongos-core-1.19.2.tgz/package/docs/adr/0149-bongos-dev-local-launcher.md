# 0149 — `bongos dev`: a one-command local launcher for a standalone instance

- **Status:** Accepted (owner decision — "we need a better option to stand up the local host").
- **Date:** 2026-07-19
- **Deciders:** Lars (owner) — chose a one-command local launcher over a cloud dev box or a recipe-only fix.
- **Extends:** [ADR 0108](<redacted>.md) (a standalone instance repo pins the core as a dependency), [ADR 0062 §5](<redacted>.md) (the core owns its own pool + branding). Sibling of `local-preview-lib.js` (task 1056 — the game-only local sandbox) and `onboard`/`provision.js` (the *cloud* standup path).

## Context

The project-creation flow scaffolds a repo whose `config/branding.json` points at `http://localhost:<port>` (each new project gets its own auto-incremented port — the trial produced test3→`:3005`, test4→`:3006`). The repo is **configured** to run on the owner's own machine, but the platform shipped **no command that actually starts it there**.

An owner who cloned a fresh project hit a wall (session export, 2026-07-19): `npm install` works, but then standing the instance up by hand is a six-part assembly — install + start Postgres, `createdb`, run migrations, export `PORT`/`PGDATABASE`/`PGHOST`/OAuth env, launch the server — before `bongos login` can even connect. The guided command that *does* exist, `bongos onboard`, provisions a **cloud** server (needs a public domain + DigitalOcean/Cloudflare tokens); the Docker path (`docs/recipes/self-host.md`) runs a **vanilla** brand on `:3000`, not the repo's brand on its own port. So *local-on-your-Mac* — exactly what a freshly-created project is configured for — was the one unsupported path.

Three silent mismatches made the manual path especially error-prone:

1. **Port.** `src/platform-server.js:44` reads `PORT` from env and **ignores branding** — so the server comes up on `3000` while branding (and every printed link) says `:3006`.
2. **DB name.** The server pool falls back to the OS username (`src/bongos/pool.js:47` via `instanceDbName()`, which is `null` in a fresh pack), while `scripts/migrate.sh:52` defaults to `example`. They only agree if `PGDATABASE` is set for **both**.
3. **Socket.** node-pg defaults to the Linux peer socket `/var/run/postgresql` (`pool.js:46`), which does not exist under Homebrew Postgres on a Mac — you must set `PGHOST`.

A fourth failure was operational: the manual server ran **unmanaged in the background**, so a stale server for one project (`:3005`) was still answering when the owner tried the next project — they signed into the wrong instance by accident.

## Decision

Ship **`bongos dev`** — one idempotent command that stands up *this* instance locally and hands off to sign-in.

```
bongos dev            up: Postgres → createdb → migrate → server → sign-in
bongos dev stop       stop the background server this launched
bongos dev status     is it up? what URL? is sign-in configured?
```

`bongos dev` (default) runs, in order:

1. **Preflight** — `psql`/`createdb`/`pg_isready` present (clear `brew install` guidance if not); `bash` present for migrations.
2. **Postgres up** — if not running, start it (Homebrew `postgresql@N`, else `pg_ctl` with `PGDATA`), poll until ready.
3. **`createdb`** the instance's database if absent (migrate.sh does not create it).
4. **Migrate** — run the core `migrate.sh` with `MEDUSA_GDS_ONLY=1` (a fresh local instance never wants OTB's instance seeds).
5. **Start the server** DETACHED but **managed** (pid/log keyed per instance), poll `/healthz` + `/api/gds/healthz`.
6. **Sign in** — if creds resolve and the machine isn't already signed in to this instance, run `bongos login <origin>`; otherwise print the exact command (`--no-login` skips).

**It resolves the three mismatches from one source of truth (branding):** `PORT` = the port in `domains.publicOrigin`; `PGDATABASE` = `db.database` → repo dir name → `cloudbongos_dev`, exported for **both** migrate and the server; `PGHOST` defaults to TCP `localhost` (an explicit env override still wins). The pure resolution + process management live in `scripts/gds/dev-lib.js` (fully injectable, unit-tested in `tests/dev_lib.mjs`); the side-effecting orchestration is `scripts/gds/dev.js`.

**Managed-not-orphaned** is the fix for the wrong-instance accident: the background server has a pid/log keyed per `(dbName, port)`, so `bongos dev status`/`stop` make it visible and killable and a re-run is a no-op. `--foreground` runs it attached (Ctrl-C lifecycle) for those who prefer it.

**The one irreducibly-manual step** — a GitHub OAuth App — is only surfaced when no creds resolve (env `<PREFIX>_GITHUB_CLIENT_ID/SECRET` or `~/.config/<configDir>/gds-github.json`, mirroring `auth.js:loadGithubCreds`). A machine that already ran another instance carries usable creds and skips it entirely.

## Alternatives considered

- **Cloud dev box** (`bongos box` + `bongos code`) — the platform's blessed remote-dev model, but it needs the project *hosted* first and adds cloud cost; overkill for "try this project on my Mac." Rejected by the owner for the local case (still the right answer for remote/multi-machine work).
- **Docker** (`self-host.md`) — real, but serves the *vanilla* brand on `:3000`; matching the repo's brand + port needs a `docker-compose.override.yml` and a port change, and Docker Desktop is heavy for a non-technical owner. Kept as the Windows / container path.
- **Recipe only** (no command) — fastest, but leaves the six-step assembly and the three mismatches in the owner's hands every time. Rejected; the recipe ([`docs/recipes/local-dev.md`](../recipes/local-dev.md)) now just documents `bongos dev`.

## Consequences

- A freshly-created, localhost-configured project goes from `git clone` to a running, signed-in instance with `npm install` then `bongos dev` — no manual DB/env/port work.
- Windows is not covered by the native path (migrations need `bash`); those users take the Docker path. Noted in help + the recipe.
- `bongos dev` runs a repo verb (needs the installed core), so it is **not** bundled into the standalone on-ramp binary — it needs a real checkout + `npm install`, which the flow already has.
