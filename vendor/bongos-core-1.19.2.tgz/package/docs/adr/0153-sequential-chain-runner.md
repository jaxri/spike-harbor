# ADR 0153 — Sequential chain execution: one kickoff walks a dependency chain

- **Status:** accepted
- **Date:** 2026-07-28
- **Task:** 1002484
- **Relates to:** [ADR 0015](<redacted>.md) (dependencies + auto-promotion), [ADR 0049](<redacted>.md) (the split parallel-safety contract), [ADR 0086](<redacted>.md) §5 (polymorphic dependency edges)

## Context

ADR 0015 made `dependencies[]` load-bearing: a task cannot be claimed until its predecessors ship, and shipping a task auto-promotes its now-unblocked dependents `backlog`→`ready` (the `promote_dependents_on_ship` trigger, migrations 020/163). That machinery works. What it does not do is **pick the newly-unblocked task up**.

The result, measured on the live instance on 2026-07-28: **146 of 303 open tasks sit behind a predecessor, and only ~79 are `ready`** at any moment. A single planning seed like goal 1000045 fronts a 24-task chain worth 1,440 credits and ~62 hours. Working it meant 24 separate human kickoffs — each one a fresh session that had to re-derive what was now claimable.

The only "sequential" affordance was `<redacted>` in `modules/hall-ui/public/work.js`: a clipboard template listing manually multi-selected tasks in topological order. Two problems. It is *text*, not execution. And the tasks a chain most needs to queue — the dependency-gated successors — are not selectable on the board at all, because they are still `backlog`.

Two builders asked for this independently: idea 1000461 (jaxri — workflows that run tasks "in parallel or sequentially") and idea 1000398 (IAMMASTERQUA — chains as the claimable unit, priced by total chain value).

## Decision

Ship a **chain runner**: one kickoff walks a dependency chain end to end.

**1. No schema change.** The ordering already exists in the polymorphic `dependencies` table, the `task_is_fully_unblocked` predicate, and the promote-on-ship trigger. `GET /tasks/:id` already returns `dependencies[]` and `dependents[]`. Adding a `queue`, `chain_id`, or `next_task` column would create a second, drift-prone source of truth for an order the graph already encodes. The runner derives the chain on demand and stays stateless.

**2. No new claim guard.** One-active-claim-per-session is keyed on the *working tree* (`shouldRefuseSessionClaim`, `modules/lifecycle/routes/claims.js`), so ship-before-next-claim is already enforced — which is exactly the sequential shape. The chain therefore claims **one task at a time**, and a task is always fully `shipped` before the next is claimed. Batch-claiming a chain is not merely discouraged, it is impossible: successors fail `DEPS_NOT_SHIPPED` by construction, because their predecessor has not shipped yet. The ship *is* the thing that unblocks the next step.

**3. Split deterministic plumbing from judgement.** `scripts/gds/sequence.js` resolves scope, orders it, and evaluates a halt matrix — all from facts on the task row, no model judgement. `.claude/skills/builder-sequence/SKILL.md` owns the loop and defers to `/builder-claim`, `/dev`, and `/builder-ship` for their existing mechanics. A halt is a named reason with a non-zero exit code, not a narrative.

**4. Halt, do not skip** (owner decision, 2026-07-28). When the next task is something the runner should not decide alone, it **stops and reports**, leaving that task claimed. It does not ship a half-finished task, and it does not skip ahead to the next unblocked sibling.

The halt matrix: `needs_migration`, `security_sensitive`, `protected_path` (touches[] ∩ `PROTECTED_GLOBS`), `rank_floor`, `thin_spec`, `judgement_kind` (`decision`/`spike`), `not_claimable`, `deps_unmet`, `in_flight`, `cycle`. The skill adds two it must detect itself: `ship_failed` and `scope_surprise`.

## Why halt rather than skip

Skipping looks like the higher-throughput option and is not. In a dependency graph, a skipped task is a *predecessor* — skipping it strands everything behind it, so the run continues while quietly guaranteeing that the rest of the chain cannot complete. The apparent progress is the dangerous part: a run that skipped three tasks and shipped nine reads as a success until someone asks why the chain never finished.

Halting also makes unattended running safe, which is the whole point of one kickoff. The owner can start a chain and walk away knowing the failure mode is "stopped early with a reason", not "made twelve judgement calls you have not seen yet".

## Consequences

- A chain of N mechanical tasks now costs one kickoff instead of N.
- Chains stop silently stranding: a halt names what a human must do, so the queue does not just quietly stop advancing.
- The halt matrix is deliberately conservative. Tasks with thin specs will halt runs, which is a **feature** — it turns "the runner stopped" into pressure to write acceptance criteria at planning time.
- `not_claimable` defers to the server's own claimable feed rather than re-deriving its filter client-side. If that endpoint is unreadable the runner stays quiet rather than halting on everything — an early bug where the envelope key was misread (`tasks` vs `claimable`) turned an empty result into a universal halt, and the null-vs-empty distinction is now covered by a test.
- **Not built:** chains as a priced, claimable unit on the Tasks board (idea 1000398). The runner is the capability; surfacing chains with their total value is a separate, additive change.

## Alternatives rejected

- **A `chain_id` / queue table.** A second source of truth for an order the dependency graph already encodes, and one that drifts the moment an edge is added.
- **Batch-claim the whole chain up front.** Impossible under the dep gate, and it would defeat the isolation that makes each ship safe.
- **Let the runner use judgement and keep shipping** (the third option the owner was offered). Faster, but it moves review after the fact — the owner would be auditing decisions that had already landed.
- **Extend `overnight-builder`.** That routine walks the claimable queue by priority across the whole backlog; this walks one bounded chain the user pointed at. Different scope, and the routine is instance-only (absent from the portable core).
