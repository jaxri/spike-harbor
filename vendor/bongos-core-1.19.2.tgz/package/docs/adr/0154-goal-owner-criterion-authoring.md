# 0154 — A goal's done-when criteria are authored by that goal's owner or managers

- **Status:** Accepted
- **Date:** 2026-07-29
- **Deciders:** Lars (owner / Archon), Claude

**Builds on / amends:** [ADR 0086](<redacted>.md) (the goal tier — this ADR extends its owner/manager authority to the goal's criteria), [ADR 0090](<redacted>.md) (Metic task authoring), [ADR 0106](<redacted>.md) (owner vs manager), [ADR 0105](<redacted>.md) (why this route exists at all), [ADR 0016](<redacted>.md) (server-enforced rank boundary — unchanged), [ADR 0151](<redacted>.md) (permissions-as-atom — and see §5, which corrects one of its rows).

**Track:** `internal` (GDS / methodology). Task [1002538](https://cloudbongos.com/builders#/task/1002538), under the **Builder experience** goal [1000025](https://cloudbongos.com/builders#/goal/1000025).

---

## Context

The Metic planning loop is complete except in one place. A Metic may create a goal ([ADR 0086](<redacted>.md): `POST /goals` is `requireRank('metic','archon')`), author the tasks under it ([ADR 0090](<redacted>.md)), wire their dependencies and criterion links, and **confirm** a criterion when the work lands ([ADR 0086](<redacted>.md) §6 re-ranked `POST /done-when/:criterionId/satisfy` to Metic+ "so the planner — not only the Archon — closes the criterion/goal loop").

But they could not **create** the criteria those tasks are measured against: `POST /versions/:id/done-when` was `requireRank('archon')`. So a Metic could stand up a goal, fill it with work, and close its criteria out — but had to ask an Archon to write them in the first place. That is the one Archon-shaped hole in an otherwise Metic-complete loop, and it is what blocked `/goal-create` ([1002540](https://cloudbongos.com/builders#/task/1002540)) from being a skill a Metic can actually run end to end.

### Why the obvious fix — a flat re-rank — is wrong

The tempting move is symmetry: a Metic may confirm a criterion, so let them create one. That argument does not survive contact with what a criterion *does*.

**Creating an unsatisfied criterion is a backward ratchet, and there is no undo.** Every "is this done" aggregate counts unsatisfied rows:

- `modules/lifecycle/version-close.js` gates on `criteria.satisfied === criteria.total`, counted **per version regardless of goal**. One unsatisfied row parks the version's close suggestion indefinitely — and that suggestion is served on the **unauthenticated** `GET /versions/close-suggestions`, so it is publicly visible.
- `db.achieveGoalIfComplete` refuses while `unsatisfied > 0`, so the goal never auto-achieves, and `promote_dependents_on_goal_achieve` never releases the tasks waiting on it.

That is operationally the same effect as `POST /done-when/:criterionId/unsatisfy` — which is Archon-only, and which `docs/governance/<redacted>.md` lists in the same Archon "Lifecycle disposition" line as this route. And there is **no DELETE route for a criterion**: descoping is direct SQL under a claim. A mistake is not correctable through the API by anyone.

**The create path also had no ownership check whatsoever.** Its entire authorization surface was `requireBuilder` → `requireRank` → version exists → (if `goal_id` given) the goal belongs to that version. That last one is referential integrity, not authority. Every *other* goal-touching write in the module runs `authorizeGoalManagement` (owner | manager | Archon) or `authorizeGoalTaskCreate` (membership + scope wall). A flat re-rank would therefore have let any Metic attach a permanent, un-deletable criterion to **any goal on any version**, including goals they had never joined and private goals ([ADR 0112](<redacted>.md)) — published to the anonymous status feed.

`docs/canonical-permissions.md` named "set version scope (`done-when`)" as Archon-exclusive. A flat re-rank contradicts that flatly; the decision below narrows it instead.

## Decision

**Authority over a goal's criteria follows goal ownership, not global rank.**

`POST /versions/:id/done-when` becomes `requireRank('metic','archon')`, plus an **ordered, fail-closed in-handler wall** for any non-Archon:

| Step | Refusal |
|---|---|
| a `goal_id` must be named | `403 goal_id_required` |
| the caller must be the goal's **owner or a manager** | `400 bad_goal_id` — **masked**, see below |
| the goal must be `open` | `409 goal_not_open` |
| the version must be open (`planning` or `building`) | `409 version_closed` |

An Archon short-circuits all four: version-level (goal-less) criteria, goals in any state, and versions in any state stay theirs.

The authority predicate is `isGoalOwnerOrManager` — the **same** owner-or-manager test behind visibility changes, invitations, join-request responses, member roles and conflict resolution. It moved from `modules/lifecycle/routes/goals.js` to a module sibling, `modules/lifecycle/goal-authz.js`, so both routes share one definition of "who holds this goal"; `authorizeGoalManagement` is rebuilt on it and re-exported from `routes/goals.js`, so its existing DB-free tests are untouched. No route requires another route.

### Authority is checked before state, and the refusal is masked

Ordering matters here in a way it does not for the sibling goal routes. Those are reached by callers who already know the goal exists (they are looking at it); this one takes an arbitrary integer `goal_id` from any Metic.

If the refusals were distinguishable — `400 bad_goal_id` (no such goal) vs `403 not_owner_or_manager` (exists, not yours) vs `409 goal_not_open` (exists, settled) — the route would be an **existence oracle**: a Metic could enumerate `goal_id`s and learn which exist on a version, including **private goals** ([ADR 0112](<redacted>.md)). That surface did not exist while the route was Archon-only, because an Archon can already read every goal. Re-ranking it creates the surface, so the re-rank has to close it.

So the ownership test runs **ahead of** both state checks, and a caller who fails it gets byte-identical `400 bad_goal_id` to one naming a goal that does not exist — same code, same message, same envelope, rendered by the same `badGoalId()` helper the genuine-absence branch uses. Only someone who already holds the goal learns anything further about it. This mirrors the O1 no-leak ordering the goal abuse matrix already pins (`not_a_member` is returned before any scope hint).

**What does not move.** `POST /done-when/:criterionId/unsatisfy` stays Archon — un-flipping a *confirmed* criterion rewrites shipped scope-truth, and keeping the backward ratchet at the top rank is the safety this grant is paired with. It was previously **unpinned** in `route-rank-check`; this ADR pins it at `archon` so a silent downgrade reds the build.

### Why this is the right boundary

Creating a criterion inside a goal you own is not scope-*truth* authorship in the sense the Archon gate was protecting — it is describing the finish line of a workspace you are already accountable for. The blast radius is bounded by something the actor already holds. Creating a criterion at the *version* level, or inside someone else's goal, still shapes the project's scope for other people, and that stays Archon.

## Consequences

- `/goal-create` becomes genuinely Metic-runnable: create the goal → write its criteria → seed its tasks, in one session, without an Archon in the loop.
- A Metic can still park **their own** goal by adding a criterion they never satisfy. That is a self-inflicted wound inside their own workspace, visible in `/goal-review`, not an attack on anyone else's.
- The proposal → ratify queue (`kind='criterion-proposal'` → `POST /inbox/:id/ratify`, Archon-only) remains the path for **version-level** criteria and for anyone who is not the goal's owner. It is no longer the only path for a goal owner describing their own goal. Note the direct path writes one row and awards no `proposal_ratified` karma and no `criterion_proposal_audit` provenance — proposals remain the richer, attributable route, and the one an Archon adjudicates.
- Five generated artifacts regenerate (`docs/api/openapi.json`, `docs/api-reference.md`, `docs/routes-permissions.md`, `clients/bongos-client/*`), because the rank flows into the published contract via the `// rank:` annotation.

## §5 — A correction to ADR 0151's catalog

[ADR 0151](<redacted>.md)'s "floor `metic` today" table bundles three routes into one row:

> `criterion.satisfy` / `criterion.review` | `POST /done-when/:id/satisfy`, `GET /done-when/pending-review`, `POST /versions/:id/done-when`

Two of those were Metic; the third (`POST /versions/:id/done-when`) was **Archon** at the time that table was written. 0151's own cited source — the exhaustive `docs/governance/<redacted>.md` — lists it correctly under Archon. The bundled row was a transcription slip, and it was latent-dangerous: 0151's R94 compat seed grants "exactly today's powers," so seeding from that row would have handed the `metic` role an Archon route, and R103's parity test would either have gone red or, worse, ratified the escalation.

This ADR makes the row's *outcome* correct but for a different reason, so the row is split anyway: `criterion.create` is its own atom, floor `metic`, **qualified by the goal-ownership wall above** — a floor alone does not describe this permission.

## Alternatives considered

- **Leave it Archon; use the proposal queue.** Rejected: it keeps the Archon in the loop for a Metic describing a goal they own, which is the janitorial-delegation problem [ADR 0152](<redacted>.md) already named. The queue survives for the cases that genuinely need adjudication.
- **Flat re-rank to Metic+.** Rejected — §Context.
- **Add a DELETE for criteria so the ratchet has an undo** (the [ADR 0152](<redacted>.md) "pair the grant with its inverse" pattern). Deferred, not rejected: it is the honest completion of "manage," and it would neutralise the no-undo objection directly. It is a new capability nobody has today — including Archons — and deleting a criterion with linked `task_criteria` rows needs its own cascade decision. Worth its own task.
