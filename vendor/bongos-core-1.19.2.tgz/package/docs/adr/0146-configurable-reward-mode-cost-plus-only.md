# ADR 0146 — Configurable reward mode: `cost-plus-only` (retire the per-task estimate payout per-instance)

**Date:** 2026-07-16
**Status:** Accepted
**Discipline:** engineer (GDS / economy)
**Task:** [#1002270](https://cloudbongos.com/builders#/task/1002270) (BONGOS-V1, under goal 1000037)

## Context — the problem

A shipped task pays a builder from **two reward streams that land on the same balance**:

1. **The per-task ESTIMATE** — `credits_reward × kind multiplier` ([ADR 0023](<redacted>.md)). A **unitless author estimate** set when the task is authored (or auto-assigned by the no-zero-reward backstop, ADR 0096). It is what a builder sees advertised at claim time, and — since [ADR 0120](<redacted>.md) — it books at ship as `credit_log.reason = 'task.shipped'`, plus a 25% idea-promotion slice ([ADR 0023](<redacted>.md)) to the idea's original capturer.
2. **The cost-plus SESSION reward** — `round(true_cost_usd × 1.20)`, 1 drachma = $1 ([ADR 0054](<redacted>.md)). Grounded in the session's **real API spend**, booked as `session.token_reward`.

[ADR 0054](<redacted>.md) named this the **"two drachma conventions, one ledger"** tension and explicitly flagged reconciling them as a deferred future-review trigger: one stream is unitless bounty points, the other is dollars, and they are summed into one `total_credits`. Goal 1000037 changed only *when* both pay (on land), never *whether* both pay.

The owner's stated intent for Cloud Bongos is that **a credit means one dollar of cost-plus value and nothing else**. Under the two-stream model that is not true — roughly half of a shipped task's payout is the arbitrary estimate. The owner asked to make the cost-plus reward the **sole** equity reward for Cloud Bongos, and for that choice to be **configurable in the economy module** (so other instances are unaffected and can choose differently).

## Decision

Add a per-instance reward **mode** to the existing reward policy, resolved by the economy module.

- **Config:** `branding.reward.mode` — a new field beside the existing `{ marginPct, usdPeg }` ([the branding contract](../branding-contract.md)):
  - `"cost-plus-and-estimate"` — **the default.** Pay both streams, exactly as before. Every existing instance keeps its current behavior on upgrade with no config change.
  - `"cost-plus-only"` — the cost-plus session reward is the **sole equity reward**; the per-task estimate payout is withheld.
- **Resolution + gate — entirely inside the economy module** (`modules/economy/credits.js`):
  - a new **pure** `rewardPolicy(rawReward)` maps the raw branding object → `{ marginPct, usdPeg, mode, perTaskCredit }`, where `perTaskCredit = mode !== 'cost-plus-only'`. `rewardConfig()` delegates to it. (Mirrors the pure/impure split of `computeSessionTokenReward`, so the mapping is unit-testable without touching the memoized `branding()` cache.)
  - `insertMultipliedConfirmCredit(...)` — the **single** writer of the per-task estimate credit — short-circuits to a zero return (**no `credit_log` INSERT**) when `perTaskCredit` is false. Its `config` argument defaults to the resolved `rewardConfig()`; the sole live caller (`lifecycle` `awardLandingCredit`) omits it and gets the resolved instance policy per call.
- **The idea-promotion slice cascades automatically.** `awardLandingCredit` passes the (now `0`) `creditsAwarded` into `maybeAwardIdeaPromotionBonus`, which already no-ops on a non-positive base — so a fraction of an unpaid estimate is correctly `0`, with **zero lifecycle changes**.
- **The estimate is preserved as an advertised guide, not a payout.** `tasks.credits_reward` still rides the row: it is shown at claim time and still drives the no-zero-reward claim gate (ADR 0096). Only the *payout* is suppressed.
- **Fail-safe default.** An unknown / garbage `mode` resolves to the default (pay both). A config typo can never silently zero out every builder's per-task reward.

**Cloud Bongos selects `cost-plus-only`.** Other instances (including the reference founder instance) keep the default and are untouched.

## What this does NOT change

- **The cost-plus session reward** — untouched. Same formula, same `marginPct`/`usdPeg`, same `session.token_reward` path. In `cost-plus-only` mode it is simply the only equity stream.
- **Achievements and the net-negative (+1 simplification) ship bonus** — deliberately **out of scope**. They are a separate, small behavioral-nudge category (badges + a symbolic +1), not the per-task estimate. If a future owner wants literally *nothing but* cost-plus, gating those is a one-line follow-up; this ADR does not.
- **The `KIND_MULTIPLIERS` table and `credits_reward` semantics** — unchanged. The multiplier is still computed (for the return shape / audit) even when the payout is withheld.

## Consequences

- **Backward-compatible by construction.** Absence of `mode` ⇒ default ⇒ current behavior. No migration, no data change.
- **Reversible.** Flipping `mode` back to the default resumes per-task payouts from the next ship; nothing is destroyed. (Historical rows are untouched — this is not a clawback; see [ADR 0120](<redacted>.md) part 4 for the separate one-time backlog re-gate.)
- **Builder-facing expectation gap (follow-up).** ~~In `cost-plus-only` mode the "Est." shown at claim time is a *guide*, not a promise — the builder is actually paid the cost-plus amount. Surfacing "this instance pays cost-plus only" in the hall / claim UI is a captured follow-up idea, not part of this task.~~ **Resolved by task [#1002469](https://cloudbongos.com/builders#/task/1002469).** The gap was not theoretical: it cost a real session on 2026-07-26, where a correct `Credits +0` was diagnosed as a broken reward gate. The resolved policy is now exposed on the `reward` port (`rewardConfig`), projected onto `clientBranding()` for the hall and returned on `GET /me` + `POST /claims` for the CLI — **the CLI must take it from the server**, since an instance's `config/branding.json` is not in a builder's checkout and a local read always reports the paying default. Claim, `/builder-start`, the ship card, and the hall now label the estimate as an estimate and name the real payer. The hall fix also closed a live misread: `taskCreditValue` falls back to the estimate when a settled task has `credits_awarded === 0` — which under `cost-plus-only` is *every* shipped task — so the plain label was presenting an unpaid estimate as the actual ledger payout.
- **The two-conventions tension is resolved for `cost-plus-only` instances** (one dollar-denominated stream) and left intact for default instances — the ADR 0054 trigger is addressed by *config*, not by forcing one model on everyone.

## Alternatives considered

- **A boolean `reward.perTaskCredit`** instead of a `mode` enum. Rejected: `"cost-plus-only"` reads self-documentingly at the config site and in prose (it is the vocabulary the decision was made in), and the enum extends cleanly if a third policy is ever wanted. The code derives the boolean internally.
- **Gate in the lifecycle (`awardLandingCredit`) via a port predicate.** Rejected: it would spread economy policy across the kernel↔module boundary. The knob belongs *inside the economy module* (the owner's explicit ask); gating the single credit writer keeps it there and needs no lifecycle change.
- **Remove `credits_reward` / stop advertising an estimate entirely.** Rejected: the estimate is still useful as a claim-time guide and is load-bearing for the no-zero-reward claim gate. Suppress the *payout*, keep the *signal*.
- **Make the cost-plus reward the only stream globally (no knob).** Rejected: the core ships to instances that may legitimately want the bounty-style per-task reward. A per-instance knob with a backward-compatible default respects the core ↔ host split (ADR 0062 §7).
