# 0158 — The choke-point verdict taxonomy, and why a verdict never executes itself

- **Status:** Accepted
- **Date:** 2026-08-06
- **Deciders:** jaxri (Archon), Claude
- **Track:** `internal` (GDS / methodology)
- **Task:** [1002598](https://cloudbongos.com/builders#/task/1002598), under goal [1000024](https://cloudbongos.com/builders#/goal/1000024) (Build-pipeline integrity)

**Builds on:** [ADR 0016](<redacted>.md) (the server-enforced trust boundary — **unchanged**), [ADR 0043](<redacted>.md) (the out-of-band substrate), [ADR 0151](<redacted>.md) (permissions as atoms), [ADR 0157](<redacted>.md) (the delegation this taxonomy generalises the *reasoning* of).

**Produces:** [`docs/governance/<redacted>.md`](../governance/<redacted>.md).

---

## Context

ADR 0157 delegated 20 permissions from Archon to Metic on a specific observation: each had been
Archon-gated by ADR 0016's fail-closed default, *never by a decision*. That reasoning was applied once,
in bulk, to a known backlog. It was not written down as a **method** — so the next person facing the
same question has to rediscover it.

Two things made the question tractable in 2026-08, and both are new:

1. **A second Archon exists.** Until 2026-08-06 there was exactly one, so *"needs an Archon"* and
   *"needs Lars"* were the same sentence. They are now different sentences, and a large share of past
   escalations reclassify on that distinction alone.
2. **The floor is declared once.** Post-ADR-0151, a floor lives in `modules/governance/catalog.js`
   rather than at 41 call sites, so classifying a wall is cheap enough to do exhaustively.

The audit that produced the choke-point map found that the hard part is not *locating* walls — greps
and route censuses do that. The hard part is deciding whether a located wall **belongs there**, and
the codebase actively misleads on that question. Four comments and doc passages were found stating
something the code does not do: two justify a live fail-open on a premise that has since become false
(**D-4**, **D-6**), one asserts an enforcement mechanism that has never existed in the repository
(**D-2**), and one misstates its own fail-direction, claiming a permissiveness the code does not have
(**D-5**). A method that reads the code's self-description gets the wrong answer — in both directions.

It also found the reverse failure. Three walls the trust model describes as live are not enforced at
all (**G-2**, **G-3**, **G-6**), and one is enforced by a mechanism other than the one the model names
(**G-7**). "Where is the wall?" and "what does the model claim about the wall?" are independent
questions and must be answered independently.

## Decision

### 1. Six verdicts, ordered, first match wins

| Verdict | Test | Remedy shape |
|---|---|---|
| **GAP** | Nothing enforces this where the trust model implies something should | Add the gate at the correct floor |
| **UNINTENDED-MISSING-SURFACE** | The rank *should* be able to do this, but no API path exists at all | Add the endpoint at the rank already granted |
| **DRIFT** | Docs and code, or two code paths, disagree about where the wall is | Fix the wrong side, add a regression check |
| **STRUCTURAL** | Needs a resource only the human owner holds — money, legal identity, a credential | Owner acts, or pre-delegates a scoped credential |
| **INTENDED** | The wall sits exactly where the stated trust model says | None — but reduce friction if hit often |
| **UNINTENDED-OVERTIGHT** | A real wall, gated higher than the model's own intent requires | Lower the floor: code + migration + ADR |

**Order is load-bearing.** GAP precedes everything because an unenforced wall is not a floor question
at all — arguing about its rank while nothing enforces it is the more expensive mistake.
UNINTENDED-OVERTIGHT is last because it is the only verdict whose remedy *weakens* a boundary; it must
never be reached by default, only after the five cheaper explanations are excluded.

**DRIFT is never terminal.** A DRIFT row must name the category it collapses into once resolved.
Otherwise "the docs disagree" becomes a place findings go to be filed and forgotten.

### 2. A verdict is advisory and never self-executing

**This is the load-bearing rule of this ADR.** Recording `UNINTENDED-OVERTIGHT` is **not**
authorization to lower a floor. It is a finding that a floor *may* be wrong, addressed to a human.

Lowering a floor still requires, in order: an owner decision, a `catalog.js` change, a migration (the
`governance_002` compat seed is run-once, so an edited `floor:` never reaches an already-migrated
database — ADR 0157 §Consequences), and an ADR recording why. A governance document that could move a
floor by asserting a verdict would be a privilege-escalation path through markdown — precisely what
ADR 0016 exists to prevent. **The audit describes; the database enforces.**

The same rule inverted: a verdict of `INTENDED` does not immunize a wall from later review, and
`GAP` does not authorize adding a gate wherever seems reasonable. Both directions go through the same
door.

### 3. Every row carries a rigor marker

A verdict without evidence is an opinion. Four markers, and a row may not exist without one:

- **`obs`** — observed by executing the code path.
- **`read`** — established by reading the code, cited `file:line`.
- **`absent`** — established by the absence of a file, caller, or route. The negative *is* the finding.
- **`unver`** — cannot be settled from the checkout. Named explicitly, never guessed.

`absent` earns its own marker because the two most consequential findings in the first map are
absences — a hook that was never in git history, and an "authoritative" audit script with no caller.
Neither is visible to any technique that reads code that exists.

`unver` earns its own marker because the alternative is silent optimism. A map that quietly assumes an
unverifiable enforcement layer is running reads as *"secure"* when the honest reading is
*"unknown"*.

### 4. Rank is not identity — state the Archon count

An audit of this kind must record **how many Archons existed when it ran, and how many of them were
the owner**, because the classification depends on both. A choke point whose true cause was "only one
Archon existed" is **RESOLVED** by a second one existing — not an open remedy. Conflating the two
inflates the remedy list with work that is already done, and hides the real trust boundaries inside
the noise.

The second count is what keeps STRUCTURAL honest. "Requires Archon rank" is satisfiable by anyone the
owner promotes; "requires the owner" — money, a legal identity, a credential held by one person — is
satisfiable by exactly one, and **no rank change widens it**. Rank is grantable; being the owner is
not. An audit that collapses those two produces STRUCTURAL rows that a promotion would have cleared,
which is the same error in the opposite direction: it tells the owner they are needed when they are
not.

### 5. Two methodological constraints on any future probe

Both were discovered the expensive way and are cheap to honor:

- **An Archon cannot audit the ownership walls.** `gateTaskOwnership` short-circuits on
  `rank === 'archon'` before the ownership lookup, so an Archon-authenticated probe passes all 7
  routes it guards and observes no wall. Any probe **must** seed sub-Archon identities. This is also
  why the single-Archon era hid a whole class of wall rather than merely queueing it.
- **Send two bodies per write.** Of 29 in-handler-gated routes, 16 return `400`/`422` on an empty `{}`
  body *before* the authorization check. A `{}`-only sweep concludes there are no in-handler walls —
  the exact opposite of the truth. Send `{}` for containment and a schema-minimal valid body for
  classification, and assert the in-handler count is non-zero or treat the run as invalid.

### 6. An audit document carries no reproduction detail for an unpatched finding

An authority audit necessarily locates live flaws. Writing the *mechanics* of an unpatched one into a
repository document publishes a working recipe to whichever ranks can read that repository — which,
for a finding about sub-Metic builders, is precisely the population able to exploit it. The asymmetry
is stark: the finding's *existence* is what the owner needs, and the finding's *mechanics* are what an
attacker needs.

So: **existence, verdict, and severity go in the audit; reproduction goes in the security-report
surface**, which is gated on `security.report.adjudicate`. Once a finding is fixed, it may be
documented in full — the restriction is about the unpatched window, not about secrecy.

This rule was learned the hard way on the first map: the adversarial grader flagged its G-1 row as
information disclosure, correctly. Two facts made it land rather than stay contained — `docs/governance/`
is absent from `SENSITIVE_DOC_GLOBS`, so the search layer serves such documents at `xenos`, and
ADR 0035's Metic+ local-clone tightening has not shipped, so sub-Metic builders can hold a full
checkout. Neither is the audit's doing; both mean an audit cannot assume its own containment. **An
audit document must assume its most adversarial plausible reader is inside its stated threat model.**

## Consequences

- **The taxonomy is reusable.** The next authority audit classifies against this table instead of
  inventing categories, and its rows are comparable to the first map's.
- **Verdicts are safe to write down.** Because §2 makes them inert, an auditor can record
  `UNINTENDED-OVERTIGHT` honestly without the document becoming a lever. This is what lets the audit
  be blunt.
- **`absent` and `unver` are first-class.** Two of the highest-severity findings in the first map are
  absences, and the single sharpest structural finding is an `unver`: the layer ADR 0043 designates
  authoritative lives entirely outside the repository that documents it, so the trust model cannot be
  audited from the artifact that states it. A taxonomy without those markers would have recorded
  silence as safety.
- **ADR 0016 and ADR 0043 are untouched.** This ADR adds a vocabulary for *describing* the boundary.
  It moves no floor, adds no gate, and changes no enforcement.
- **A cost.** Hand-written verdicts do not regenerate. The map goes stale as line numbers drift, and
  its own "keeping this true" section is the only mechanism keeping it honest. That is accepted: a
  script can tell you where a gate is, never whether it belongs there.

## Alternatives considered

- **Generate the map from the route census.** Rejected. A census answers "where is the gate," which
  is the easy half. It cannot answer "should it be there," and a generated document would imply it had.
- **Fold the verdicts into `canonical-permissions.md`.** Rejected. That file is a mirror of the
  enforced model; mixing *judgments about* the model into the *description of* it is how a doc starts
  reading as authority. Kept in `docs/governance/`, which is explicitly interpretive.
- **Let an `UNINTENDED-OVERTIGHT` verdict open a task automatically.** Rejected, and it is the same
  hazard as §2 one step removed. An auto-filed task to lower a floor is a queued privilege change
  nobody decided. A human reads the map and files what they choose.
- **Three verdicts instead of six** (intended / not-intended / owner-only). Rejected: it collapses
  GAP into UNINTENDED-OVERTIGHT, which inverts the remedy. An unenforced wall needs a gate *added*;
  an over-tight wall needs a floor *lowered*. Merging them produces exactly the wrong action half the
  time.
