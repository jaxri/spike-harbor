# 0159 — Merge-gate reconciliation: required checks match reality, CODEOWNERS becomes real, protection stays the owner's switch

- **Status:** Accepted
- **Date:** 2026-08-08
- **Deciders:** jaxri (Archon), Claude
- **Track:** `internal` (build pipeline / governance)
- **Task:** [1002611](https://cloudbongos.com/builders#/task/1002611), under goal [1000024](https://cloudbongos.com/builders#/goal/1000024) (Build-pipeline integrity)

**Builds on:** [ADR 0042](<redacted>.md) (CI auto-merge; described Code-Owner review as a live control), [ADR 0058](<redacted>.md) (the gate-review phase plan — **unchanged**; its workflows remain planned), [ADR 0158](<redacted>.md) (the verdict taxonomy; findings D-12 and G-5 in the [choke-point map](../governance/<redacted>.md)).

---

## Context

The unit CI lane now exists (task 1002610): every PR and every push to `main` runs the DB-free
suite + the architecture fitness gates as a status-check context named exactly `unit`. Before
that task, no workflow could report any of the three contexts `gating.js` hardcodes as required.

Two findings remained:

- **D-12** — `gating.js` (the owner kill-switch for branch protection) hardcoded
  `required_status_checks` for `unit`, `trufflehog` and `gate-review`. Two of the three still
  have no workflow. Running `gating.js on` would require contexts nothing can report, blocking
  every merge indefinitely rather than gating them. The same misfire has a second shape: a
  required context that *reports red on every PR* also blocks every merge — and the lane's
  first-ever runs surfaced exactly that (three tests red in every clean environment, plus a
  shallow-clone break in the lane itself).
- **G-5** — no CODEOWNERS existed anywhere in the tree, while ADR 0042:77 describes Code-Owner
  review as a live control, `protected-surfaces.json` lists `CODEOWNERS` as a protected glob,
  `publish-manifest.js` excludes it from the public mirror, and `gating.js` claims in its own
  header to be "owner-gated in CODEOWNERS".

## Decision

1. **`DEFAULT_PROTECTION` requires only contexts that exist and can pass today — `[unit]`.**
   The planned contexts return to the baked-in default when their workflows ship, not before.

2. **The future check names are fixed now, deliberately:** `secret-scan` and `gate-review` —
   the names `adopt-preflight.js` (`CORE_EXPECTED_CHECKS`) and `init.js` already present as the
   core's contract. `trufflehog` (the tool) stops appearing as a context name; a context is
   named for what it asserts, not for the tool that asserts it, so the tool can be swapped
   without a branch-protection edit.

3. **CODEOWNERS becomes a real root file**, scoped to `gate-review.js`'s `HARD_FLOOR_GLOBS`
   (the surfaces whose auto-merge would disable the safety system itself) plus `gating.js`.
   It is inert until branch protection is on — GitHub enforces it only via
   `require_code_owner_reviews` — so shipping it changes nothing operationally today; it makes
   the already-written descriptions true and arms the owner's switch.

4. **Branch protection stays OFF, and flipping it on remains the owner's explicit act**
   (`node scripts/gds/gating.js on`). This task makes that switch safe to use; it does not use
   it. (An ADR 0158 principle applied: a finding's remedy is never self-executing.)

5. **The unit lane is hardened so `unit` is actually requirable:** `fetch-depth: 0` (the
   default depth-1 clone broke `tests/main_audit.mjs`, which resolves real first-parent ranges).
   Of the three tests red in every clean environment, two — `platform_boot` and
   `served_paths_shipped` — are parked in `KNOWN_FAILING` with per-test diagnoses in task
   1002617; `publish_manifest` guards the public-mirror boundary, so it was **fixed here
   instead of parked** (grader catch): its "must see ≥7 host tests" non-vacuity floor went
   stale the moment ADR 0107 moved the host-module tests into `modules/<key>/tests/`, and the
   floor is now a regex specimen self-test that cannot go stale with the module roster.
   Parking is quarantine with a tracked exit, not acceptance: the gate must be green on a
   good tree before it can be required on every tree.

## Consequences

- `gating.js on` now produces a protection config that gates instead of wedging. The owner can
  flip it whenever they choose; nothing forces the flip.
- When the `secret-scan` or `gate-review` workflow lands, its author must add the context back
  to `DEFAULT_PROTECTION` (the comment there says so) — until then the kill-switch's
  `GATE_WORKFLOWS` toggles no-op gracefully on the absent files.
- CODEOWNERS and `HARD_FLOOR_GLOBS` are now two expressions of the same set and must be kept
  aligned by hand when either changes; both files say so at the top.
- The two parked tests are the debt this ADR takes on; task 1002617 is the ledger entry.
- `audit-authorship.sh` allowlists CODEOWNERS: GitHub's format requires the literal
  `@username`, which is repo-hosting identity (the provision-staging.sh precedent), not a
  hardcoded builder identity.

## Rejected

- **Deleting `GATE_WORKFLOWS` / the gate-review references from gating.js** — the phantom-name
  objection (the G-20 shape) loses to forward compatibility here: the switch handles absence
  gracefully, ADR 0058's phase plan is unchanged, and removing the names would mean the
  kill-switch silently stops covering the gate workflows the moment they ship.
- **Stopping describing CODEOWNERS instead of creating it** — the describing surfaces
  (ADR 0042, the protected-surface registry, the mirror manifest, gating.js) all assume it as
  the one human backstop in an auto-merging pipeline; watering four descriptions down is more
  churn than making the one file real, and leaves the pipeline with no owner-review lever at all.
