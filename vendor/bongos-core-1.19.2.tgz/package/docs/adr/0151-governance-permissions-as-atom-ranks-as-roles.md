# 0151 — Governance: permissions as the atom, ranks as seeded roles

- **Status:** Accepted
- **Date:** 2026-07-24
- **Deciders:** Lars (owner / Archon), Claude
- **Track:** `internal` (GDS / methodology — a Cloud Bongos platform capability)
- **Task:** BV1.R90 ([#1001838](https://cloudbongos.com/builders#/task/1001838)) — the foundation of the BONGOS-V1 **Governance** goal ([#1000030](https://cloudbongos.com/builders#/goal/1000030)); settles the model in an ADR before any of R93–R114 build against it.
- **Builds on:** [ADR 0016](<redacted>.md) (the server-enforced HTTP trust boundary — **preserved untouched**), [ADR 0043](<redacted>.md) (the out-of-band git/ssh substrate + protected-path rank floor), [ADR 0062](<redacted>.md) (core ↔ host split), [ADR 0083](<redacted>.md) (modules), [ADR 0084](<redacted>.md) (auto-derived per-task rank floor), [ADR 0086](<redacted>.md) (goal-scoped hierarchy + cross-tier edges), [ADR 0090](<redacted>.md) (Metic authoring powers), [ADR 0106](<redacted>.md) (ownership authority).
- **Gates:** R91 (module key) · R93/R94 (tables + catalog code) · R95 (resolver) · R97 (`requirePermission`) · R98–R101 (principals / session-scopes / ownership / registry) · R96/R102 (core-host split) · R104–R109 (gate migration) · R110/R111/R113 (the tab) · R103/R112/R114 (proofs). This ADR is the decision those tasks implement.

---

## Context

Authority in Cloud Bongos is a **single rank threshold** today. [ADR 0016](<redacted>.md) put authority in one DB column (`builders.rank`), checked server-side per request with no caching; [ADR 0018](<redacted>.md) / [ADR 0034](<redacted>.md) wired the four live ranks into the ordered tier `xenos (1) < thetes (2) < metic (3) < archon (4)`. Every privileged route calls `requireRank(...allowed)`, which admits a builder whose rank sits **at or above** the lowest-authority rank named (a threshold, [#591](https://cloudbongos.com/builders#/task/591)). That design is sound and is **not** being replaced — it is the substrate this ADR builds *on top of*.

But a rank is an **all-or-nothing bundle**. There is no way to say "this builder may triage ideas but not author tasks," or to stand up a trusted reviewer who is not a full Metic, without inventing a new rank and threading it through a dozen-plus hand-copied tier maps (§Decision 2 counts 13). The owner wants a **Discord-style roles-and-permissions system**: configurable roles, assignable to builders, composed from granular permissions — where **permissions are the atomic primitive and ranks become seeded roles** — delivered with **zero day-one behavior change** and **without weakening the trust boundary** that is Cloud Bongos's one hard-to-copy moat ([ADR 0087](<redacted>.md): *compete on governance, not tooling*).

The 2026-07-03 governance planning session ([goal 1000030](https://cloudbongos.com/builders#/goal/1000030)) locked the shape and seeded the R90–R114 task chain against six done-when criteria (C1–C6). This ADR records the decision so those tasks build against **one** settled model instead of re-litigating it fourteen times, and it enumerates the **full permission catalog** (the appendix) grounded in the 2026-07-24 authority sweep of every server-side gate in the tree.

**What a rank threshold cannot express (the axes a role model must cover).** The sweep found four distinct *kinds* of authority already live in the code that a flat rank ladder flattens together:

1. **Rank-derived power** — `requireRank('metic')` and friends. The bulk. Maps cleanly to roles.
2. **Machine principals** — the BFG session-eval uploader and the Discord bot are gated on their **exact `system_role`** (`requireBfgPrincipal`, `requireDiscordBot` in `src/bongos/auth.js`), *not* rank: an Archon token is rejected because it carries `system_role = NULL`. A governance axis roles don't cover.
3. **Session-scopes** — a dev-box token (`session.source = 'box'`) is **deny-by-default**: it may reach only the routes that opted in via `allowBoxScope`, *regardless of how senior its builder is*. Capability attached to the session, orthogonal to the builder's rank.
4. **Ownership-scoped authority** — "act on **own** X" and "act on a goal you **own/manage**." Enforced today by in-handler pure gates (`authorizeMemberRoleChange`, [ADR 0106](<redacted>.md)) and by row-level ownership checks, not by `requireRank`.

A model that claims to be "the complete authority model" (criterion C3) has to represent all four.

---

## Decision

Six pillars, one per criterion.

### 1. Permissions are the atom; ranks become seeded roles (C1)

A **permission** is the atomic unit of authority — a stable string key (e.g. `idea.triage`, `task.create`, `builder.rank.set`) that maps to a real capability (a route, a claim rule, a page). Permissions are **defined in code, not UI-invented data**: because each key corresponds to an actual server capability, the catalog is a code constant that the resolver, the gates, and the tab all read from one place (R94). A permission that no route consumes does not exist.

A **role** is a named, assignable bundle of permissions (`governance_roles` + `governance_role_permissions`). A **builder** holds zero or more roles (`governance_builder_roles`).

The four live ranks become **four seeded roles** — `xenos`, `thetes`, `metic`, `archon` — whose grants reproduce today's rank thresholds **exactly** (the compat seed, below). `builders.rank` stays as the identity/graduation column it is today; the seed keeps each builder's role assignment in lock-step with their rank. Ranks do not disappear — they become the *default* roles a fresh instance ships, and the anchor the auto-graduation ([#692](https://cloudbongos.com/builders#/task/692)) and promotion ladder still move along.

A per-request, **uncached** resolver `resolveBuilderPermissions(builderId)` returns a builder's **effective permission set** = the union of their roles' permissions, read fresh on every request (R95). This preserves ADR 0016's single most important property — **instant demotion, no stale-authority window** — because a role change, like a rank change today, takes effect on the builder's very next request. The resolver is exposed through a **kernel port** so core `auth` resolves permissions without importing the `governance` module (respecting the ADR 0083 core-never-imports-a-module boundary; the module registers the port, core calls it).

A new middleware `requirePermission(...perms)` gates a route on the caller holding **all** of the named permissions (fail-closed: 403 on any missing). `requireRank` keeps working unchanged throughout the migration — the seeded rank-roles make `requireRank('metic')` and `requirePermission(<the metic-role's keys>)` equivalent — so gates migrate route-by-route with no flag day (R97).

### 2. Every DB-resolvable authority gate reads permissions, not rank (C2)

Once the primitive exists, the gates migrate off rank:

- **Core routes** (`src/bongos/routes/`) and the **~60 module route gates** (`modules/*/routes/*`) move `requireRank(...)` → `requirePermission(<key>)` with the catalog key that names each route's capability, behavior verified identical against the parity intent (R104, R105).
- **Claim eligibility** — today rank-driven (`xenosClaimAllowed` / the per-task `requires_rank` floor) — is re-expressed as permissions (`task.claim.newcomer` vs `task.claim.any`), with the per-task floor still honored and the abuse cases still blocked (R106).
- **HTML page gates** (`requireArchonPage` / `requireNonXenosPage` / `requireBuilderPage`) and the **wandering-prefs rank-default/ceiling clamp** resolve via permissions / role metadata (R107).
- The **duplicated rank-ladder / tier / order maps** collapse behind the resolver, with a fitness guard forbidding a new parallel map (R108). The 2026-07-24 sweep found **13 definition sites across 5 families** — `RANKS` (the full 16-value ladder, ×2 "twinned"), `LIVE_RANK_LADDER` (×2), `REQUIRES_RANK_TIER`/`RANK_TIER` (×3, one a deliberately-local copy in `permission-path-check.js`), `RANK_ORDER` (×4, one **0-indexed** while the tier maps are 1-indexed), and four one-off rank `Set`s — several commented as hand-kept copies. This is the exact drift class that *caused the Builder 25 incident* (a tier map that forgot `thetes` — [ADR 0043](<redacted>.md)); centralizing it is a security win, not just tidiness.
- The **route-rank-check fitness gate** learns to read `requirePermission`, re-expresses its EXPECTED pins in permission terms, and still hard-fails the build on an ungated or under-gated write route (R109).

### 3. The complete authority model — roles + principals + session-scopes + ownership-scoped permissions (C3)

The model represents all four axes from §Context as **first-class types**, not as rank special-cases:

- **Roles** — the rank-seeded and custom bundles of §1. The common case.
- **Principals** (R98) — a **machine identity** is a first-class principal type, its capability keyed on `system_role` (the existing `bfg` / `discord_bot` gate), **provisioned out-of-band and never UI-grantable**. The resolver treats a principal's capability distinctly from a builder's roles; the governance tab *shows* principals but cannot *grant* to them. (A human token can never acquire a principal capability — that is the point of gating on exact identity.)
- **Session-scopes** (R99) — a **session-scope** is a first-class capability the resolver honors: a box-scoped session's effective permissions are its **deny-by-default allow-list**, intersected with (never widening) its builder's role permissions — so a box session is limited even when its builder is an Archon. This models the current ad-hoc `allowBoxScope` flag explicitly.
- **Ownership-scoped permissions** (R100) — "act on **own** X" is a **parameterized** permission distinct from the global grant: `box.manage.own` ≠ `box.manage.any`, `claim.act.own` ≠ `claim.act.any`, likewise own-memory / own-credential, and the goal owner/manager authority of [ADR 0106](<redacted>.md). A route requires the scoped form; the resolver + an ownership predicate (the in-handler pure-gate pattern) decide it against the target row. Existing own-scoped routes migrate to it.

### 4. Policy owns / substrate enforces — the protected-surface registry + the system-permission wall (C6 / R101)

This is the pillar that keeps configurability from becoming a foot-gun, and it has two halves.

**The `system` flag.** Every permission in the catalog is flagged **`system: true`** (trust-boundary, **non-grantable**) or **`system: false`** (operational, grantable). A `system` permission — deploy, protected-path modification, rank-setting, version disposition, grade-bypass, cross-tier structural edges — **cannot be added to a custom role**; the governance API rejects the grant server-side and the tab renders it **LOCKED** (visible, so the model is legible; not togglable). `system: false` permissions are the ones an Archon may compose into custom roles freely. The rule for the flag: *a permission is `system` iff granting it to a non-Archon would breach the trust boundary or a scope/quality gate* (privilege management, scope disposition, quality-gate bypass, cross-tier structural edges, and everything the out-of-band substrate enforces).

**The protected-surface registry.** Today's rank→surface map — `PROTECTED_GLOBS` + the per-tier `EXPECTED_RANKS` — is baked into code (`src/bongos/permission-path-check.js`). Governance takes ownership of it **as data**: which paths are protected, and at what floor, becomes a governance-owned registry. The **out-of-band substrate stays the enforcer** — the pre-push hook, the grader pre-pass, `main-audit.js`, `gate-review.js`, and the goal-scope check *read the registry* instead of a hardcoded list, but enforcement never moves into the app. The Metic floor and the `system`-permission mapping *flow from* the registry. The registry (R101) is also the moment to **close the [ADR 0087](<redacted>.md) §3 path-matching gap** the sweep confirmed: `permission-path-check.js`'s `normalize()` does backslash→slash + strip-`./` only — **no case-folding and no Unicode normalization** — so a case-varied or homoglyph path evades the protected-glob match (Linux-deployed, so latent today, but it is the Cursor-class `.cursorignore`/case-bypass CVE shape). The registry matcher should normalize (case-fold + Unicode NFC) and gate file **creation** as strictly as edits.

The invariant this buys, stated as a testable promise (R112, R114): **the tab can re-map which surfaces are protected and at what floor (policy), but it cannot move enforcement into the request path (substrate).** An Archon can create a custom role and grant it every `system: false` permission in the catalog, assign it to a `xenos`, and that builder gains exactly those operational powers — **while a `system` permission the role "has" stays enforced by the substrate**: the deploy / protected-path / SSH attempt is still blocked, because [ADR 0043](<redacted>.md)'s layer-3 audit reads the real git history and the real registry, independent of anything the app grants. Config owns policy; the substrate owns enforcement; a forced grant cannot cross that line. (Note: `main` on this repo still has **no** GitHub branch protection — re-verified 2026-07-24, [ADR 0043](<redacted>.md) §"Branch-protection status" — so `main-audit.js` remains the *authoritative* substrate layer, not a redundant net. The registry does not change that; it only makes the protected list data instead of a constant.)

### 5. Capability in core, settings per project (C4)

Governance is a **core module** (`modules/governance/`, `default: true`) — a Cloud Bongos instance ships configurable roles the way it ships its status page. The *capability* (tables, resolver, catalog, gate, tab) lives in core; the *settings* (which roles exist, their starting grants) are **per-instance config**, mirroring the branding pattern:

`config/governance.json` (instance) resolves over `config/governance.neutral.json` (neutral starter, ships with the core package) with an env override on top — the exact `env → instance → neutral` precedence of `src/branding.js` (`resolveBranding` / `deepMerge`) (R96). The neutral config seeds the four rank-role templates a fresh instance inherits; **live** role assignments live in the DB (`governance_builder_roles`, R93), never in config. A vanilla instance boots with sane default roles, no OTB-specific identity, and the trust boundary intact — proven by a vanilla-boot fitness check (R102).

The tables are **module-owned, additive migrations** (`governance_roles`, `governance_role_permissions`, `governance_builder_roles`, all `governance_*`-namespaced per ADR 0083's module-migration rule), plus a `governance` scope-map key covering `modules/governance/**` + `config/governance*.json` (protected, since it overlaps the authz core — R91).

### 6. The Archon Governance tab + the proofs (C5, C6)

- **API** (R110): routes to list roles/permissions/assignments, create a role, toggle an **operational** permission on a role, and assign a role to a builder — all gated `governance.manage` (an Archon-seeded, itself-`system` permission), with `system` permissions **rejected as non-grantable server-side** and the routes pinned in route-rank-check.
- **Page** (R111, R113): `modules/hall-ui/public/governance.{html,js}` renders the role list, a per-role permission grid (toggle operational perms; `system` perms render LOCKED), and assign-role-to-builder — Discord-style, theme-aware, behind an Archon nav entry + page gate (defense-in-depth on top of the API gate).
- **Proofs**: a **parity test** (R103) enumerates every current builder + rank and asserts their resolved permission set grants **exactly** today's powers — no more, no less (red if the seed drifts). An **abuse-matrix test** (R112) asserts every attempt to grant a `system` permission to a custom role / low-trust builder is rejected, and the substrate still blocks the action even if a grant were forced. A **live demo** (R114) closes the goal: an Archon builds a custom role, assigns it, the builder performs the operational action — while a `system` permission stays walled.

---

## The compatibility seed (the "zero day-one change" guarantee)

The seed is what makes the cut-over behavior-identical. Four rank-roles are seeded with **cumulative (nested-superset)** grants, and every existing builder is backfilled the role matching their current rank (R93):

| Seeded role | Grants (cumulative — each ⊇ the one above) |
|---|---|
| **`xenos`** | own-work + public read: `task.claim.newcomer`, `task.ship`, `task.act.own`, `cost.log`, `learning.create`, `blocker.file`, `idea.file`, `box.manage.own`, `memory.manage.own`, `credential.manage.own`, `page.view.public` |
| **`thetes`** | everything `xenos` has **+** `task.claim.any` (the whole general queue, still honoring each task's `requires_rank` floor), `page.view.builder` |
| **`metic`** | everything `thetes` has **+** `me.wandering.set` (higher clamp) **+** the review/triage/authoring set: `idea.triage`, `blocker.review`, `task.{create,edit,promote,demote,vote}`, `task.dependency.manage`, `task.criterion.manage`, `criterion.satisfy`, `criterion.review`, `planning.run`, `priority.run`, `goal.create`, `goal.archive`, `goal.scope.widen`, `goal.manage.own`, `module.enable`, `module.submit`, `security.report.file`, `llm_cache.use`, `backup.manage`, `source.clone.local`, `box.source.full` |
| **`archon`** | everything `metic` has **+** the **admin** operational set (`builder.status.set`, `builder.budget.set`, `task.abandon`, `criterion.unsatisfy`, `version.create`, `auth.session.revoke`, `access_request.review`, `security.report.adjudicate`, `provisioning.fleet.manage`, `box.fleet.manage`, `autonomy.precheck`, `discord.channels.manage`, `project.curate`, `override_request.decide`, `claim.release.any`, `idea.ratify`, `task.newcomer_restock`, `task.peer_votes.tally`, `goal.reorder`, `builder.roster.read`, `session.search`, `memory.read.any`, `audit_log.read`, `page.view.governance`) **+** the **`system`** set (`builder.rank.set`, `version.close`, `task.confirm.grade_bypass`, `dependency.cross_tier.manage`, `goal.scope.manage`, `governance.manage`, `gate_approval.decide`, `deploy.push_main`, `path.protected.modify`, `infra.ssh`). The `principal.*` permissions are **not** in any rank-role — they are held only by the machine-principal identities (`system_role='bfg'`/`'discord_bot'`), never by a human, not even an Archon (that is what gating on exact identity means). |

**Why cumulative preserves the threshold.** Today `requireRank('metic')` admits metic **and** archon (threshold = at-or-above). Because the seeded `archon` role ⊇ `metic` role, the resolver's union preserves exactly that: both roles grant `idea.triage`, so `requirePermission('idea.triage')` admits both — identical to the old threshold. A builder in the compat seed holds exactly **one** rank-role, so their effective set = that role's set = exactly their rank's threshold powers today. The parity test (R103) is the mechanical proof.

**One deliberate, fail-closed divergence.** The threshold check currently *also* admits the reserved-but-unwired ranks **above** archon (`olympian`…`demigod`) to `requireRank('archon')` gates. The seed maps **only the four live ranks** to roles; a reserved rank maps to **no role → no permissions → fail-closed**. No current builder holds a divine rank, so parity holds for the actual roster; but the model is stricter than today's *latent* threshold-admit-divine edge. This is intended (fail-closed beats fail-open for an unwired rank) and is called out for R103/R106 so the parity test asserts against the live roster, not the reserved enum.

---

## The permission catalog (appendix)

Enumerated from the **2026-07-24 authority sweep** ([`docs/governance/<redacted>.md`](../governance/<redacted>.md) — 81 guarded routes + the ownership/page/substrate gates), grouped here by **capability** (one key may cover a set of sibling routes; the sweep doc holds the exhaustive 1:1 route→gate list R94 transcribes). `sys` = `system` flag (✔ = non-grantable, LOCKED in the tab). Ownership-scoped keys carry an `own`/`any` split. This catalog + the sweep doc are the single source R94 transcribes into `modules/governance/` code constants; R93 seeds roles against it.

### System permissions (`system: true` — non-grantable; substrate- or Archon-enforced)

`system` iff granting to a non-Archon would breach the trust boundary or a scope/quality gate — privilege management, scope disposition, quality-gate bypass, cross-tier structural edges, and everything the out-of-band substrate enforces.

| Key | Guards (route / surface) | Enforced by | sys |
|---|---|---|---|
| `builder.rank.set` | `PATCH /builders/:id/rank` — the single rank writer; one-rung, upward | HTTP (`requireRank('archon')`) | ✔ |
| `version.close` | version close disposition (never delegated below Archon — canonical) | HTTP | ✔ |
| `task.confirm.grade_bypass` | `POST /tasks/:id/confirm` — ratify past a failed grade (env-relaxable; see note) | HTTP + grader | ✔ |
| `dependency.cross_tier.manage` | `POST\|DELETE /dependencies` — cross-tier structural edges ([ADR 0086](<redacted>.md)) | HTTP | ✔ |
| `goal.scope.manage` | cross-tier goal-scope edges + protected-scope admission ([ADR 0086](<redacted>.md)) | HTTP + goal-scope-check | ✔ |
| `governance.manage` | the governance tab's write routes (roles/perms/assignments) — meta-escalation | HTTP (`requireRank('archon')`) | ✔ |
| `gate_approval.decide` | `POST /gate-approvals/:pr/approve` — CI deploy-gate override | HTTP + gate-review substrate | ✔ |
| `deploy.push_main` | `git push origin main` / the deploy | **substrate** (pre-push, main-audit, deploy gate) | ✔ |
| `path.protected.modify` | modifying a `PROTECTED_GLOBS` path below the Metic floor | **substrate** (3 layers, [ADR 0043](<redacted>.md)) | ✔ |
| `infra.ssh` | `ssh` to the droplet / operator surface | **substrate** (credential placement, not app) | ✔ |
| `principal.bfg` | `/memory/bfg/*` — `requireBfgPrincipal` (exact `system_role='bfg'`) | HTTP (identity, not rank) | ✔ |
| `principal.discord_bot` | Discord bot routes — `requireDiscordBot` (exact `system_role`; dormant) | HTTP (identity, not rank) | ✔ |

The `system` set is deliberately **tight** — only gates whose delegation would *compromise the platform* (escalate rank, bypass the grader/deploy gate, touch protected paths/infra, or re-grant permissions). Every other authority — including many currently archon-gated **admin** ops (offboard, abandon, onboarding review, fleet teardown) — is **operational** and therefore *delegable*, which is the whole value of the model: an Archon can stand up a "moderator" or "onboarder" role without handing out deploy. (The exact system/operational line for a couple of scope-disposition ops is R94's to finalize; this ADR sets the rule and the default.)

> **Env-relaxable exception (flagged for R94/R106):** `POST /tasks/:id/confirm` is archon-only *unless* `GRADER_BYPASS_ENABLED=1` (read live per request, [ADR 0041](<redacted>.md)), which relaxes the middleware to any-builder — then the handler re-narrows in-code via `gateTaskOwnership` (claim holder or Archon only). The permission model represents this as `task.confirm.grade_bypass` (system) with a documented env override on the *substrate* side; the grant is never widened by config, only by the operator env flag.

### Operational permissions (`system: false` — grantable to custom roles)

"Floor" = the rank that holds this permission *today* via the compat seed; it is the seed's job, not an intrinsic property — a custom role may be granted any of these regardless of floor.

**Admin ops — floor `archon` today (delegable to a custom role; that is the point):**

| Key | Guards (route / surface) |
|---|---|
| `builder.status.set` | `PATCH /builders/:id/status` — offboard / (de)activate |
| `builder.budget.set` | `PATCH /builders/:id/budget` |
| `task.abandon` | `POST /tasks/:id/abandon` — terminal scope removal |
| `criterion.unsatisfy` | `POST /done-when/:id/unsatisfy` |
| `version.create` | `POST /versions` — create a version + its done-when criteria. Added BV1.R105 (task 1001847): the route had no atom, so it was the one module write the migration could not finish. **Operational, not `system`,** even though `version.close` is `system` — the flag marks trust-boundary power, and creating a version is *authoring* (it confers no authority). Its siblings are `goal.create` / `task.create`. Close is the disposition that finalises a version's scope-truth; create opens it. |
| `auth.session.revoke` | `POST /auth/revoke`, `/auth/revoke-all` |
| `access_request.review` | `GET/PATCH /access-requests/:id` — admit a builder |
| `security.report.adjudicate` | `POST /security/reports/:id/{confirm,dispute,fix,link-fix}`, `/security/docs` CRUD |
| `provisioning.fleet.manage` | `GET /provisioning/fleet[/cost-ledger]`, `POST …/force-teardown` |
| `box.fleet.manage` | `GET /boxes[/cost-ledger]`, `POST /boxes/:b/close`, `PATCH …/block` |
| `autonomy.precheck` | `GET /autonomy/precheck` — unsupervised-runner gate |
| `discord.channels.manage` | `GET /discord/channels/plan`, `POST …/reconcile` |
| `project.curate` | platform-identity: `POST /projects`, `/projects/invite`, `PATCH /projects/:id/featured`, `GET /scouting` |
| `override_request.decide` | `GET /override-requests`, `POST …/:id/decide` |
| `claim.release.any` | `POST /claims/:id/release-on-behalf` |
| `idea.ratify` | `POST /inbox/:id/ratify` |
| `task.newcomer_restock` | `POST /tasks/newcomer-restock` |
| `task.peer_votes.tally` | `POST /tasks/peer-votes/tally` |
| `goal.reorder` | `POST /goals/reorder` |
| `builder.roster.read` | `GET /builders/roster`, `/grades/by-builder`, `/builders/:id/active-claims` |
| `session.search` | `GET /sessions/search` |
| `memory.read.any` | `GET /memory/builders/:id/file[s]` — cross-builder memory read (Archon) |
| `audit_log.read` | `GET /audit-log` |

**Working rank — floor `metic` today:**

| Key | Guards (route / surface) |
|---|---|
| `idea.triage` | `PATCH /inbox/:id` |
| `blocker.review` | `POST /blockers/:id/{resolve,link}` |
| `task.create` / `task.edit` / `task.promote` / `task.demote` | `POST /tasks`, `PATCH /tasks/:id`, `/promote`, `/demote` ([ADR 0090](<redacted>.md)) |
| `task.dependency.manage` / `task.criterion.manage` | `/tasks/:id/dependencies` + `/criteria` CRUD (same-tier) |
| `task.vote` | `POST /tasks/:id/vote` |
| `criterion.satisfy` / `criterion.review` | `POST /done-when/:id/satisfy`, `GET /done-when/pending-review` |
| `criterion.create` | `POST /versions/:id/done-when` — floor `metic` but **qualified**: a non-Archon must name a `goal_id`, on a `building` version, in an `open` goal they own or manage ([ADR 0154](<redacted>.md)). A floor alone does not describe this permission. *(Was bundled into the `criterion.review` row above while the route was still Archon-only — a transcription slip against the sweep; see ADR 0154 §5.)* |
| `planning.run` / `priority.run` | planning- / priority-session surface |
| `goal.create` | `POST /goals` (protected scope → archon in-handler; [ADR 0086](<redacted>.md)) |
| `goal.archive` | `POST /goals/:id/{archive,reopen}` |
| `goal.scope.widen` | `POST /goals/:id/scope` (same-tier; cross-tier = `goal.scope.manage`, system) |
| `module.enable` / `module.submit` | `POST /modules/:key/{enable,submit}`, `GET /modules/submissions` |
| `security.report.file` | `POST /security/reports`, `GET /security/adr` |
| `llm_cache.use` | `POST /llm-cache/{lookup,store}` |
| `backup.manage` | `GET /backup/status`, `POST /backup/trigger` |
| `source.clone.local` | Metic+ local clone / collaborator invite ([ADR 0035](<redacted>.md)) |
| `box.source.full` | `GET /box/source-access` → `full` (vs `starter`); `boxScopeForRank` |

**Ownership-scoped (`own` ≠ `any`) + baseline — floor `thetes` / `xenos` / any builder / `own`:**

| Key | Guards (route / surface) | Floor |
|---|---|---|
| `goal.manage.own` | `PATCH /goals/:id/members/:b`, `POST /goals/:id/transfer` — owner/manager, in-handler ([ADR 0106](<redacted>.md)) | owner/manager |
| `task.act.own` | act on **own** active claim (release, cost, notes) | own |
| `box.manage.own` | own dev-box lifecycle | own |
| `memory.manage.own` | own builder memory | own |
| `credential.manage.own` | own API key / credential | own |
| `me.wandering.set` | `PATCH /me/wandering` (clamped by `maxLevelForRank`) | own (rank-clamped) |
| `task.claim.any` | claim the general queue (per-task floor still applies) | thetes |
| `task.claim.newcomer` | claim a `newcomer_friendly` task (`xenosClaimAllowed`; xenos = one active claim) | xenos |
| `task.ship` · `cost.log` · `learning.create` · `blocker.file` · `idea.file` | own-work write surfaces | any builder |
| `page.view.public` | public read surfaces | any (incl. xenos) |
| `page.view.builder` | authenticated hall pages (`requireNonXenosPage` / `requireBuilderPage`) | thetes+ |
| `page.view.governance` | the Archon governance page (`requireArchonPage`; write = `governance.manage`) | archon |

> **Sweep-completeness note.** These keys cover every authority **domain** the 2026-07-24 sweep found ([the sweep doc](../governance/<redacted>.md) holds the exhaustive 1:1 route list — 81 guarded routes). R94 (the code transcription) is where each remaining `requireRank` site is mapped 1:1 to a key and any residual gap is closed; the route-rank-check fitness gate (R109) is the mechanical backstop that no write route ends up keyless. Keys are stable strings; adding a permission is a catalog + migration change, never a UI action. **A permission's `system` flag, not its floor, decides grantability** — floors are seed data and move; the flag is the wall.

---

## Alternatives considered

- **Keep ranks; add more of them.** Rejected. Every new rank threads through the 13 hand-copied tier/ladder maps (the exact drift that caused the Builder 25 incident) and still can't express "triage but not author," principals, session-scopes, or ownership. Ranks-as-roles subsumes ranks without losing them.
- **Permissions replace ranks entirely (drop the rank column).** Rejected for the cut-over. `builders.rank` anchors auto-graduation, the promotion ladder, and the per-task `requires_rank` floor; ripping it out forfeits the zero-day-one-change guarantee. Ranks become *seeded roles* and the column stays as identity/graduation — a strangler, not a rewrite.
- **Make every permission grantable (no `system` flag).** Rejected — it is the whole risk. A configurable role that could be granted `deploy` or `path.protected.modify` would let an Archon (or a compromised Archon token) hand the crown jewels to a `xenos`. The `system` flag + "substrate enforces" is what makes the tab safe; the abuse-matrix test (R112) exists to prove it.
- **Enforce the protected-surface floor in the app (move the substrate in-process).** Rejected — it re-opens exactly the gap [ADR 0043](<redacted>.md) closed. Git/SSH sit *outside* the HTTP boundary; the authoritative audit must read real git history + real ranks/registry independent of the request path. Governance owns the *data* (policy); the out-of-band substrate stays the *enforcer*.
- **Cache the resolved permission set per token/TTL.** Rejected, same reasoning as ADR 0016 rejected caching rank: a cache is a stale-authority window on a demotion. The resolver is per-request and uncached; the cost is one more query on a join we already do, bought for instant revocation.
- **Store roles/permissions as free-form UI data.** Rejected. Permissions map to real routes, so the catalog is **code** — a permission no route consumes is meaningless. The UI assigns and toggles; it never invents a key.

---

## Consequences

- **R91–R114 build against one settled model.** R93/R94 (tables + catalog code) transcribe this ADR's catalog and seed; R95–R97 build the resolver + gate; R98–R101 add the three non-role axes + the registry; R96/R102 do the core-host config split; R104–R109 migrate the gates and collapse the tier maps; R110/R111/R113 build the tab; R103/R112/R114 prove parity, the abuse matrix, and the live demo.
- **ADR 0016 is preserved, not amended.** Authority still lives server-side, resolved fresh per request against the DB, with instant demotion. The unit of authority narrows from *rank* to *permission*; the enforcement property is unchanged. `requireRank` and `requirePermission` coexist during the migration via the seed.
- **The trust boundary strengthens.** The 13 duplicated tier/ladder maps — a proven incident source — collapse to one resolver behind a fitness guard; the protected-surface list becomes auditable data with case/Unicode-normalized matching and a mechanical abuse-matrix proof; principals and session-scopes stop being ad-hoc special-cases and become modeled, testable types.
- **Configurability is bounded by design.** An Archon can compose any `system: false` permission into a custom role, but the `system` set is non-grantable and substrate-enforced, so no configuration can hand out deploy / protected-path / rank-setting power. This is the C6 safety guarantee, proven not asserted.
- **Zero day-one behavior change.** The compat seed reproduces every current builder's exact powers; the one divergence (unwired divine ranks fail closed instead of latently inheriting Archon) is a fail-closed improvement no live builder touches.
- **Portable, and the moat.** Governance ships as a `default: true` core module with a neutral config every instance inherits; it is precisely the "governance / audit / org-memory" substrate [ADR 0087](<redacted>.md) named as the hard-to-copy asset. No new recurring cost — tables + code + a config file.
