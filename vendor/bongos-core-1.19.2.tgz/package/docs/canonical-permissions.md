# Canonical permissions reference

> **Read-only reference. Do not treat this file as the source of truth — it is a mirror.**
> The **enforcing** source of truth for authority is the production database (`builders.rank`)
> plus the `requireRank()` middleware on each route. This file *describes* that model so humans
> and agents can read it in one place; it cannot *grant* anything. If this file and a route ever
> disagree, **the route is authoritative and the doc is the bug.** See
> [ADR 0016 — Trust boundary](adr/<redacted>.md).
>
> Changing the permission model is a code + migration + ADR change, never an edit to this file alone.
> A builder editing local files (this doc, `CLAUDE.md`, skills, `settings.json`, hooks) cannot
> elevate themselves — every privileged route re-checks rank against the DB on every request,
> with no caching, so a demotion takes effect on the builder's very next request.

This page was split out of `CLAUDE.md` §10 in V3.R86 ([#305](https://example.com/builders#/task/305)) so the agent index no longer carries
de-facto permission *state*. `CLAUDE.md` now points here.

---

## Where authority lives

| Surface | Role | Inside the trust boundary? |
|---|---|---|
| `builders.rank` (prod DB, migration 023) | **the** source of authority | ✅ yes — the boundary itself |
| `requireRank()` middleware on each route (`src/bongos/auth.js`) | enforcement point | ✅ yes |
| `PATCH /api/gds/builders/:id/rank` (Archon-only, task [#232](https://example.com/builders#/task/232) / V3.R07) | the *only* writer of rank | ✅ yes |
| `CLAUDE.md`, this file, ADRs | **describe** the model for humans/agents | ❌ no — documentation only |
| `.claude/skills/*`, `.claude/settings.json`, hooks | call server endpoints; cannot grant authority | ❌ no |
| session token / cookie | identity, not authority (carries no rank) | ❌ no |

The rule that makes this legible: **markdown describes, the database enforces.**

---

## The rank ladder (migration `023_pms_rank.sql`; default flipped in `029_rank_three_live.sql`; `thetes` wired live in `068_thetes_requires_rank.sql`)

`builders.rank` is a Postgres `text` column, `NOT NULL DEFAULT 'xenos'` (the default was `'thetes'`
under the original two-rank cut; migration 029 flipped it to the sandboxed entry rank), with a
`CHECK` constraint holding **16 reserved values**. The full enum is reserved up front so adding a
rank to the *live* set later is a code-only change (route grants) — never a migration.

```
-- Divine — above-the-system
olympian, hermes, oracle, demigod
-- Citizen — the working ladder
archon, strategos, boule, aristoi, hippeis, zeugitai, thetes
-- Outsider / sub-citizen — sandboxed
metic, xenos, periokoi, doulos, helot
```

### Which ranks are actually wired in V3

The CHECK enum reserving a value does **not** mean that rank has route grants. Reserved-but-unwired
ranks are a no-op until code grants them privileges. As of **[#692](https://example.com/builders#/task/692) / ADR 0034**, four ranks are LIVE,
forming the ordered claim-gate tier **`xenos` (1) < `thetes` (2) < `metic` (3) < `archon` (4)**
(`REQUIRES_RANK_TIER` in `src/bongos/db.js`):

- **`archon`** — Lars (`github_login = 'example-owner'`, set by migration 023). **Since
  [ADR 0157](adr/<redacted>.md) (2026-08-05) the Archon rank is responsible for
  RANK and IDENTITY, not day-to-day administration.** It is everything a Metic can do, plus: **rank**
  (grant/revoke — the single writer), **identity** (offboard/(de)activate, admit an access request, revoke
  sessions), the **four escalation keys** that would otherwise make that delegation self-reversible
  (grader-bypass confirm, CI gate approval, protected-module goal scope, and `governance.manage`),
  **version close**, cross-tier dependency edges, and the substrate floors (push `main`, protected paths,
  ssh — ADR 0043). Version-**level** criteria (a `done-when` with no `goal_id`, or one outside an open
  version / outside a goal they own) also stay Archon per
  [ADR 0154](adr/<redacted>.md), though that ADR's `done-when/:id/unsatisfy`
  carve-out was superseded — unsatisfy is Metic now. Overrides any claim. The authority that
  stays *exclusively* Archon — never delegated to Metic — is **setting rank** (`PATCH /builders/:id/rank`)
  and **closing versions**.
- **`metic`** — the Archon-approved **working rank**. Full claim/ship of any ready task (own work),
  plus the review/triage powers criterion C2 assigns: **idea triage** (`PATCH /inbox/:id`), **blocker
  review** (`POST /blockers/:id/{resolve,link}`), and planning/priority sessions. **As of [ADR 0090](adr/<redacted>.md)
  (owner decision 2026-06-26) a Metic may also author + shape tasks**: create (`POST /tasks`), edit
  (`PATCH /tasks/:id`), promote (`POST /tasks/:id/promote`), and wire a task's dependencies + criterion
  links (`/tasks/:id/dependencies`, `/tasks/:id/criteria`) — the reasoning being that a rank trusted to
  *triage* ideas is trusted to *seed* the work they become. **As of [ADR 0152](adr/<redacted>.md)
  (owner decision 2026-07-27) a Metic may also retire work** — `POST /tasks/:id/abandon` — and undo a
  mis-retire, since `POST /tasks/:id/promote` now also restores `abandoned → backlog`. **Still cannot**
  set rank, close versions, grader-bypass confirm, or author cross-tier `POST /dependencies` / goal-scope edges
  ([ADR 0086](adr/<redacted>.md)) — those stay Archon. A builder reaches Metic
  only by deliberate Archon promotion (`PATCH /builders/:id/rank`).
- **`thetes`** — the **graduated-newcomer rank** (ADR 0034). Claims the **whole general queue** — any
  task whose `requires_rank` is the default `'xenos'` — and is **not** limited to `newcomer_friendly`,
  but is blocked from tasks raised to `requires_rank='metic'/'archon'`. Has **no** scope-shaping or
  trust powers: cannot triage, file red-team, resolve blockers, run planning/priority, or create/edit
  tasks — all of those stay Metic+. A `xenos` **auto-graduates** to `thetes` the moment their 3rd task
  reaches `shipped` (server-side, in the ship transaction — `db.maybeAutoGraduateToThetes`, counting
  `tasks.shipped_by` rows at `status='shipped'`); no Archon action needed. `thetes` is **also manually
  grantable** — an Archon may `PATCH /builders/:id/rank` to `thetes` directly (e.g. to fast-track a
  builder), and onward to `metic` (the trust grant). Two paths reach it: the automatic graduation and a
  deliberate Archon promotion.
- **`xenos`** — the **sandboxed entry rank** every new GitHub-authed builder defaults to (migration
  029 flipped the column default here). Read-only on public surfaces; may claim + ship **only** tasks
  an Archon (or the newcomer-generator) has flagged `newcomer_friendly = true` (enforced in
  `db.claimTask` / `claimTasksBatch`, returns `rank_too_low_for_task`). Cannot triage, resolve
  blockers, or run planning/priority sessions. This is also the tier a deactivated/offboarded builder
  is dropped to by `/builder-exit` (migration `025`); for them `status='inactive'` additionally blocks
  *all* claims. Either way, example / credit history / shipped-task attribution are preserved.

Everything else on the citizen ladder (`strategos`…`zeugitai`), the divine tiers, and the other
sub-citizen tiers (`periokoi`/`doulos`/`helot`) stay **reserved but unwired** — promoting anyone to
them is a no-op until those ranks gain explicit route grants. Documented, not a bug.

> **The claim-sandbox fails closed ([#510](https://example.com/builders#/task/510)).** The row-level claim gate
> (`db.xenosClaimAllowed` + the `listClaimableTasks` view filter) allowlists the **live general-queue
> ranks `{thetes, metic, archon}`** — *everyone else* (a `xenos`, any reserved/unwired rank, a future
> typo, or a missing rank lookup) is sandboxed to `newcomer_friendly` tasks. The earlier logic tested
> `rank !== 'xenos'`, which failed **open**: any value that merely wasn't the literal string `'xenos'`
> (e.g. a reserved `'helot'`) skipped the sandbox and could claim the whole queue. Not exploitable in
> practice today (the per-task `requires_rank` floor independently collapses unknown ranks to tier 0),
> but both gates now state the same fail-closed posture so a future rank can't silently bypass one of
> them. Regression: `tests/rank_gate.mjs`.

> **History.** The first rank cut (migration 023 / task [#106](https://example.com/builders#/task/106)) shipped a deliberately-minimal
> **two-rank** model — `archon` + `thetes` (default) — with `metic`/`xenos` reserved. The V3.R86
> CLAUDE.md audit ([#305](https://example.com/builders#/task/305)) surfaced that this conflicted with the V3 plan (criterion C2) and the skills,
> which assume the three-rank **Xenos → Metic → Archon** model. Task **[#360](https://example.com/builders#/task/360)** (ADR 0018) wired the
> three-rank model for real; target and shipped now agree. The two-rank "deliberately minimal" note in
> ADR 0016 §Consequences is superseded.

---

## What's gated server-side today

`requireRank(...allowed)` runs after `requireBuilder`, compares the **live** `builders.rank` against
the gate, and returns `403 { error: 'rank_forbidden', required, actual }` on mismatch. The check is
**threshold-based, not exact-set membership** ([#591](https://example.com/builders#/task/591)): a builder passes if their rank sits
**at or above** the lowest-authority rank named in `allowed` (using the `RANKS` ladder, where lower
index = higher authority). So `requireRank('archon')` admits `archon` **and the divine tiers above it**
(`olympian`…`demigod`) — fixing the old footgun where a promotion to an "above-the-system" rank
silently *lost* all archon-gated authority — while still denying everything below the floor. Unknown
or missing ranks fail closed.

- **Archon-only** — **rank, identity, and the four escalation keys ([ADR 0157](adr/<redacted>.md), owner decision 2026-08-05).**
  That ADR narrowed Archon from ~50 route gates to 9 live ones, on the rule *"the Archon rank is
  responsible for rank and identity only"*:
  - **rank** — `PATCH /api/gds/builders/:id/rank` (the single writer).
  - **identity** — `PATCH /api/gds/builders/:id/status` (offboard/(de)activate), `GET|PATCH /api/gds/access-requests[/:id]`
    (who is admitted), `POST /api/gds/auth/revoke[-all]` (whose sessions are valid).
  - **the four escalation keys**, which look operational but are not: `POST /api/gds/tasks/:id/confirm`
    (grader-bypass), `POST /api/gds/gate-approvals/:pr/approve` (CI deploy-gate override), protected-module
    **goal scope** ([ADR 0086](adr/<redacted>.md)), and `governance.manage` (the
    roles/permissions tab). Delegating any one of them lets a Metic reach Archon in four steps — create a
    protected-scope goal in the permission core, claim a task there (protected paths already floor at
    *metic* per [ADR 0043](adr/<redacted>.md)), confirm
    past the failed grade, approve their own red gate — so keeping rank Archon-only depends on keeping
    these Archon-only too. **Any future delegation must re-check that chain.**
  - plus `version.close` (paired with rank as the powers that never delegate), the cross-tier
    `POST|DELETE /api/gds/dependencies` (`system: true` — no system permission is grantable below archon),
    and the substrate floors (`deploy.push_main` / `path.protected.modify` / `infra.ssh`, ADR 0043).

  Earlier one-power delegations that ADR 0157 generalises: **task authoring** — `POST /api/gds/tasks`,
  `PATCH /api/gds/tasks/:id` (incl. the `newcomer_friendly` flag), `POST /api/gds/tasks/:id/promote`, and the
  `tasks/:id/{dependencies,criteria}` CRUD — moved to Metic+ in [ADR 0090](adr/<redacted>.md),
  and **task retirement** — `POST /api/gds/tasks/:id/abandon`, plus the `abandoned → backlog` restore on
  `/promote` — in [ADR 0152](adr/<redacted>.md) (see the Metic+Archon bullet).
  `POST /api/gds/done-when/:id/unsatisfy` **was** Archon-only and moved to Metic in ADR 0157, superseding
  [ADR 0154](adr/<redacted>.md)'s "the backward ratchet stays Archon" carve-out;
  satisfy and unsatisfy remain separate permissions, so confirming a criterion still never confers
  un-confirming one. **A manual promotion advances exactly
  ONE live rung at a time** (`xenos→thetes→metic→archon`; [#707](https://example.com/builders#/task/707)) — a multi-rung jump (e.g. `xenos→metic`) returns
  `400 multi_rung_promotion` naming the next allowed rung. Demotions are unconstrained (offboarding
  drops straight to `xenos`); the automatic `xenos→thetes` graduation is +1 and unaffected.
- **Metic + Archon** — the working rank's review/triage powers ([#360](https://example.com/builders#/task/360) / ADR 0018): `PATCH /api/gds/inbox/:id`
  (idea triage), `POST /api/gds/blockers/:id/{resolve,link}` (blocker review) — **plus, since
  [ADR 0090](adr/<redacted>.md), full task authoring**: `POST /api/gds/tasks`,
  `PATCH /api/gds/tasks/:id`, `POST /api/gds/tasks/:id/promote`, the `tasks/:id/dependencies` +
  `tasks/:id/criteria` CRUD, and `POST /api/gds/done-when/:id/satisfy` (criterion confirm,
  [ADR 0086](adr/<redacted>.md)). Since
  [ADR 0154](adr/<redacted>.md), also `POST /api/gds/versions/:id/done-when`
  (criterion **create**) — but walled by goal ownership, not by rank alone: a non-Archon must name a
  `goal_id`, on an open (`planning`/`building`) version, in an `open` goal they **own or manage** (the same
  `authorizeGoalManagement` wall as goal visibility/invites/roles). Version-level criteria stay Archon;
  `done-when/:id/unsatisfy` moved here in [ADR 0157](adr/<redacted>.md). The floor here is
  `metic`, so **`thetes` does NOT pass these** — it sits below `metic` on the ladder and inherits none
  of its grants (ADR 0034); `archon` and the divine tiers above it do.

  **[ADR 0157](adr/<redacted>.md) added the whole operational block here** —
  20 permissions that had been Archon-gated only by ADR 0016's fail-closed default, never by a decision:
  the governance/monitoring **pages** (`/watch`, `/harbor`, `/gate` — `page.view.governance`) and
  `GET /api/gds/sessions/search`; the **dev-box + provisioning fleets** (`GET /boxes[/cost-ledger]`,
  `POST /boxes/:b/close`, `PATCH .../block`, `GET /provisioning/fleet[/cost-ledger]`,
  `POST .../force-teardown`); **security adjudication** (`GET /security/reports`,
  `POST /security/reports/:id/{confirm,dispute,fix,link-fix}`, `/security/docs` CRUD);
  `GET /api/gds/audit-log`; the **roster reads** (`GET /builders/roster`, `/grades/by-builder`,
  `/builders/:id/active-claims`); **cross-builder memory reads** (`GET /memory/builders/:id/file[s]`);
  **project curation + scouting**; `PATCH /builders/:id/budget`; `POST /inbox/:id/ratify`;
  `GET /override-requests` + `POST .../:id/decide`; `POST /claims/:id/release-on-behalf`;
  `POST /done-when/:id/unsatisfy`; `POST /goals/reorder`; `POST /versions`;
  `POST /tasks/newcomer-restock`; `POST /tasks/peer-votes/tally`; `GET /discord/channels/plan` +
  `POST .../reconcile`; `GET /autonomy/precheck`. Plus `GET /gate-approvals`, whose read was split out as
  `gate_approval.read` so the Gate page is usable at Metic while **approving** stays Archon.

  > **Note the one confidentiality widening:** `/security/docs` (the engagement-report store with
  > attacker-usable exploit detail) is now Metic-readable, because it shares `security.report.adjudicate`
  > with the report-adjudication writes. Every other delegated permission widens who may *act*; this one
  > widens who may *read*. ADR 0157 §Consequences records the split that would undo it if wanted.
- **Any authenticated builder** — own work: claim/ship/cost/learnings/file-blocker/file-idea. Two
  row-level claim rules apply (enforced in `db.claimTask` / `claimTasksBatch`, not by `requireRank`):
  a **`xenos` can only CLAIM tasks flagged `newcomer_friendly`** (returns `rank_too_low_for_task`),
  while a **`thetes`** escapes that sandbox and claims the whole general queue; and any task may RAISE
  its floor via `requires_rank` (the `REQUIRES_RANK_TIER` comparison — `INSUFFICIENT_RANK` (403) when
  the builder's tier is below it).
- **Every-privileged-route audit:** task [#231](https://example.com/builders#/task/231) (V3.R06) applies `requireRank()` to *every* privileged
  route so none is left ungated; the periodic auditor ([#266](https://example.com/builders#/task/266)/[#267](https://example.com/builders#/task/267)) asserts the boundary stays intact.
- **Rank writer:** `PATCH /api/gds/builders/:id/rank` (task [#232](https://example.com/builders#/task/232) / V3.R07) — Archon-only, the single
  writer of rank.

**Default posture for any new write/privileged route: `requireRank('archon')`** until a lower rank is
explicitly granted — fail closed, not open.

### The per-task `requires_rank` floor auto-derives (ADR 0084)

A task's `requires_rank` is not a hand-set field that drifts to the default — it is **derived on
every create/edit and enforced as a hard floor** (task [#1498](https://example.com/builders#/task/1498)). Before this, the column was inert:
nothing set it, so every task sat at the `'xenos'` default and the claim gate above never bit.

- **Derivation (`db.deriveRequiredRank(touches, security_sensitive)`):** a task floors at `metic` when
  it is `security_sensitive` **or** any `touches[]` entry hits the permission-sensitive set — reusing
  the **same** `permission-path-check.matchProtected` matcher the trust boundary uses (so the claim
  floor and the [ADR 0043](adr/<redacted>.md) git-push floor can never disagree). Everything else stays `'xenos'` (the open
  general queue). The rule **never auto-assigns `archon`** — owner-only is a deliberate manual call.
- **Override is upward-only (`db.highestRank`):** the stored value is `max(derived floor, requested)`.
  An Archon may RAISE a task's floor (incl. to `archon`) on `POST /api/gds/tasks` or
  `PATCH /api/gds/tasks/:id` (`requires_rank`, Archon-only); a request **below** the derived floor is
  clamped up (fail-closed). Flipping `security_sensitive` on ratchets the floor up; it never lowers one.
- **Backfill:** migration `<redacted>` raised every non-terminal task that was
  still at the `'xenos'` default to `metic` where sensitive (raise-only, idempotent).
- The builders-hall card shows a rank pill when a task's floor is above `xenos`.

### Source access is rank-gated too (ADR 0031 §9.2, ADR 0035 §1)

Authority over *the code itself* rides the same ladder, enforced server-side from the live DB rank
(never from anything the builder's machine can write):

- **Local clone onto your own disk = Metic and up.** Below Metic (`xenos`, `thetes`), there is **no
  permanent local copy** — the collaborator-invite path is a Metic+ affordance. New builders work
  inside the org-controlled cloud box, where access is revocable and audited.
- **Box source is scoped by rank** (`boxScopeForRank`, decided live inside `GET /api/gds/box/source-access`):
  `xenos`/`thetes` get a sparse `starter` surface; `metic`/`archon` get `full`. A demotion cuts a box
  off on its very next fetch (instant credential-layer revocation; the droplet teardown is the slower
  control-plane half via `box.js reconcile`).

> **Rollout note (ADR 0035 §4):** until the box lane is verified end-to-end on real hardware, the
> collaborator-invite/local-clone path stays open to all admitted ranks as the interim on-ramp — the
> Metic+ tightening lands once the box gives newcomers a working alternative. Never leave zero working paths.

### Git and SSH are OUTSIDE the HTTP boundary — covered by a separate rank floor (ADR 0043, SEC [#863](https://example.com/builders#/task/863))

ADR 0016's per-request rank check covers `/api/gds/*` only. Two surfaces it does **not** cover —
`git push` to `main` and `ssh` to the droplet — were used in the Builder 25 incident to land an
un-graded tiering change straight on prod `main`. The repo is a free-plan private repo, so GitHub
branch protection is unavailable; the enforcement is therefore code-side, in three layers (ADR 0043).
**Verified still true 2026-07-24** — no classic protection, no rulesets, no CODEOWNERS, and a
non-admin merged PR #19 to `main` with zero required checks; see ADR 0043 §"Branch-protection status"
for the probes. `main-audit.js` is therefore still the *authoritative* layer, not a backup one:

- A builder **below Metic** (`xenos`, `thetes`) may **not modify permission-sensitive paths** — the
  rank/authz machinery, the ship/grade/deploy pipeline, DB `migrations/`, `infra/`, and the
  trust-boundary docs. The protected set is the glob list in
  [`src/bongos/permission-path-check.js`](../src/bongos/permission-path-check.js) (source of truth).
- **Nobody pushes `main` directly.** The pre-push hook (`.husky/pre-push`) blocks it; the graded
  pipeline pushes only via `scripts/gds/push-main.js` (which carries the `OTB_ALLOW_MAIN_PUSH`
  override). A raw push is caught and reverted by the **post-push main audit**
  (`scripts/gds/main-audit.js`) — nightly and as the `~/deploy.sh` deploy gate — which is the
  authoritative layer (it reads the real git history + real ranks, independent of the builder).
- CLAUDE.md §10 carries a portable **behavioral** framing of this rule (product builders build the
  product, not the platform core they stand on); this doc holds the rank-name detail and the code is
  the enforcement. Editing CLAUDE.md or the hook locally cannot remove the audit/deploy-gate.

---

## Failure mode when a builder edits local files

A builder who edits their checkout to try to elevate themselves hits the boundary and fails every
time, in a defined way (`403 rank_forbidden`), because the server never consults anything the
builder's machine can write. The full enumeration of local-edit attack attempts and their outcomes
lives in [ADR 0016 §"Failure mode when a builder edits local files"](adr/<redacted>.md).

---

## No hardcoded Archon identity in implementation code (V3.R12 / [#236](https://example.com/builders#/task/236), 2026-05-29)

Implementation code — anything under `scripts/`, `src/`, `public*/`, `tests/`, `.claude/skills/`,
`.claude/scheduled-tasks/`, `.claude/hooks/` — MUST NOT hardcode references to the original Archon's
identity. Use `req.builder.*` server-side, the active session client-side, `$HOME` /
`os.path.expanduser('~')` for paths, and look up `builders.github_login` instead of the literal
`example-owner`.

- **Intentionally exempt (history, not runtime):** references in docs, ADRs, session logs, scope
  archives, CLAUDE.md §2, and the seed scripts that originally created V2/V3 tasks. These describe the
  project's history.
- **Infra config, not impersonation:** the droplet's operational identity (`User=lars`,
  `lars@REDACTED_IP`, `/home/lars/example`, `lars@example.com`).
- **Enforcement:** [`scripts/gds/audit-authorship.sh`](../scripts/gds/audit-authorship.sh) — exits 0
  clean, exits 1 with a hit list + remediation hints if a new hardcode shows up. Hookable from CI /
  pre-commit. Re-run after any change that touches identity surfaces; state was clean (0 hits) as of
  the V3.R12 sweep.
