'use strict';

// modules/governance/session-scopes.js — the SESSION-SCOPE axis (ADR 0151 §3, BV1.R99).
//
// The FOURTH axis, and the only one attached to the TOKEN rather than to the
// builder. Roles say what a person may do (R95); a principal's identity says what
// a machine may do (R98); an ownership scope says whose row it may be done to
// (R100); a SESSION-SCOPE says how much of that authority this particular
// credential carries. A dev-box session is minted onto a machine OUTSIDE the ADR
// 0016 trust boundary (#919/SR#2, ADR 0053), so it must stay limited even when its
// builder is an Archon.
//
// A SESSION-SCOPE CAN ONLY EVER NARROW. That is the whole load-bearing property,
// and it has two halves that fail in opposite directions:
//   • INTERSECTION, never union — the scope may not GRANT a permission the
//     builder's roles do not already confer, or a box token would escalate;
//   • DENY-BY-DEFAULT — a permission the allow-list does not name is denied, or an
//     unlisted permission leaks through.
// resolver.narrowToSessionScope() is the one place the two compose, and it is
// written as a FILTER of the role answer so widening is not expressible there.
//
// EXPLICIT DATA, not `if (source === 'box')`. session-scopes.json (next to this
// file) is the declaration; this module validates it against the permission
// catalog at load. GOVERNANCE OWNS THE POLICY, THE KERNEL STAYS THE ENFORCER —
// the same split R101 draws for the protected-surface registry: src/bongos/auth.js
// reads the same JSON as DATA (fs, never `require` — ADR 0083's one-way rule) and
// requireBuilder remains the gate every route composes. Nothing here enforces
// anything; re-mapping a scope here changes what the gate admits, it can never
// move the gate.
//
// FAIL-CLOSED at load: a key the catalog does not define, a `system: true`
// trust-boundary key, or a machine-principal key on a session-scope allow-list all
// THROW. Silently dropping the row would quietly shrink (or, for a principal,
// blur) the surface a token outside the trust boundary may reach — an unreadable
// policy is a broken install, not an opted-out one.

const catalog = require('./catalog');
const registry = require('./session-scopes.json');

// Normalize the declared rows into the same shape the kernel loader produces:
// `source` null for the legacy sourceless row, `permissions` always an array.
function normalizeScope(row) {
  return Object.freeze({
    source: row && row.source !== undefined ? row.source : null,
    label: row && typeof row.label === 'string' ? row.label : null,
    unscoped: !!(row && row.unscoped === true),
    permissions: Object.freeze(row && Array.isArray(row.permissions) ? [...row.permissions] : []),
  });
}

// The catalog cross-check. Exported so the shipped assertion itself is what the
// tests exercise, rather than a re-implementation of it (the fixture would
// otherwise have to rewrite this file on disk to be loaded).
function validateAgainstCatalog(scopes) {
  for (const scope of scopes) {
    const where = `session-scope registry: scope "${scope.source}"`;
    // unscoped XOR an allow-list. Both would be ambiguous (does it narrow?);
    // neither would be a scope that can never admit anything.
    if (scope.unscoped === (scope.permissions.length > 0)) {
      throw new Error(`${where} must declare EITHER unscoped:true OR a non-empty permissions allow-list, never both/neither`);
    }
    for (const key of scope.permissions) {
      if (!catalog.byKey(key)) {
        throw new Error(`${where} allows "${key}", which the permission catalog does not define`);
      }
      // R98's rule, kept structural: a machine principal's capability comes from
      // its exact system_role, never from a role — so a box-scoped session
      // carrying one must not be expressible on a scope allow-list either.
      if (catalog.isPrincipalKey(key)) {
        throw new Error(`${where} allows the machine-principal permission "${key}" — a session-scope narrows a builder's ROLE authority and never composes with the identity axis`);
      }
      // A session-scope IS the surface a credential outside the ADR 0016 trust
      // boundary may reach. A trust-boundary permission must never appear on one,
      // even though the intersection would make listing it inert today.
      if (catalog.isSystem(key)) {
        throw new Error(`${where} allows the system:true permission "${key}" — a session-scope may only list operational capability (a scoped token lives outside the trust boundary)`);
      }
    }
  }
  return scopes;
}

const SESSION_SCOPES = Object.freeze(
  validateAgainstCatalog(Object.freeze((registry.scopes || []).map(normalizeScope))),
);

const _bySource = new Map(SESSION_SCOPES.map((s) => [s.source, s]));

// The scope a session's `source` declares, or null when the registry does not
// declare it. An UNRECOGNISED source resolves to null and therefore to NO
// permissions — it never defaults to "full" (a null/absent source is a DECLARED
// row here, not an implicit default: it predates the box source existing).
function scopeFor(source) {
  const key = source === undefined ? null : source;
  if (key !== null && typeof key !== 'string') return null;
  return _bySource.get(key) || null;
}

// Does this session's scope narrow at all? Unknown source → true (fail-closed:
// treated as narrowing to nothing, which is what scopeFor/narrowToSessionScope do).
function isScoped(source) {
  const scope = scopeFor(source);
  return !scope || !scope.unscoped;
}

// The deny-by-default allow-list for a source; empty for an unscoped source (it
// narrows nothing) AND for an unrecognised one (it admits nothing) — callers must
// consult scopeFor()/isScoped() to tell those apart, exactly as the resolver does.
const NO_KEYS = Object.freeze([]);
function allowedKeys(source) {
  const scope = scopeFor(source);
  return scope ? scope.permissions : NO_KEYS;
}

function sources() {
  return SESSION_SCOPES.map((s) => s.source);
}

module.exports = {
  SESSION_SCOPES,
  validateAgainstCatalog,
  normalizeScope,
  scopeFor,
  isScoped,
  allowedKeys,
  sources,
};
