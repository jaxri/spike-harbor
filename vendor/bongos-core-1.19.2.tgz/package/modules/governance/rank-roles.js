'use strict';

// modules/governance/rank-roles.js — the PURE rank→role rotation decision
// (ADR 0151, BV1.R95b).
//
// A builder holds exactly ONE seeded rank-role. governance_002 seeds four of them
// (is_system=true, seeded_rank set) and backfills each builder the one matching
// their rank — but that backfill is run-once, so nothing kept it true afterwards.
// This is the decision the writer (db.syncRankRole) executes to keep it true:
// given a builder's CURRENT assignments and a rank, which seeded role to ADD and
// which to REMOVE.
//
// THE REMOVAL IS THE SECURITY HALF. An additive-only sync would leave a demoted
// Archon still holding the `archon` role, so resolveBuilderPermissions() would keep
// returning Archon permissions. That is the exact privilege retention ADR 0016's
// "a demotion takes effect on the builder's very next request" promise forbids: the
// resolver is correctly per-request and uncached, but it reads an ASSIGNMENT, and a
// stale assignment breaks the freshness guarantee one layer beneath the resolver.
//
// CUSTOM ROLES ARE NEVER TOUCHED. An Archon-assigned role (is_system=false, the
// R110 tab's output) must survive a rank change — only rows that are BOTH
// is_system AND carry a seeded_rank rotate. Keying the removal on "every role this
// builder holds" would silently revoke delegated authority on every promotion.
//
// A rank with NO seeded role — one of the twelve reserved ranks migration 023's
// CHECK still admits — yields target=null: every seeded role is removed and none is
// added, so the builder resolves to ZERO permissions. That is governance_002's
// deliberate fail-closed divergence (ADR 0151), preserved rather than re-derived —
// never invent a role for a rank the seed does not define.
//
// Pure: no DB, no I/O, no module state. The writer reads the two row sets and
// executes this verdict, so the unit tests exercise production logic directly.

// A row (an assignment joined to governance_roles, or a role row) is a SEEDED
// rank-role only when it is both a system role and names the rank it reproduces.
// Both halves are required: is_system alone would admit a future non-rank system
// role, and seeded_rank alone would trust a column a custom role could carry.
function isSeededRankRole(row) {
  return !!row
    && row.is_system === true
    && typeof row.seeded_rank === 'string'
    && row.seeded_rank.length > 0;
}

// planRankRoleSync({ rank, currentRoles, seededRoles }) → { target, add, remove, next }
//
//   rank         the builder's rank AFTER the write being synced.
//   currentRoles the builder's assignments, each { role_key, is_system, seeded_rank }.
//   seededRoles  the seeded rank-roles the DB defines, each { role_key, seeded_rank,
//                is_system }. Passed in rather than hardcoded so the four role keys
//                stay DB truth — this file never re-declares the seed.
//
//   target  the seeded role_key the builder should end up with, or null when the
//           rank has no seeded role (fail-closed divergence, above).
//   add     [] or [target] — empty when it is already held (idempotence).
//   remove  every OTHER seeded rank-role currently held. Custom roles never appear.
//   next    the resulting role_key set, sorted — "what the role set becomes".
function planRankRoleSync({ rank, currentRoles = [], seededRoles = [] } = {}) {
  const match = seededRoles.find((r) => isSeededRankRole(r) && r.seeded_rank === rank);
  const target = match ? match.role_key : null;

  const held = currentRoles.filter((r) => r && typeof r.role_key === 'string');
  const remove = held
    .filter((r) => isSeededRankRole(r) && r.role_key !== target)
    .map((r) => r.role_key);
  const add = target && !held.some((r) => r.role_key === target) ? [target] : [];

  const removed = new Set(remove);
  const next = held
    .map((r) => r.role_key)
    .filter((key) => !removed.has(key))
    .concat(add)
    .sort();

  return Object.freeze({
    target,
    add: Object.freeze(add),
    remove: Object.freeze(remove),
    next: Object.freeze(next),
  });
}

module.exports = { planRankRoleSync, isSeededRankRole };
