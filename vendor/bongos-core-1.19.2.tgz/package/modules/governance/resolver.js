'use strict';

// modules/governance/resolver.js — the permission resolver (ADR 0151, BV1.R95).
//
// Turns a builder's ROLES into their effective PERMISSION SET: the union of every
// permission granted to every role they hold. This is the heart of the
// permissions-as-atom model — `requirePermission()` (R97) and every migrated gate
// (R104-R107) resolve authority through here.
//
// TWO AXES, two entry points (R98, ADR 0151 §3). Roles are one axis; a machine
// PRINCIPAL's capability is the other, resolved from its exact `system_role` and
// never from a role. They are kept apart on purpose — see resolvePrincipalPermissions
// below, and the principal keys effectivePermissions drops.
//
// It preserves ADR 0016 exactly:
//   • server-side — the answer is computed on the server from DB rows, never from
//     a token claim or anything the client can influence;
//   • per request — resolveBuilderPermissions() is called on the request that
//     needs it, so a revoked role takes effect on the builder's very next request;
//   • UNCACHED — there is no memo, no TTL, no process-local map. Caching authority
//     is the one optimisation this file must never take (a cached grant survives
//     its revocation, which is the failure mode the trust boundary exists to
//     prevent). If a future profile shows the join is hot, the answer is a DB
//     index, not a cache.
//
// Fail-closed throughout: a builder with no roles resolves to the EMPTY set, and a
// grant naming a key the code catalog doesn't define is DROPPED (see
// effectivePermissions below) rather than admitted on trust.

const catalog = require('./catalog');
const db = require('./db');
const sessionScopes = require('./session-scopes');

// Pure core of the ROLE axis, split out so it is unit-testable without a database.
//
// Filters raw grant rows against the code catalog: the catalog is the source of
// truth for what a permission IS (every key maps to a real route — modules/
// governance/CLAUDE.md), so a DB row naming an unknown key is stale or hand-
// inserted and grants NOTHING. Returns a frozen, sorted, de-duplicated array.
//
// It also DROPS every principal key (R98). A machine identity's capability is the
// other axis — it comes from `builders.system_role`, never from a role — so a grant
// row naming `principal.*` confers nothing here no matter how it got written (a
// hand-inserted row, a future bug in the governance CRUD's system-permission
// rejection). That makes "a role cannot confer a principal permission" structural
// rather than merely policed at the write side.
function effectivePermissions(rawKeys) {
  const known = new Set();
  for (const key of rawKeys || []) {
    if (!catalog.byKey(key)) continue;
    if (catalog.isPrincipalKey(key)) continue;
    known.add(key);
  }
  return Object.freeze([...known].sort());
}

// The PRINCIPAL axis (R98, ADR 0151 §3) — deliberately a SEPARATE entry point, not
// a branch inside the role resolve. A builder's authority is the union of their
// roles; a machine principal's authority is its identity, and collapsing the two
// into one lookup is exactly the mistake that would let a rank reach a principal
// capability.
//
// Pure and DB-free: the only input is `builders.system_role`, which requireBuilder
// already reads fresh from the DB per request (alongside rank), and which no API
// route writes — a principal is provisioned out-of-band by migration, under a DB
// CHECK allowlist. The match is EXACT string equality, so NULL (every human,
// including an Archon), a differently-cased value, or an unknown role resolves to
// the empty set. Mirrors requireBfgPrincipal / requireDiscordBot in src/bongos/
// auth.js, which stay the HTTP enforcement point.
function resolvePrincipalPermissions(systemRole) {
  const principal = catalog.principalByRole(systemRole);
  return principal ? Object.freeze([principal.permission]) : Object.freeze([]);
}

// Does this exact machine identity hold this permission? Fail-closed on a blank or
// unknown identity, and on a key the identity does not own (one principal never
// reaches another's capability).
function principalHasPermission(systemRole, key) {
  return resolvePrincipalPermissions(systemRole).includes(key);
}

// The resolve entry point. Returns the builder's effective permission set as a
// frozen sorted array of catalog keys. A null/invalid builder id resolves to the
// empty set (fail-closed) without touching the DB.
async function resolveBuilderPermissions(builderId) {
  if (builderId === null || builderId === undefined || builderId === '') return Object.freeze([]);
  const raw = await db.getPermissionKeysForBuilder(builderId);
  return effectivePermissions(raw);
}

// Convenience for gate code: does this builder hold EVERY one of `required`?
// An empty `required` list is a programming error, not an open gate — it returns
// false so a mis-authored gate denies rather than admits (the same posture
// requireRank takes on an all-unknown allow-list).
//
// It also REFUSES ownership-scoped keys (R100). "Do you hold box.manage.own" has
// no unconditional answer — the permission is parameterized by a resource this
// function was never given — and returning true would be precisely the collapse
// of `.own` into an unconditional grant the axis exists to prevent. The caller
// wants authorizeOwned(), which cannot be called without naming the owner.
async function builderHasPermissions(builderId, required) {
  if (!Array.isArray(required) || required.length === 0) return false;
  if (required.some((k) => catalog.isOwnershipScoped(k))) return false;
  const held = new Set(await resolveBuilderPermissions(builderId));
  return required.every((k) => held.has(k));
}

// ── the OWNERSHIP axis (R100, ADR 0151 §3) ──────────────────────────────────────
// The third entry point, and a SEPARATE one for the same reason the principal axis
// is separate: an ownership-scoped permission is a conjunction of two facts from
// two different places, and folding it into the plain resolve would silently drop
// the second one.
//
//   1. the ROLE fact  — does the builder hold the key? (this file, from the DB)
//   2. the OWNER fact — is the concrete row theirs? (REQUEST-scoped; only the
//                       handler that loaded the row knows it)
//
// The resolver structurally cannot know (2): it is handed a builder id, never a
// box/claim/memory row. So the caller SUPPLIES the owner and the model refuses to
// answer without it — `ownerId` is not an option, it is the second half of the
// question. That is what keeps `.own` from degrading into `.any`: there is no code
// path here that turns an ownership-scoped key into an admit on its own.
//
// Pure + DB-free where it can be: the comparison below never touches Postgres, and
// the role fact reuses resolveBuilderPermissions, so ADR 0016 holds unchanged —
// per-request, server-side, no stored answer.

// The owner comparison, normalized once so ~15 sites stop hand-rolling it. STRICT:
// only a scalar id (Postgres hands bigints back as strings, JS code carries them as
// numbers, so 7 and '7' must match) — anything else, including null/undefined, an
// object, an array, a boolean, NaN or an empty/blank string, has NO identity and
// therefore matches NOTHING. No trimming and no case-folding: normalizing harder
// than the data warrants is how a comparison quietly widens.
function ownerIdentity(value) {
  if (typeof value === 'number') return Number.isFinite(value) ? String(value) : null;
  if (typeof value === 'bigint') return String(value);
  if (typeof value === 'string') return value === '' ? null : value;
  return null;
}
function sameOwner(a, b) {
  const left = ownerIdentity(a);
  const right = ownerIdentity(b);
  return left !== null && right !== null && left === right;
}

// Does this builder hold `key` AND own the resource `ownerId` identifies?
// Fail-closed on every unhappy path — an unknown key, a key that is NOT
// ownership-scoped (wrong entry point; the plain resolve answers those), a missing
// or unidentifiable owner, or a builder who simply does not hold the key.
async function authorizeOwned(builderId, key, context) {
  const permission = catalog.byKey(key);
  if (!permission || permission.scope !== 'own') return false;
  if (!sameOwner(context && context.ownerId, builderId)) return false;
  return (await resolveBuilderPermissions(builderId)).includes(key);
}

// The composition every own-scoped route actually wants: reach this row because it
// is YOURS, or because you hold the cross-owner permission over its resource
// family (claim.release.any, memory.read.any, box.fleet.manage). One resolve, both
// branches. A resource with no cross-owner form by design (credential) simply has
// no second branch, so the answer stays own-only.
async function authorizeOwnedOrAny(builderId, ownKey, context) {
  const permission = catalog.byKey(ownKey);
  if (!permission || permission.scope !== 'own') return false;
  const held = await resolveBuilderPermissions(builderId);
  if (catalog.crossOwnerKeysFor(ownKey).some((k) => held.includes(k))) return true;
  return sameOwner(context && context.ownerId, builderId) && held.includes(ownKey);
}

// ── the SESSION-SCOPE axis (R99, ADR 0151 §3) ───────────────────────────────────
// The FOURTH entry point, separate for the same reason the other three are: it
// answers a different question with a different input. Roles answer "what may this
// PERSON do"; a principal answers "what may this MACHINE do"; an ownership scope
// answers "whose row may it be done to"; a session-scope answers "how much of that
// does THIS CREDENTIAL carry". A dev-box token is minted onto a machine outside the
// ADR 0016 trust boundary (#919/SR#2, ADR 0053), so it must stay limited even when
// its builder is an Archon — which no role-shaped answer can express.
//
// A SESSION-SCOPE CAN ONLY EVER NARROW, in both directions:
//   • INTERSECTION, never union. The scope may not GRANT a permission the roles do
//     not confer — so the composition below is written as a FILTER of the ROLE
//     answer. There is no branch here that can add a key, which is what makes
//     "a box token cannot escalate" structural rather than merely intended.
//   • DENY-BY-DEFAULT. A key the allow-list does not name is denied; an
//     unrecognised session source resolves to NOTHING rather than to "full".
// Widening is therefore not expressible without deleting the filter, and R103's
// parity is untouched: effectivePermissions is the unchanged ROLE answer this
// composes ON TOP of, never inside.
//
// Pure and DB-free (the DB half is resolveBuilderPermissions'), so an unknown key
// on an allow-list is inert as well as refused at load: it can never appear in the
// catalog-filtered role answer, so it can never survive the intersection.
function narrowToSessionScope(rawKeys, source) {
  const scope = sessionScopes.scopeFor(source);
  if (!scope) return Object.freeze([]); // unrecognised source → no authority at all
  const held = effectivePermissions(rawKeys);
  if (scope.unscoped) return held; // this credential narrows nothing (cli/web)
  const allowed = new Set(scope.permissions);
  return Object.freeze(held.filter((key) => allowed.has(key)));
}

// What can THIS SESSION actually do? The builder's roles ∩ this session's scope,
// as a frozen sorted array of catalog keys. Fails closed BEFORE touching the DB on
// a source the registry does not declare.
async function resolveSessionPermissions(builderId, source) {
  if (!sessionScopes.scopeFor(source)) return Object.freeze([]);
  return narrowToSessionScope(await resolveBuilderPermissions(builderId), source);
}

module.exports = {
  resolveBuilderPermissions,
  builderHasPermissions,
  effectivePermissions,
  resolvePrincipalPermissions,
  principalHasPermission,
  sameOwner,
  authorizeOwned,
  authorizeOwnedOrAny,
  narrowToSessionScope,
  resolveSessionPermissions,
};
