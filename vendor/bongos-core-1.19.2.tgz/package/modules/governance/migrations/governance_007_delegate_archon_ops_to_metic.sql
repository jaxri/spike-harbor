-- governance_007_delegate_archon_ops_to_metic.sql — grant the Metic rank-role the
-- twenty permissions ADR 0157 lowered archon→metic, plus the new `gate_approval.read`
-- (task 1002584).
--
-- Owner decision (2026-08-05): the Archon rank is responsible for RANK and IDENTITY
-- only. `catalog.js` moved twenty operational floors archon→metic to match, and split
-- `gate_approval.read` out of `gate_approval.decide` so the Gate page can open to Metic
-- while approving a held PR stays Archon.
--
-- The compat seed (governance_002) is RUN-ONCE, so a floor change cannot be made by
-- editing it — every already-migrated database would keep the old grant. This is the
-- follow-on grant migration the 002 header calls for, and it follows
-- governance_003_task_abandon_metic.sql (the ADR 0152 worked example) exactly.
--
-- Additive only: `archon` already holds all twenty (the seeded roles are cumulative
-- supersets), so lowering each floor adds exactly one grant — metic — and revokes
-- nothing. `gate_approval.read` is genuinely new, so it is granted to BOTH metic and
-- archon to keep archon ⊇ metic. Idempotent (ON CONFLICT DO NOTHING); forward-safe
-- (INSERT only, no dropped or retyped state).
--
-- The drift guard (tests/governance_seed.mjs) reads the UNION of the seed and every
-- later governance_* grant migration, so this file is what keeps the SQL snapshot equal
-- to catalog.js's floor-derived RANK_ROLE_SEED.
--
-- NOT here, deliberately: `version.close` and the four escalation keys
-- (`task.confirm.grade_bypass`, `gate_approval.decide`, `goal.scope.manage`,
-- `governance.manage`) stay Archon — see ADR 0157 for why moving any one of them would
-- make this delegation self-reversible. `dependency.cross_tier.manage` also stays: it is
-- system:true, and granting a system key to metic violates the catalog's own invariant.

BEGIN;

INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'metic', unnest(ARRAY[
  -- admin ops (spend, adjudicate, operate) — none decides who holds authority
  'builder.budget.set',
  'builder.roster.read',
  'security.report.adjudicate',
  'provisioning.fleet.manage',
  'box.fleet.manage',
  'autonomy.precheck',
  'discord.channels.manage',
  'project.curate',
  -- work disposition
  'criterion.unsatisfy',
  'version.create',
  'override_request.decide',
  'claim.release.any',
  'idea.ratify',
  'task.newcomer_restock',
  'task.peer_votes.tally',
  'goal.reorder',
  -- reads
  'session.search',
  'memory.read.any',
  'audit_log.read',
  -- surfaces
  'page.view.governance',
  'gate_approval.read'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

-- `gate_approval.read` is a NEW catalog key, so archon does not already hold it from
-- governance_002. Granted here to preserve the cumulative-superset invariant
-- (tests/governance_catalog.mjs: archon ⊇ metic ⊇ thetes ⊇ xenos).
INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'archon', unnest(ARRAY[
  'gate_approval.read'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

COMMIT;
