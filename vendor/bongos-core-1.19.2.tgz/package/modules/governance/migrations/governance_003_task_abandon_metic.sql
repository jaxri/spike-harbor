-- governance_003_task_abandon_metic.sql — grant `task.abandon` to the Metic rank-role
-- (ADR 0152; task 1002476).
--
-- The abandon route was re-ranked Archon→Metic+ in the code gate, and the catalog's
-- floor for `task.abandon` moved archon→metic to match. The compat seed
-- (governance_002) is RUN-ONCE, so a floor change cannot be made by editing it —
-- every already-migrated database would keep the old grant. This is the follow-on
-- grant migration the 002 header calls for ("a NEW permission granted to a seeded
-- role is a NEW migration, not an edit here").
--
-- Additive only: `archon` already holds `task.abandon` (the seeded roles are
-- cumulative supersets), so lowering the floor adds exactly one grant — metic —
-- and revokes nothing. Idempotent (ON CONFLICT DO NOTHING); forward-safe (INSERT
-- only, no dropped or retyped state).
--
-- The drift guard (tests/governance_seed.mjs) reads the UNION of the seed and every
-- later governance_* grant migration, so this file is what keeps the SQL snapshot
-- equal to catalog.js's floor-derived RANK_ROLE_SEED.

BEGIN;

INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'metic', unnest(ARRAY[
  'task.abandon'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

COMMIT;
