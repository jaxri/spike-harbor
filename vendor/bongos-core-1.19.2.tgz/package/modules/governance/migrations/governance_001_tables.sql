-- governance_001_tables.sql — the `governance` module's DB slice (ADR 0151, BV1.R93).
--
-- The live home for configurable roles/permissions: assignable roles, the role→
-- permission grants, and builder→role assignments. This is the DB half of the
-- permissions-as-atom model; the permission CATALOG itself is CODE
-- (modules/governance/catalog.js — a permission maps to a real route, so it is not
-- UI-invented data), so `permission_key` here is a string validated app-side against
-- the catalog, deliberately NOT a foreign key to a permissions table.
--
-- Preserves ADR 0016: authority is still resolved server-side, per request, uncached
-- (R95). These tables only hold the role definitions + assignments the resolver unions;
-- they grant nothing on their own.
--
-- Module migrations are ADDITIVE and NAMESPACED (ADR 0083 §Decision #5): every object
-- is governance_-prefixed, there is no down-migration, and the filename is
-- governance_-prefixed (ADR 0108 §5) so its stem never collides across repos.
-- `scripts/migrate.sh` discovers + applies this when the governance module is enabled
-- (default:true). Idempotent: safe to re-run.

BEGIN;

-- ---------------------------------------------------------------------------
-- governance_roles — an assignable role. Four are seeded as the compat rank-roles
-- (is_system=true, seeded_rank set); the rest are Archon-authored custom roles.
-- role_key is the stable natural key the other two tables reference.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance_roles (
  id            bigserial PRIMARY KEY,
  -- stable slug: 'xenos'/'thetes'/'metic'/'archon' for the seeded rank-roles, or a
  -- kebab-case slug for an Archon-created custom role.
  role_key      text NOT NULL UNIQUE,
  label         text NOT NULL,
  description   text,
  -- for a seeded rank-role: the rank it reproduces (xenos/thetes/metic/archon);
  -- NULL for a custom role. Kept so the resolver + tab can recognise the four
  -- protected rank-roles (they cannot be deleted/renamed via the tab).
  seeded_rank   text,
  -- true for the four seeded rank-roles — a system role the tab renders but cannot
  -- delete/rename. Custom roles are false.
  is_system     boolean NOT NULL DEFAULT false,
  -- who authored a custom role (NULL for the seeded rank-roles).
  created_by    bigint REFERENCES builders(id) ON DELETE SET NULL,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);

-- ---------------------------------------------------------------------------
-- governance_role_permissions — the grants: which permission KEYS a role holds.
-- permission_key is a catalog key (modules/governance/catalog.js), validated
-- app-side (NOT a FK — the catalog is code, not a table). The governance API (R110)
-- refuses to insert a `system` permission for a custom role; the seeded rank-roles
-- legitimately hold their archon-floored system perms.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance_role_permissions (
  role_key       text NOT NULL REFERENCES governance_roles(role_key) ON DELETE CASCADE,
  permission_key text NOT NULL,
  granted_at     timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (role_key, permission_key)
);

CREATE INDEX IF NOT EXISTS governance_role_permissions_perm_idx
  ON governance_role_permissions (permission_key);

-- ---------------------------------------------------------------------------
-- governance_builder_roles — builder→role assignments. The resolver (R95) unions
-- the permissions of every role a builder holds. The compat seed backfills exactly
-- one role per builder (their rank-role) so day-one behaviour is identical.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS governance_builder_roles (
  builder_id   bigint NOT NULL REFERENCES builders(id) ON DELETE CASCADE,
  role_key     text NOT NULL REFERENCES governance_roles(role_key) ON DELETE CASCADE,
  -- who assigned this role (NULL for the compat-seed backfill).
  assigned_by  bigint REFERENCES builders(id) ON DELETE SET NULL,
  assigned_at  timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (builder_id, role_key)
);

CREATE INDEX IF NOT EXISTS governance_builder_roles_role_idx
  ON governance_builder_roles (role_key);

COMMIT;
