-- governance_005_resync_builder_rank_roles.sql — repair drifted builder→role
-- assignments (ADR 0151, BV1.R95b).
--
-- governance_002 backfilled every builder the seeded role matching their rank, but
-- it is run-once and nothing kept it true afterwards: the only write to
-- governance_builder_roles in the repo WAS that backfill. So by now the table can
-- hold two kinds of wrong row:
--   • MISSING — a builder admitted after 002 ran has no role at all, and
--     resolveBuilderPermissions() returns the empty set (denied everywhere).
--   • STALE — a builder whose rank CHANGED still holds their OLD rank-role. A
--     demoted Archon keeps resolving Archon permissions, which defeats ADR 0016's
--     "a demotion takes effect on the very next request" promise one layer beneath
--     the (correctly uncached) resolver. This is the security half.
--
-- BV1.R95b closes the hole going forward (the two _applyRankChangeTx twins rotate
-- the role inside the rank transaction, and sign-in assigns it at registration);
-- this migration repairs the rows already written.
--
-- IDEMPOTENT: the DELETE only matches rows that disagree with builders.rank and the
-- INSERT is ON CONFLICT DO NOTHING, so a second run changes nothing.
--
-- ADDITIVE per ADR 0083 §Decision #5: no DDL at all, no down path, every object it
-- names is governance_-prefixed or the core `builders` table it reads. It touches
-- governance_builder_roles (ASSIGNMENTS) and NOT governance_role_permissions
-- (GRANTS) — so it revokes no grant and the union model tests/governance_seed.mjs
-- builds over the grant migrations is untouched.

BEGIN;

-- 1. Drop every SEEDED rank-role a builder holds that no longer matches their rank.
--    Keyed on is_system + seeded_rank, so an Archon-assigned CUSTOM role
--    (is_system=false) is never caught by it — only the rank-derived role rotates.
--    This clause is the security fix: an additive-only repair would leave the
--    demoted Archon's `archon` row in place, preserving exactly the privilege
--    retention this migration exists to end.
DELETE FROM governance_builder_roles br
 USING governance_roles r, builders b
 WHERE r.role_key = br.role_key
   AND b.id = br.builder_id
   AND r.is_system = true
   AND r.seeded_rank IS NOT NULL
   AND r.seeded_rank IS DISTINCT FROM b.rank;

-- 2. (Re)assign the seeded rank-role matching each builder's CURRENT rank.
--    The INNER JOIN is governance_002's, deliberately: a builder sitting on one of
--    the twelve legacy ranks migration 023's CHECK still admits matches no seeded
--    role, so they get NO row and resolve to zero permissions. That is ADR 0151's
--    intentional fail-closed divergence (stricter than the old latent
--    threshold-admit of an unwired rank) — preserve it; do not invent a grant here.
INSERT INTO governance_builder_roles (builder_id, role_key)
SELECT b.id, r.role_key
  FROM builders b
  JOIN governance_roles r ON r.seeded_rank = b.rank AND r.is_system = true
ON CONFLICT (builder_id, role_key) DO NOTHING;

COMMIT;
