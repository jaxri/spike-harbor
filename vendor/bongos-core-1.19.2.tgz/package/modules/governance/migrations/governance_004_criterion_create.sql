-- governance_004_criterion_create.sql — grant the new `criterion.create` atom to the
-- Metic and Archon rank-roles (ADR 0154; task 1002538).
--
-- `POST /versions/:id/done-when` was re-gated Archon→Metic+ (walled by goal
-- ownership: a non-Archon must name a goal they own or manage, on a building
-- version). In catalog.js the route moved OUT of the bundled `criterion.review`
-- row — where it had been mis-filed while it was still Archon-only (ADR 0154 §5)
-- — and into its own atom, `criterion.create`, floor `metic`.
--
-- Unlike governance_003 (a floor MOVE, where archon already held the key), this is
-- a BRAND-NEW key: no role holds it yet, so both rungs the floor implies are
-- granted here. RANK_ROLE_SEED is a cumulative superset — floor `metic` means
-- {metic, archon} — and the drift guard (tests/governance_seed.mjs) compares the
-- UNION of the run-once seed (governance_002) plus every later grant migration
-- against that floor-derived seed, per role.
--
-- Additive only: one new permission key granted to two roles; nothing is revoked.
-- (`criterion.review` keeps its key and its floor — only its human `guards` note
-- lost the route.) Idempotent (ON CONFLICT DO NOTHING); forward-safe (INSERT only).
--
-- One block PER ROLE, in the governance_003 shape: the drift guard scans for
-- `SELECT '<role>', unnest(ARRAY[…])` literally, so a combined
-- `unnest(ARRAY['metic','archon']), 'key'` form parses as zero grants and reds it.

BEGIN;

INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'metic', unnest(ARRAY[
  'criterion.create'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'archon', unnest(ARRAY[
  'criterion.create'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

COMMIT;
