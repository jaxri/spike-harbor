-- governance_006_version_create.sql — grant the new `version.create` atom to the
-- Archon rank-role (BV1.R105; task 1001847).
--
-- `POST /versions` was the ONE rank-gated module write route the R105 migration could
-- not finish: no catalog atom named version CREATION. `version.close` is a different
-- capability (the close disposition), so the route stayed on requireRank while the
-- other 60 moved. catalog.js now carries `version.create`, floor `archon`,
-- system:false — see the comment beside the row for why it is NOT system:true.
--
-- Same shape as governance_004 (a BRAND-NEW key, not a floor move): no role holds it
-- yet. But floor `archon` is the TOP rung, so the cumulative superset RANK_ROLE_SEED
-- builds contains it for exactly ONE role — hence a single grant block here, where 004
-- needed two.
--
-- THIS MIGRATION IS LOAD-BEARING, not bookkeeping. The seed (governance_002) is
-- run-once, so a database that has already migrated would never learn the new key:
-- the archon rank-role would not hold `version.create`, and the freshly-migrated route
-- would 403 every Archon — locking the instance out of creating versions. The grant
-- has to arrive as its own migration for the change to be behaviour-identical in
-- practice and not just on a fresh install.
--
-- Additive only: one new permission key granted to one role; nothing is revoked.
-- Idempotent (ON CONFLICT DO NOTHING); forward-safe (INSERT only).
--
-- One block PER ROLE, in the governance_003/004 shape: the drift guard
-- (tests/governance_seed.mjs) scans for `SELECT '<role>', unnest(ARRAY[…])` literally,
-- so a combined `unnest(ARRAY['metic','archon']), 'key'` form parses as zero grants
-- and reds it.

BEGIN;

INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'archon', unnest(ARRAY[
  'version.create'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

COMMIT;
