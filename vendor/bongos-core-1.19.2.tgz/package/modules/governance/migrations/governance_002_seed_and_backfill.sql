-- governance_002_seed_and_backfill.sql — the compatibility seed (ADR 0151, BV1.R93).
--
-- Seeds the four rank-roles (xenos/thetes/metic/archon) with the grants that
-- reproduce today's rank thresholds EXACTLY, then backfills every existing builder
-- the role matching their current rank. This is the "zero day-one behavior change"
-- guarantee: after this runs, resolveBuilderPermissions() (R95) returns, for every
-- builder, precisely the powers requireRank granted them before.
--
-- The role→permission grants below are MATERIALISED from the code catalog's
-- RANK_ROLE_SEED (modules/governance/catalog.js), which derives them from each
-- permission's floor (cumulative nested supersets). tests/governance_seed.mjs parses
-- this file and asserts the four arrays equal RANK_ROLE_SEED, so this snapshot can
-- never silently drift from the catalog (the "no second list that drifts" discipline,
-- SEC #863 / R108). A NEW permission granted to a seeded role is a NEW migration, not
-- an edit here (migrations are run-once).
--
-- Idempotent (ON CONFLICT DO NOTHING throughout): safe to re-run.

BEGIN;

-- ── the four seeded rank-roles ────────────────────────────────────────────────
-- Labels are the canonical rank names (portable core); an instance may surface its
-- own display labels via config/governance.json (R96) without changing these keys.
INSERT INTO governance_roles (role_key, label, description, seeded_rank, is_system) VALUES
  ('xenos',  'Xenos',  'Seeded rank-role — the sandboxed entry rank. Own-work + public read.', 'xenos',  true),
  ('thetes', 'Thetes', 'Seeded rank-role — graduated newcomer. Adds the general claim queue.', 'thetes', true),
  ('metic',  'Metic',  'Seeded rank-role — the trusted working rank. Adds review/triage/authoring.', 'metic',  true),
  ('archon', 'Archon', 'Seeded rank-role — top authority. Adds the admin + system (non-grantable) powers.', 'archon', true)
ON CONFLICT (role_key) DO NOTHING;

-- ── the grants (materialised from RANK_ROLE_SEED; guarded by tests/governance_seed.mjs) ──

-- xenos (Xenos) — 12 permissions
INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'xenos', unnest(ARRAY[
  'task.claim.newcomer', 'task.ship', 'task.act.own', 'box.manage.own',
  'memory.manage.own', 'credential.manage.own', 'me.wandering.set', 'cost.log',
  'learning.create', 'blocker.file', 'idea.file', 'page.view.public'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

-- thetes (Thetes) — 14 permissions
INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'thetes', unnest(ARRAY[
  'task.claim.any', 'page.view.builder', 'task.claim.newcomer', 'task.ship',
  'task.act.own', 'box.manage.own', 'memory.manage.own', 'credential.manage.own',
  'me.wandering.set', 'cost.log', 'learning.create', 'blocker.file',
  'idea.file', 'page.view.public'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

-- metic (Metic) — 38 permissions
INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'metic', unnest(ARRAY[
  'idea.triage', 'blocker.review', 'task.create', 'task.edit',
  'task.promote', 'task.demote', 'task.vote', 'task.dependency.manage',
  'task.criterion.manage', 'criterion.satisfy', 'criterion.review', 'planning.run',
  'priority.run', 'goal.create', 'goal.archive', 'goal.scope.widen',
  'module.enable', 'module.submit', 'security.report.file', 'llm_cache.use',
  'backup.manage', 'source.clone.local', 'box.source.full', 'task.claim.any',
  'page.view.builder', 'goal.manage.own', 'task.claim.newcomer', 'task.ship',
  'task.act.own', 'box.manage.own', 'memory.manage.own', 'credential.manage.own',
  'me.wandering.set', 'cost.log', 'learning.create', 'blocker.file',
  'idea.file', 'page.view.public'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

-- archon (Archon) — 71 permissions
INSERT INTO governance_role_permissions (role_key, permission_key)
SELECT 'archon', unnest(ARRAY[
  'builder.rank.set', 'version.close', 'task.confirm.grade_bypass', 'dependency.cross_tier.manage',
  'goal.scope.manage', 'governance.manage', 'gate_approval.decide', 'deploy.push_main',
  'path.protected.modify', 'infra.ssh', 'builder.status.set', 'builder.budget.set',
  'task.abandon', 'criterion.unsatisfy', 'auth.session.revoke', 'access_request.review',
  'security.report.adjudicate', 'provisioning.fleet.manage', 'box.fleet.manage', 'autonomy.precheck',
  'discord.channels.manage', 'project.curate', 'override_request.decide', 'claim.release.any',
  'idea.ratify', 'task.newcomer_restock', 'task.peer_votes.tally', 'goal.reorder',
  'builder.roster.read', 'session.search', 'memory.read.any', 'audit_log.read',
  'idea.triage', 'blocker.review', 'task.create', 'task.edit',
  'task.promote', 'task.demote', 'task.vote', 'task.dependency.manage',
  'task.criterion.manage', 'criterion.satisfy', 'criterion.review', 'planning.run',
  'priority.run', 'goal.create', 'goal.archive', 'goal.scope.widen',
  'module.enable', 'module.submit', 'security.report.file', 'llm_cache.use',
  'backup.manage', 'source.clone.local', 'box.source.full', 'task.claim.any',
  'page.view.builder', 'goal.manage.own', 'task.claim.newcomer', 'task.ship',
  'task.act.own', 'box.manage.own', 'memory.manage.own', 'credential.manage.own',
  'me.wandering.set', 'cost.log', 'learning.create', 'blocker.file',
  'idea.file', 'page.view.public', 'page.view.governance'
])
ON CONFLICT (role_key, permission_key) DO NOTHING;

-- ── backfill: every builder gets the role matching their current rank ─────────
-- The JOIN admits only builders whose rank IS one of the four seeded rank-roles.
-- A builder on a reserved/unwired rank (none exist today — verified) gets NO row and
-- resolves to zero permissions: the deliberate fail-closed divergence of ADR 0151
-- (stricter than today's latent threshold-admit of an unwired rank).
INSERT INTO governance_builder_roles (builder_id, role_key)
SELECT b.id, b.rank
FROM builders b
JOIN governance_roles r ON r.role_key = b.rank AND r.is_system = true
ON CONFLICT (builder_id, role_key) DO NOTHING;

COMMIT;
