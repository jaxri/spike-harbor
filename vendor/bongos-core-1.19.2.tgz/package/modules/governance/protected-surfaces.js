'use strict';

// modules/governance/protected-surfaces.js — the protected-surface registry's
// GOVERNANCE-side API (ADR 0151 §4, BV1.R101).
//
// POLICY OWNS / SUBSTRATE ENFORCES — the whole point of this slice.
//
//   GOVERNANCE OWNS THE DATA. protected-surfaces.json (next to this file) says
//   WHICH repo paths are protected, at WHAT rank floor, mapped to WHICH
//   `system: true` catalog permission. That file is the source of truth; the
//   Archon governance tab (R110/R111) edits it as policy. Before R101 the same
//   information was a hardcoded PROTECTED_GLOBS constant inside the kernel.
//
//   THE OUT-OF-BAND SUBSTRATE STAYS THE ENFORCER. Nothing here enforces
//   anything. The enforcers are the git pre-push hook, the grader pre-pass, the
//   post-push main audit, gate-review.js and the goal-scope check — they read
//   the registry with no DB, no server and no HTTP, and they are what actually
//   blocks a sub-floor change (ADR 0043). Re-mapping a floor here changes what
//   the substrate protects; it can never make the request path the authority.
//   Moving enforcement into the app is the regression R101 exists to prevent
//   (ADR 0151 §"Alternatives considered").
//
//   NO DB DEPENDENCY. A DB-backed override is a governance-tab concern layered
//   on top and must never become a dependency of the hook — the hook runs on a
//   laptop with no database and no network. This module is therefore
//   synchronous, DB-free and requires nothing but the catalog and the doorway.
//
// DEPENDENCY DIRECTION (ADR 0083's one-way rule). Code flows exactly one way:
// this module → src/module-api.js (the published doorway) → the kernel matcher
// in src/bongos/permission-path-check.js. Core never requires this module. The
// kernel loads the JSON data file directly (a static data read, the same way the
// sibling trust primitive route-rank-check.js reads modules/*/routes/*.js off
// disk to rank-gate them), and we read the parsed result back through the
// doorway so there is exactly ONE loader and ONE matcher — no second list to
// drift (the SEC #863 failure mode).

const api = require('../../src/module-api');
const catalog = require('./catalog');

const ppc = api.permissionPathCheck;

// The registry, as parsed by the single kernel loader.
const SURFACES = ppc.PROTECTED_SURFACES;

// ── invariants asserted at module load (fail loud on an authoring typo) ───────
// The governance module is where the registry meets the permission catalog, so
// this is where "every protected surface maps to a real, non-grantable
// permission" is checked. A surface mapping to an unknown key, or to a
// `system: false` (grantable) key, would mean an Archon could hand a custom role
// the power the substrate is supposed to reserve — exactly the wall ADR 0151 §4
// builds. Fail loud rather than silently protecting nothing.
for (const s of SURFACES) {
  const perm = catalog.byKey(s.permission);
  if (!perm) {
    throw new Error(`protected-surface registry: "${s.glob}" maps to "${s.permission}", which the permission catalog does not define`);
  }
  if (perm.system !== true) {
    throw new Error(`protected-surface registry: "${s.glob}" maps to "${s.permission}", which is not system:true — a protected surface must map to a NON-GRANTABLE permission (ADR 0151 §4)`);
  }
  if (!catalog.RANK_ORDER.includes(s.floor)) {
    throw new Error(`protected-surface registry: "${s.glob}" declares floor "${s.floor}", which is not a rank`);
  }
}

// The lowest floor any surface declares — 'metic' today (ADR 0043's Metic floor,
// now DERIVED from registry data rather than hardcoded).
const FLOOR = catalog.RANK_ORDER[Math.min(...SURFACES.map((s) => catalog.RANK_ORDER.indexOf(s.floor)))];

// The distinct system permissions the registry maps onto.
const SYSTEM_PERMISSIONS = Object.freeze([...new Set(SURFACES.map((s) => s.permission))].sort());

// Per-path lookups — the single matcher, reached through the doorway.
const surfaceFor = (file) => ppc.surfaceFor(file);
const floorFor = (file) => ppc.floorFor(file);
const permissionFor = (file) => ppc.permissionFor(file);
const isProtected = (file) => ppc.surfaceFor(file) !== null;

module.exports = {
  SURFACES,
  PROTECTED_GLOBS: ppc.PROTECTED_GLOBS,
  REGISTRY_PATH: ppc.REGISTRY_PATH,
  FLOOR,
  SYSTEM_PERMISSIONS,
  surfaceFor,
  floorFor,
  permissionFor,
  isProtected,
};
