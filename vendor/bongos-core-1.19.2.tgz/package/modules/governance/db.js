'use strict';

// modules/governance/db.js — the governance db slice (ADR 0151, BV1.R95).
//
// Reads the role/grant/assignment rows governance_001_tables.sql defines. The
// per-domain db-slice pattern (ADR 0091 §2): the pool comes through the published
// doorway (src/module-api.js), never `../../src/bongos/db`.
//
// NO CACHING, deliberately. Every read here runs against the live DB on the
// request that needs it, so a revoked role takes effect on the builder's very
// next request — the ADR 0016 trust-boundary rule the resolver inherits.

const { pool } = require('../../src/module-api');
const { planRankRoleSync } = require('./rank-roles');

// Every permission_key granted to any role the builder holds. Duplicates across
// roles are collapsed by the DISTINCT — the resolver's UNION semantics. Returns
// a flat array of raw key strings (validated against the catalog by resolver.js);
// [] for a builder with no roles, which fails closed to zero authority.
async function getPermissionKeysForBuilder(builderId) {
  const { rows } = await pool.query(
    `SELECT DISTINCT rp.permission_key
       FROM governance_builder_roles br
       JOIN governance_role_permissions rp ON rp.role_key = br.role_key
      WHERE br.builder_id = $1`,
    [builderId],
  );
  return rows.map((r) => r.permission_key);
}

// The role keys a builder holds, for introspection surfaces (the Archon tab,
// R110/R111) and for explaining a 403. Not part of the resolve path.
async function getRoleKeysForBuilder(builderId) {
  const { rows } = await pool.query(
    `SELECT role_key FROM governance_builder_roles WHERE builder_id = $1 ORDER BY role_key`,
    [builderId],
  );
  return rows.map((r) => r.role_key);
}

// --- the rank→role WRITE half (BV1.R95b) ------------------------------------
//
// Everything above this line only READS. Until R95b the only write to
// governance_builder_roles in the whole repo was governance_002's run-once
// backfill, so a builder created after it had NO role (locked out of every
// permission gate) and a builder whose rank CHANGED kept their OLD rank-role
// (a demoted Archon still resolving Archon permissions — the ADR 0016 defect).
//
// The writer below is a TRANSACTION PARTICIPANT: every caller hands it the client
// its own BEGIN/COMMIT is running on, so the role rotation commits — or rolls back
// — atomically with the rank write it accompanies. Core reaches it through the
// `governance.roleSync` kernel port (routes/role-sync.js); it never imports this
// module (ADR 0083).

// The seeded rank-roles as the DB actually defines them. Read per call rather than
// cached: it is the same authority data the resolver refuses to memoise, and this
// runs on rank writes + sign-in, never in a hot loop.
async function getSeededRankRoles(q) {
  const { rows } = await q.query(
    `SELECT role_key, seeded_rank, is_system
       FROM governance_roles
      WHERE is_system = true AND seeded_rank IS NOT NULL`,
  );
  return rows;
}

// A builder's assignments joined to their role definitions, so the plan can tell a
// seeded rank-role from an Archon-assigned custom one.
async function getRoleAssignmentsForBuilder(q, builderId) {
  const { rows } = await q.query(
    `SELECT br.role_key, r.is_system, r.seeded_rank
       FROM governance_builder_roles br
       JOIN governance_roles r ON r.role_key = br.role_key
      WHERE br.builder_id = $1`,
    [builderId],
  );
  return rows;
}

// syncRankRole(client, { builderId, rank }) — make the builder's seeded rank-role
// match `rank`: add the matching one, DELETE every other seeded one, leave custom
// roles alone. `client` is the caller's open transaction client; pass null/undefined
// to run on the pool (the sign-in path, which has no surrounding transaction).
//
// Idempotent — a builder whose role already matches costs two SELECTs and no write,
// so calling it on every sign-in quietly repairs drift instead of accumulating it.
// The DELETE is keyed on the plan's `remove` list, which is built only from rows the
// join proved are is_system seeded roles, so a custom role can never be caught by it.
// assigned_by is left NULL: a rank-derived assignment is the system's, not a person's
// (governance_002's backfill uses the same convention; the human decision is audited
// in credit_log's rank_change row).
async function syncRankRole(client, { builderId, rank } = {}) {
  if (builderId === null || builderId === undefined || builderId === '') {
    return { target: null, added: [], removed: [] };
  }
  const q = client || pool;
  const seededRoles = await getSeededRankRoles(q);
  const currentRoles = await getRoleAssignmentsForBuilder(q, builderId);
  const plan = planRankRoleSync({ rank, currentRoles, seededRoles });

  if (plan.remove.length > 0) {
    await q.query(
      `DELETE FROM governance_builder_roles
        WHERE builder_id = $1 AND role_key = ANY($2::text[])`,
      [builderId, [...plan.remove]],
    );
  }
  if (plan.add.length > 0) {
    await q.query(
      `INSERT INTO governance_builder_roles (builder_id, role_key)
       SELECT $1, unnest($2::text[])
       ON CONFLICT (builder_id, role_key) DO NOTHING`,
      [builderId, [...plan.add]],
    );
  }
  return { target: plan.target, added: [...plan.add], removed: [...plan.remove] };
}

// --- the R110 CRUD surface (roles / grants / assignments) --------------------
//
// The db half of the governance API routes. Deliberately DUMB writes: the
// authority invariants (system perms non-grantable, seeded rank-roles immutable
// through the API) are enforced in routes/governance.js against the catalog —
// the same split governance_001 documents (permission_key is validated app-side,
// not a FK). Grant/assign are ON CONFLICT DO NOTHING so the tab's toggle is
// idempotent; each returns whether a row actually changed.

async function listRolesWithGrants() {
  const { rows } = await pool.query(
    `SELECT r.role_key, r.label, r.description, r.is_system, r.seeded_rank,
            r.created_by, r.created_at,
            COALESCE(array_agg(rp.permission_key ORDER BY rp.permission_key)
                     FILTER (WHERE rp.permission_key IS NOT NULL), '{}') AS permissions
       FROM governance_roles r
       LEFT JOIN governance_role_permissions rp ON rp.role_key = r.role_key
      GROUP BY r.id
      ORDER BY r.is_system DESC, r.role_key`,
  );
  return rows;
}

async function getRoleByKey(roleKey) {
  const { rows } = await pool.query(
    `SELECT role_key, label, description, is_system, seeded_rank, created_by, created_at
       FROM governance_roles
      WHERE role_key = $1`,
    [roleKey],
  );
  return rows[0] ?? null;
}

async function createRole({ roleKey, label, description, createdBy }) {
  const { rows } = await pool.query(
    `INSERT INTO governance_roles (role_key, label, description, is_system, seeded_rank, created_by)
     VALUES ($1, $2, $3, false, NULL, $4)
     RETURNING role_key, label, description, is_system, seeded_rank, created_by, created_at`,
    [roleKey, label, description ?? null, createdBy],
  );
  return rows[0];
}

async function grantRolePermission({ roleKey, permissionKey }) {
  const { rowCount } = await pool.query(
    `INSERT INTO governance_role_permissions (role_key, permission_key)
     VALUES ($1, $2)
     ON CONFLICT (role_key, permission_key) DO NOTHING`,
    [roleKey, permissionKey],
  );
  return rowCount > 0;
}

async function revokeRolePermission({ roleKey, permissionKey }) {
  const { rowCount } = await pool.query(
    `DELETE FROM governance_role_permissions
      WHERE role_key = $1 AND permission_key = $2`,
    [roleKey, permissionKey],
  );
  return rowCount > 0;
}

async function listAssignments() {
  const { rows } = await pool.query(
    `SELECT br.builder_id, b.github_login, b.display_name, b.rank,
            br.role_key, r.label AS role_label, r.is_system, r.seeded_rank,
            br.assigned_by, br.assigned_at
       FROM governance_builder_roles br
       JOIN builders b ON b.id = br.builder_id
       JOIN governance_roles r ON r.role_key = br.role_key
      ORDER BY br.builder_id, br.role_key`,
  );
  return rows;
}

async function assignRole({ builderId, roleKey, assignedBy }) {
  const { rowCount } = await pool.query(
    `INSERT INTO governance_builder_roles (builder_id, role_key, assigned_by)
     VALUES ($1, $2, $3)
     ON CONFLICT (builder_id, role_key) DO NOTHING`,
    [builderId, roleKey, assignedBy],
  );
  return rowCount > 0;
}

async function unassignRole({ builderId, roleKey }) {
  const { rowCount } = await pool.query(
    `DELETE FROM governance_builder_roles
      WHERE builder_id = $1 AND role_key = $2`,
    [builderId, roleKey],
  );
  return rowCount > 0;
}

module.exports = {
  getPermissionKeysForBuilder,
  getRoleKeysForBuilder,
  getSeededRankRoles,
  getRoleAssignmentsForBuilder,
  syncRankRole,
  listRolesWithGrants,
  getRoleByKey,
  createRole,
  grantRolePermission,
  revokeRolePermission,
  listAssignments,
  assignRole,
  unassignRole,
};
