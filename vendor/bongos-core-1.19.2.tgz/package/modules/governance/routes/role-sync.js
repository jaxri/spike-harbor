'use strict';

// The governance module's rank-role SYNC port (ADR 0151, BV1.R95b).
//
// A second, deliberately tiny kernel port beside `governance` (routes/governance.js).
// `governance` is the READ surface every gate resolves on every request; this is the
// single WRITE core needs — "this builder's rank is now X, make their seeded
// rank-role match". They are kept apart on purpose:
//   • the read port is on the hot path of every permission-gated request and is
//     resolved by requirePermission(); a mutation has no business hanging off it;
//   • this one is resolved by exactly three writers (the two _applyRankChangeTx
//     twins + the sign-in path) and is a TRANSACTION PARTICIPANT — it takes the
//     caller's client so the role rotation commits or rolls back with the rank write.
// The port name is namespaced (`governance.roleSync`) like the `ideas.capture` /
// `art.getBuilderGeminiKeyRow` / `grade.builderRollingAvgGrade` ports.
//
// Registered from a route factory for the same reason routes/governance.js is:
// mountModuleRoutes is the one boot hook that runs BOTH in the live server and
// whenever a test rebuilds the router, and registration is hasProvider-guarded so a
// rebuild never trips the seam's single-provider duplicate guard.
//
// The router is EMPTY and must stay empty. Rank-derived assignment is automatic and
// has no HTTP surface; the MANUAL assignment CRUD is R110's Archon-gated tab on the
// governance router. An endpoint here would be a way to hand out a rank-role without
// changing the rank.

const express = require('express');
const api = require('../../../src/module-api');
const db = require('../db');

// DELEGATE, never spread — a test that stubs db.syncRankRole must still bite at call
// time (the modules/onboarding/port.js precedent; a spread captures the original
// reference at module-load).
const rankRoleSyncPort = {
  syncRankRole: (...a) => db.syncRankRole(...a),
};

function registerSeams() {
  if (!api.hasProvider('governance.roleSync')) {
    api.registerProvider('governance.roleSync', rankRoleSyncPort);
  }
}

module.exports = function buildGovernanceRoleSyncRouter() {
  registerSeams();
  return express.Router();
};

module.exports.rankRoleSyncPort = rankRoleSyncPort;
