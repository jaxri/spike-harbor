'use strict';

// The governance module's kernel PORT registration (ADR 0151, BV1.R95).
//
// governance exposes the permission RESOLVER as the `governance` kernel PORT.
// CORE files that must NOT import a module resolve it instead — first among them
// src/bongos/auth.js, whose `requirePermission()` gate (R97) needs a builder's
// effective permission set on every gated request. The one-way rule (ADR 0083)
// forbids core requiring modules/governance/ directly; the port is how the
// capability crosses that line.
//
// Why a route factory for a (currently) routeless capability: `mountModuleRoutes`
// is the one boot hook that runs BOTH in the live server AND whenever a test
// rebuilds the GDS router, so registering here keeps the port present for the
// route-building tests too. Registration is hasProvider-guarded so
// re-instantiation never trips the seam's single-provider duplicate guard.
// (Mirrors modules/economy/routes/reward.js.) The R110 governance CRUD
// endpoints live on this same router, below.

const express = require('express');
const api = require('../../../src/module-api');
const resolver = require('../resolver');
const catalog = require('../catalog');
const db = require('../db');
const sessionScopes = require('../session-scopes');

// The port surface. Deliberately narrow: resolution + the catalog reads a gate or
// the Archon tab needs. It grows with R98-R101 (principals, session-scopes,
// ownership scoping, the protected-surface registry) — one object port rather
// than a port per capability, so core resolves `governance` once.
//
// The principal half (R98) is READ-ONLY by construction: resolution keyed on an
// exact system_role, plus `listPrincipals` for the tab to render. There is no
// create/grant/assign counterpart and there must never be one — a principal is
// provisioned out-of-band in `builders.system_role` (migration + DB CHECK
// allowlist), so the tab can SHOW a principal but has nothing to call to make one.
//
// The ownership half (R100) is why an own-scoped route reaches the port from
// INSIDE its handler rather than from a middleware: the second half of the
// decision is the concrete row's owner, which only the handler that loaded the row
// knows. `authorizeOwned`/`authorizeOwnedOrAny` take that owner as an argument, so
// there is no arity at which an ownership-scoped key resolves to an admit on its
// own (ADR 0151 §3's in-handler pure-gate pattern, made a first-class call).
// Callers must fail CLOSED when the port is absent, exactly as requirePermission
// does — a missing authority system is a denial, never an admission.
//
// The session-scope half (R99) is READ-ONLY and deliberately NOT the enforcement
// path: the kernel gate (auth.requireBuilder) reads the same registry as static
// data, so a request never depends on this port being registered to stay
// deny-by-default. What the port adds is the composed answer — roles ∩ this
// session's scope — for the governance tab and for any gate that wants the
// session's real authority rather than the builder's.
const governancePort = {
  resolveBuilderPermissions: resolver.resolveBuilderPermissions,
  // The pure catalog-drop half, for the session-load fold (task 1002556): the
  // kernel feeds it the raw grant keys its own session query carried, so a
  // permission gate needs no second round-trip. Same answer as
  // resolveBuilderPermissions given the same rows — DB-free by construction.
  effectivePermissions: resolver.effectivePermissions,
  builderHasPermissions: resolver.builderHasPermissions,
  getRoleKeysForBuilder: db.getRoleKeysForBuilder,
  isSystem: catalog.isSystem,
  isGrantable: catalog.isGrantable,
  permissionKeys: catalog.permissionKeys,
  resolvePrincipalPermissions: resolver.resolvePrincipalPermissions,
  principalHasPermission: resolver.principalHasPermission,
  isPrincipalKey: catalog.isPrincipalKey,
  listPrincipals: catalog.principals,
  authorizeOwned: resolver.authorizeOwned,
  authorizeOwnedOrAny: resolver.authorizeOwnedOrAny,
  sameOwner: resolver.sameOwner,
  isOwnershipScoped: catalog.isOwnershipScoped,
  crossOwnerKeysFor: catalog.crossOwnerKeysFor,
  resolveSessionPermissions: resolver.resolveSessionPermissions,
  narrowToSessionScope: resolver.narrowToSessionScope,
  sessionScopeFor: sessionScopes.scopeFor,
  listSessionScopes: () => sessionScopes.SESSION_SCOPES,
};

function registerSeams() {
  if (!api.hasProvider('governance')) {
    api.registerProvider('governance', governancePort);
  }
  // The session-load fold (task 1002556): the kernel's lookupSession embeds this
  // fragment so the SAME round-trip carries the builder's raw grant keys, and
  // requirePermission runs the pure effectivePermissions instead of a second
  // query. Registered HERE — capability-named, module-agnostic on the kernel
  // side (ADR 0083 §Decision #4) — because this module owns the governance SQL.
  // Contract: a boot-time CONSTANT (never user input) yielding one
  // `raw_permission_keys` column against the kernel query's alias `s`
  // (builder_sessions). Raw keys only — the catalog-drop stays in the resolver.
  if (!api.hasProvider('session-grants-sql')) {
    api.registerProvider('session-grants-sql', {
      selectFragment: `,
            (SELECT COALESCE(array_agg(DISTINCT rp.permission_key), '{}')
               FROM governance_builder_roles br
               JOIN governance_role_permissions rp ON rp.role_key = br.role_key
              WHERE br.builder_id = s.builder_id) AS raw_permission_keys`,
    });
  }
}

// ── the R110 CRUD surface (ADR 0151 §2 — the governance tab's server half) ────
//
// Every route — the three reads included — gates on the `governance.manage`
// atom (system, floor archon): this surface EDITS the role/permission graph
// itself, the meta-escalation the catalog flags non-grantable, and even listing
// it exposes the full authority map. Two invariants are enforced HERE, against
// the catalog, not in the db layer (governance_001's app-side-validation split):
//   • a `system:true` permission is NON-GRANTABLE to a custom role (R94's wall —
//     "The governance API (R110) rejects granting it");
//   • the four seeded rank-roles are IMMUTABLE through this API: their grants
//     derive from catalog floors (a change is a migration — R94) and their
//     assignment derives from builders.rank via the R95b sync. A second writer
//     for either would fork authority truth.
const { validateOrRespond, LIMITS, parseId } = api;
const ROLE_KEY_RE = /^[a-z][a-z0-9-]*$/;
const ROLE_KEY_MAX = 64;

module.exports = function buildGovernanceRouter() {
  registerSeams();
  const router = express.Router();

  // Param guard for :roleKey. Responds bad_role_key and returns null on a
  // malformed slug (seeded keys like 'metic' pass shape and are refused later,
  // by policy, with the honest code).
  function roleKeyParam(req, res) {
    const roleKey = req.params.roleKey;
    if (roleKey.length > ROLE_KEY_MAX || !ROLE_KEY_RE.test(roleKey)) {
      res.fail('bad_role_key', 400, { role_key: roleKey, expected: 'a kebab-case slug (^[a-z][a-z0-9-]*$)' });
      return null;
    }
    return roleKey;
  }

  // Load a role that this API may MUTATE: 404 on a missing role, refuse a seeded
  // rank-role with the caller's `immutableCode`. Returns null after responding.
  async function loadMutableRole(res, roleKey, immutableCode, reason) {
    const role = await db.getRoleByKey(roleKey);
    if (!role) {
      res.fail('role_not_found', 404, { role_key: roleKey });
      return null;
    }
    if (role.is_system) {
      res.fail(immutableCode, 403, { role_key: roleKey, reason });
      return null;
    }
    return role;
  }
  const GRANTS_REASON = 'a seeded rank-role\'s grants derive from catalog floors; changing one is a migration (R94), never an API write';
  const ASSIGN_REASON = 'a seeded rank-role is assigned by rank (R95b sync); change the builder\'s rank instead';

  // rank: perm governance.manage — the full role list with each role's grants.
  router.get('/governance/roles', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    try {
      const roles = await db.listRolesWithGrants();
      res.json({ roles });
    } catch (err) {
      console.error('[gds] GET /governance/roles', err);
      res.fail('roles_list_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: perm governance.manage — the permission catalog + principals, straight
  // from code (the catalog is CODE, not a table); no DB read. `grantable` is the
  // flag the tab renders LOCKED from; principals are read-only by construction.
  router.get('/governance/permissions', api.requireBuilder, api.requirePermission('governance.manage'), (req, res) => {
    const permissions = catalog.PERMISSIONS.map((p) => ({
      key: p.key,
      system: p.system,
      floor: p.floor,
      guards: p.guards,
      scope: p.scope,
      resource: p.resource,
      grantable: catalog.isGrantable(p.key),
    }));
    res.json({ permissions, principals: catalog.principals() });
  });

  // rank: perm governance.manage — every builder↔role assignment row.
  router.get('/governance/assignments', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    try {
      const assignments = await db.listAssignments();
      res.json({ assignments });
    } catch (err) {
      console.error('[gds] GET /governance/assignments', err);
      res.fail('assignments_list_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: perm governance.manage — create a CUSTOM role (is_system false, no
  // seeded_rank — the seeded four exist only via governance_002). Grants are
  // added one at a time via the toggle below, so creation carries none.
  router.post('/governance/roles', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    if (validateOrRespond(req, res, {
      role_key: { required: true, type: 'string', minLength: 2, maxLength: ROLE_KEY_MAX },
      label: { required: true, type: 'string', minLength: 1, maxLength: LIMITS.TITLE },
      description: { type: 'string', maxLength: 2000 },
    })) return;
    const roleKey = req.body.role_key;
    if (!ROLE_KEY_RE.test(roleKey)) {
      return res.fail('bad_role_key', 400, { role_key: roleKey, expected: 'a kebab-case slug (^[a-z][a-z0-9-]*$)' });
    }
    try {
      const role = await db.createRole({
        roleKey,
        label: req.body.label,
        description: req.body.description ?? null,
        createdBy: req.builder.id,
      });
      res.status(201).json({ role: { ...role, permissions: [] } });
    } catch (err) {
      if (err && err.code === '23505') {
        return res.fail('role_exists', 409, { role_key: roleKey });
      }
      console.error('[gds] POST /governance/roles', err);
      res.fail('role_create_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: perm governance.manage — grant one OPERATIONAL permission to a custom
  // role (the toggle's ON half). The order of refusals is the authority order:
  // role exists → role is custom → the key exists → the key is grantable.
  router.put('/governance/roles/:roleKey/permissions/:permissionKey', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    const roleKey = roleKeyParam(req, res);
    if (roleKey === null) return;
    const permissionKey = req.params.permissionKey;
    try {
      const role = await loadMutableRole(res, roleKey, 'seeded_role_immutable', GRANTS_REASON);
      if (role === null) return;
      if (!catalog.byKey(permissionKey)) {
        return res.fail('unknown_permission', 400, { permission_key: permissionKey });
      }
      if (!catalog.isGrantable(permissionKey)) {
        return res.fail('permission_not_grantable', 400, {
          permission_key: permissionKey,
          reason: 'system (trust-boundary) permissions are non-grantable to a custom role (ADR 0151)',
        });
      }
      const granted = await db.grantRolePermission({ roleKey, permissionKey });
      res.json({ ok: true, role_key: roleKey, permission_key: permissionKey, granted });
    } catch (err) {
      console.error('[gds] PUT /governance/roles/:roleKey/permissions/:permissionKey', err);
      res.fail('grant_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: perm governance.manage — revoke a grant (the toggle's OFF half).
  // Deliberately NOT validated against the catalog: a grant whose key the
  // catalog since retired is exactly the row an Archon most needs to remove
  // (the resolver already drops it — this is hygiene, not authority).
  router.delete('/governance/roles/:roleKey/permissions/:permissionKey', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    const roleKey = roleKeyParam(req, res);
    if (roleKey === null) return;
    const permissionKey = req.params.permissionKey;
    try {
      const role = await loadMutableRole(res, roleKey, 'seeded_role_immutable', GRANTS_REASON);
      if (role === null) return;
      const removed = await db.revokeRolePermission({ roleKey, permissionKey });
      res.json({ ok: true, role_key: roleKey, permission_key: permissionKey, removed });
    } catch (err) {
      console.error('[gds] DELETE /governance/roles/:roleKey/permissions/:permissionKey', err);
      res.fail('revoke_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: perm governance.manage — assign a CUSTOM role to a builder.
  // assigned_by is ALWAYS the session builder, never input (the audit trail's
  // "who did this" must be the authenticated actor).
  router.post('/governance/assignments', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    if (validateOrRespond(req, res, {
      builder_id: { required: true, type: 'integer', min: 1 },
      role_key: { required: true, type: 'string', minLength: 2, maxLength: ROLE_KEY_MAX },
    })) return;
    const roleKey = req.body.role_key;
    if (!ROLE_KEY_RE.test(roleKey)) {
      return res.fail('bad_role_key', 400, { role_key: roleKey, expected: 'a kebab-case slug (^[a-z][a-z0-9-]*$)' });
    }
    try {
      const role = await loadMutableRole(res, roleKey, 'seeded_role_assignment_forbidden', ASSIGN_REASON);
      if (role === null) return;
      const assigned = await db.assignRole({
        builderId: req.body.builder_id,
        roleKey,
        assignedBy: req.builder.id,
      });
      res.status(assigned ? 201 : 200).json({ ok: true, builder_id: req.body.builder_id, role_key: roleKey, assigned });
    } catch (err) {
      if (err && err.code === '23503') {
        return res.fail('builder_not_found', 404, { builder_id: req.body.builder_id });
      }
      console.error('[gds] POST /governance/assignments', err);
      res.fail('assign_failed', { status: 500, message: 'internal error' });
    }
  });

  // rank: perm governance.manage — remove a custom-role assignment. Idempotent:
  // `removed` says whether a row went away.
  router.delete('/governance/assignments/:builderId/:roleKey', api.requireBuilder, api.requirePermission('governance.manage'), async (req, res) => {
    const builderId = parseId(req, res, { param: 'builderId', code: 'bad_builder_id', positiveInt: true });
    if (builderId === null) return;
    const roleKey = roleKeyParam(req, res);
    if (roleKey === null) return;
    try {
      const role = await loadMutableRole(res, roleKey, 'seeded_role_assignment_forbidden', ASSIGN_REASON);
      if (role === null) return;
      const removed = await db.unassignRole({ builderId, roleKey });
      res.json({ ok: true, builder_id: builderId, role_key: roleKey, removed });
    } catch (err) {
      console.error('[gds] DELETE /governance/assignments/:builderId/:roleKey', err);
      res.fail('unassign_failed', { status: 500, message: 'internal error' });
    }
  });

  return router;
};

module.exports.governancePort = governancePort;
