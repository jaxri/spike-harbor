'use strict';

// modules/governance/config.js — the governance config contract (ADR 0151, BV1.R96).
//
// Role TEMPLATES and their display labels are per-instance CONFIG; live grants and
// assignments are DB rows. This file resolves the config half, mirroring
// src/branding.js precedence exactly:
//
//   env override  ->  instance config (config/governance.json)  ->  neutral
//   starter (config/governance.neutral.json)
//
// A fresh instance with NO config resolves to the PLAIN neutral role set — never to
// a host's labels (fail-to-vanilla, the same posture branding takes). R102 proves
// that boot.
//
// WHAT LIVES HERE vs WHAT LIVES IN THE DB — get this wrong and config becomes a
// second source of authority truth, which is exactly what ADR 0016 forbids:
//   • config — TEMPLATES/DEFAULTS: a role's display label, its description, and the
//     permission list a starting CUSTOM role template proposes. Shapes only.
//   • DB     — LIVE STATE: governance_roles / governance_role_permissions /
//     governance_builder_roles (R93). WHO HOLDS WHAT is a row, resolved server-side
//     per request by resolver.js. Nothing in this file grants anything to anybody.
//
// Three fail-closed rules, in the same spirit as resolver.js's drop-unknown-key rule:
//   1. A template naming a `system: true` catalog key is STRIPPED. An instance's
//      config file is editable by anyone who can write the checkout, so it must never
//      be able to hand out deploy / rank-set / protected-path power. catalog
//      .isGrantable() is that wall — the same one the governance API and the Archon
//      tab use, so this cannot drift from the catalog.
//   2. A template naming a key the catalog does not define is DROPPED (the catalog is
//      the source of truth for what a permission IS — resolver.js, same rule).
//   3. A `permissions` list on one of the four SEEDED rank-roles is DROPPED wholesale.
//      Their grants are DERIVED from catalog floors and materialised by
//      governance_002; config may relabel a seeded role, never re-grant it.
//
// Stripping rather than throwing matches resolver.js: a typo in a config file must
// fail CLOSED, not brick the boot.
//
// SLICE BOUNDARY: this file is the config CONTRACT, and deliberately has no production
// caller yet — R96 is the "what shape is a role template, and what can config never
// do" decision, landed before the surfaces that read it. R110/R111 (the Archon
// governance tab) is the first intended consumer, and R102 (the vanilla-boot proof)
// asserts against the neutral starter. Wiring a speculative caller now would guess at
// their needs; the tests pin the contract until they land.

const fs = require('node:fs');
const path = require('node:path');
const api = require('../../src/module-api');
const catalog = require('./catalog');

// Both the neutral starter and the instance pack sit at the repo root's config/
// today (src/instance-config.js resolveCoreRoot() === resolveInstanceRoot() === this
// checkout), so this is the established module idiom for a repo-root read
// (modules/lifecycle, modules/onboarding, modules/discord). When ADR 0108's root
// split lands, the INSTANCE path routes through resolveInstanceRoot() — the module
// doorway does not re-export the root resolvers yet.
const ROOT = path.resolve(__dirname, '..', '..');
const NEUTRAL_PATH = path.join(ROOT, 'config', 'governance.neutral.json');
const INSTANCE_PATH = path.join(ROOT, 'config', 'governance.json');

const SEEDED_RANK_ROLES = new Set(catalog.RANK_ORDER);

const isObj = (v) => v && typeof v === 'object' && !Array.isArray(v);

// Instance roles merge over neutral PER ROLE KEY and per field, so an instance can
// relabel `metic` without restating the other three. The shape is exactly two levels
// deep, so this is a targeted merge rather than branding's generic deepMerge.
function mergeRoles(neutral, instance) {
  const out = {};
  const keys = new Set([...Object.keys(neutral || {}), ...Object.keys(instance || {})]);
  for (const key of keys) {
    const n = isObj((neutral || {})[key]) ? neutral[key] : {};
    const i = isObj((instance || {})[key]) ? instance[key] : {};
    out[key] = { ...n, ...i };
  }
  return out;
}

// The env layer overrides LABELS ONLY, deliberately: an env var must never be able to
// widen authority, so there is no env knob that adds a permission. It exists for the
// co-tenant case branding's AUTH_IDP override exists for — several hosted instances
// sharing the neutral pack, differentiated only by env, with no config file of their
// own. Format: "<PREFIX>_GOVERNANCE_ROLE_LABELS=metic=Trusted,archon=Owner". It can
// only RELABEL a role the merged config already defines — a typo names no role and is
// inert, rather than quietly growing the role set from an env string.
function applyLabelOverrides(roles, env) {
  const raw = api.resolveEnv('GOVERNANCE_ROLE_LABELS', { env });
  if (!raw) return roles;
  const out = { ...roles };
  for (const pair of String(raw).split(',')) {
    const eq = pair.indexOf('=');
    if (eq <= 0) continue;
    const key = pair.slice(0, eq).trim();
    const label = pair.slice(eq + 1).trim();
    if (!label || !isObj(out[key])) continue;
    out[key] = { ...out[key], label };
  }
  return out;
}

// Filter a template's proposed permissions against the code catalog. isGrantable() is
// false for BOTH an unknown key and a `system: true` key, so rules 1 and 2 above are
// one call — and they can never drift from the catalog. Returns a frozen sorted array.
function grantableOnly(keys) {
  const seen = new Set();
  for (const k of Array.isArray(keys) ? keys : []) {
    if (typeof k === 'string' && catalog.isGrantable(k)) seen.add(k);
  }
  return Object.freeze([...seen].sort());
}

function sanitizeRole(key, raw) {
  const seeded = SEEDED_RANK_ROLES.has(key);
  return Object.freeze({
    key,
    seeded,
    label: typeof raw.label === 'string' && raw.label ? raw.label : key,
    description: typeof raw.description === 'string' ? raw.description : '',
    // Rule 3: a seeded rank-role's grants come from catalog floors via governance_002.
    permissions: seeded ? Object.freeze([]) : grantableOnly(raw.permissions),
  });
}

// Pure resolver — all inputs injected, so tests drive it with zero I/O (the
// resolveBranding pattern).
function resolveGovernanceConfig({ neutral, instance, env = process.env } = {}) {
  const merged = applyLabelOverrides(mergeRoles((neutral || {}).roles, (instance || {}).roles), env);
  const roles = {};
  for (const key of Object.keys(merged).sort()) {
    if (!isObj(merged[key])) continue; // a malformed entry is not a role, and grants nothing
    roles[key] = sanitizeRole(key, merged[key]);
  }
  // The four rank-roles ALWAYS exist (governance_002 seeds them unconditionally), so a
  // config that omits or mangles one falls back to the canonical rank name rather than
  // dropping the role out of the display set.
  for (const key of catalog.RANK_ORDER) {
    if (!roles[key]) roles[key] = sanitizeRole(key, {});
  }
  return Object.freeze({ roles: Object.freeze(roles) });
}

// READ, never require(): a bare require('../../config/X.json') of a boundary-excluded
// config crashes a vanilla boot with MODULE_NOT_FOUND (fitness Check 16 / task 1824).
function readJson(p) {
  try { return JSON.parse(fs.readFileSync(p, 'utf8')); }
  catch (e) { if (e.code === 'ENOENT') return null; throw e; }
}

// Disk loader with the documented precedence. BOTH files are optional: the instance
// pack because a vanilla instance ships only the neutral starter, and the neutral
// starter because the four rank-roles still resolve to their canonical names without
// it. Unlike branding — where a missing identity is fatal — no value here is required,
// so the loader fails to sane defaults rather than throwing.
//
// CALL THIS AT BOOT, NOT PER REQUEST. The two reads are synchronous, which is correct
// for a startup read of a committed file and wrong inside a request handler. If a
// consumer needs it on a hot path, resolve once at boot and pass the frozen result —
// do NOT add a cache here (this file sits next to resolver.js, whose no-cache rule is
// absolute; keeping config cache-free too means nobody has to check which is which).
function loadGovernanceConfig({ neutralPath = NEUTRAL_PATH, instancePath = INSTANCE_PATH, env = process.env } = {}) {
  return resolveGovernanceConfig({
    neutral: readJson(neutralPath) || {},
    instance: readJson(instancePath) || {},
    env,
  });
}

module.exports = {
  resolveGovernanceConfig,
  loadGovernanceConfig,
  grantableOnly,
  NEUTRAL_PATH,
  INSTANCE_PATH,
};
