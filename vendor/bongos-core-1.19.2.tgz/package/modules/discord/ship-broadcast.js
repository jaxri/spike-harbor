// Shared ship-broadcast routing + the server-side broadcast poster.
//
// chooseBroadcastTargets is the PURE channel-routing decision (task 990): given a
// shipped task's security flag, which Discord channels + lines the broadcast goes
// to. It lived in scripts/gds/ship.js; task 1045 extracted it here so BOTH the
// laptop-local ship.js path AND the server-mediated publish path (ADR 0055) route
// by the EXACT same rule — a security fix must never leak to a public channel from
// either path. ship.js re-exports it so its existing regression test is unchanged.
//
// postShipBroadcast is the SERVER-SIDE poster (task 1045). On the server-mediated
// publish path a dev box cannot post the broadcast — it holds no webhook secret
// (ADR 0053 "box holds nothing"), which is exactly why a box ship was silently
// skipping the public announcement. So when the GDS server confirms the deploy
// landed (publish-status reconcile, confirmed→shipped), the server — which holds
// the webhook secrets and just deployed — fires the broadcast instead. Best-effort:
// it never throws, so a Discord hiccup can never undo a ship.

// PURE. Returns the array of { channel, line } the caller posts, in order:
//   - no summary              → [] (the long-standing "no summary, no broadcast").
//   - securitySensitive=true  → ONLY the Archon-only #security-ship-feed. This
//     branch can NEVER return ship_news or ship_feed — a security fix must not
//     advertise the shape of an exploit on a public/builder channel before it is
//     live (the owner requirement behind task 990).
//   - otherwise               → the builder #ship-feed only.
// #ship-feed / #security-ship-feed lines are PREFIXED with `#<taskId>` so the
// upvote bot can map a 👍 back to the task (discord-reaction.parseShipMarker).
//
// #ship-news is PAUSED (task 1749, owner ask 2026-07-03): per-ship broadcast was
// too spammy (it posted to #ship-news AND #ship-feed, ×2 posters = 4 messages).
// For now #ship-news gets nothing so exactly one #ship-feed message fires per
// ship. The broader "make the two channels genuinely different + filter by task
// type" work is idea 458 — un-pause by restoring the ship_news entry below.
function chooseBroadcastTargets({ securitySensitive, taskId, summary }) {
  if (!summary) return [];
  if (securitySensitive) {
    return [{ channel: 'security_ship_feed', line: `#${taskId} shipped (security) — ${summary}` }];
  }
  return [
    // { channel: 'ship_news', line: summary },  // PAUSED — task 1749 / idea 458
    { channel: 'ship_feed', line: `#${taskId} shipped — ${summary}` },
  ];
}

// Best-effort server-side broadcast for a task that just landed via server-
// mediated publish. `task` is the shipTask() row: { id, value_summary,
// security_sensitive, ... }. deps.postWebhook (the scripts/discord/lib poster) and
// deps.log are injectable for tests.
//
// FAIL CLOSED on the security flag, exactly like ship.js's local block: if the
// flag is not a definite boolean we SUPPRESS the broadcast entirely rather than
// risk advertising an unpatched exploit on a public channel. Returns
// { posted: [channels], skipped: reason|null } so the behavior is unit-testable;
// never throws (a single channel's failure is logged and swallowed).
async function postShipBroadcast(task, deps = {}) {
  const result = { posted: [], skipped: null };
  if (!task || task.id == null) { result.skipped = 'no_task'; return result; }
  const summary = task.value_summary;
  if (!summary) { result.skipped = 'no_summary'; return result; }
  const sec = task.security_sensitive;
  if (sec !== true && sec !== false) { result.skipped = 'security_flag_indeterminate'; return result; }

  const postWebhook = deps.postWebhook || require('./webhook').postWebhook;
  const log = deps.log || console.log;
  const targets = chooseBroadcastTargets({ securitySensitive: sec, taskId: task.id, summary });
  for (const { channel, line } of targets) {
    try {
      await postWebhook(channel, line);
      result.posted.push(channel);
    } catch (e) {
      // A channel's failure (e.g. no webhook configured on this host) must never
      // throw into the ship/reconcile path — log + continue (#94 / ADR 0032).
      log(`[gds] ship broadcast: #${channel.replace(/_/g, '-')} post failed (non-blocking): ${e && e.message ? e.message : e}`);
    }
  }
  return result;
}

// task 1002606 (finding P-3) — the strand notice. Until now Discord fired only on
// task.shipped, so a STRAND (needs_rebase flagged by the publish-reconciler) had no
// push channel — the builder discovered it at their next /builder-start, up to a
// whole session later. The reconciler now emits `task.strand-flagged` the moment a
// strand is detected; this poster carries it to the builder channel.
//
// PURE routing, same discipline as chooseBroadcastTargets: a security-sensitive
// task's strand notice goes ONLY to the Archon-only #security-ship-feed (the reason
// string can name conflicted files of an unpatched fix). The line deliberately does
// NOT start with `#<taskId>` — a LEADING task marker is what the applause bot maps
// 👍 reactions onto (discord-reaction.parseShipMarker), and a strand is not
// applaudable shipped work.
function chooseStrandTargets({ securitySensitive, taskId, reason }) {
  if (taskId == null) return [];
  const line = `⚠️ task ${taskId} stranded at 'confirmed' (${reason || 'unknown'}) — its builder must fix + re-land it, or release it.`;
  if (securitySensitive) {
    return [{ channel: 'security_ship_feed', line }];
  }
  return [{ channel: 'ship_feed', line }];
}

// Best-effort server-side strand poster — fired by the `task.strand-flagged` seam
// listener. `info` is the reconciler's event payload: { id, builder_id, title,
// security_sensitive, reason }. FAIL CLOSED on the security flag exactly like
// postShipBroadcast: if it is not a definite boolean the notice is suppressed
// entirely rather than risk naming an unpatched fix on a builder channel. Never
// throws — a channel failure is logged and swallowed.
async function postStrandNotice(info, deps = {}) {
  const result = { posted: [], skipped: null };
  if (!info || info.id == null) { result.skipped = 'no_task'; return result; }
  const sec = info.security_sensitive;
  if (sec !== true && sec !== false) { result.skipped = 'security_flag_indeterminate'; return result; }

  const postWebhook = deps.postWebhook || require('./webhook').postWebhook;
  const log = deps.log || console.log;
  const targets = chooseStrandTargets({ securitySensitive: sec, taskId: info.id, reason: info.reason });
  for (const { channel, line } of targets) {
    try {
      await postWebhook(channel, line);
      result.posted.push(channel);
    } catch (e) {
      log(`[gds] strand notice: #${channel.replace(/_/g, '-')} post failed (non-blocking): ${e && e.message ? e.message : e}`);
    }
  }
  return result;
}

module.exports = { chooseBroadcastTargets, postShipBroadcast, chooseStrandTargets, postStrandNotice };
