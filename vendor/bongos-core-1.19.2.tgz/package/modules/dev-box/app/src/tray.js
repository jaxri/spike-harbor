// devbox-app/src/tray.js — the menu-bar (mac) / system-tray (Windows) face.
//
// macOS gets monochrome TEMPLATE images (the OS recolors them for light/dark
// menu bars; the shape carries the state). Windows gets colored PNGs. Four
// states: off (outline), on (filled), busy (half), alert (bang).

const path = require('node:path');
const { Tray, Menu, nativeImage } = require('electron');

const ASSETS = path.join(__dirname, '..', 'assets', 'tray');
const IS_MAC = process.platform === 'darwin';

// status (box-controller vocabulary) → icon variant
function iconVariant(status) {
  switch (status) {
    case 'active': return 'on';
    case 'provisioning':
    case 'closing': return 'busy';
    case 'error': return 'alert';
    default: return 'off'; // none / signed_out / loading
  }
}

function loadIcon(variant) {
  const file = IS_MAC ? `mac-${variant}Template.png` : `win-${variant}.png`;
  const img = nativeImage.createFromPath(path.join(ASSETS, file));
  if (IS_MAC) img.setTemplateImage(true);
  return img;
}

function statusLine(snapshot) {
  switch (snapshot.status) {
    case 'signed_out': return 'Not signed in';
    case 'loading': return 'Checking…';
    case 'none': return 'Box: off';
    case 'provisioning': return 'Box: starting up…';
    case 'active': return `Box: ON${snapshot.box && snapshot.box.hostname ? ` — ${snapshot.box.hostname}` : ''}`;
    case 'closing': return 'Box: shutting down…';
    case 'error': return 'Box: error — open the panel';
    default: return 'Dev Box';
  }
}

// createTray({ onOpen, onToggle, onOpenTerminal, onOpenHall, onQuit,
//              getLoginItem, setLoginItem }) → { update(snapshot), destroy() }
function createTray(handlers) {
  const tray = new Tray(loadIcon('off'));
  let current = { status: 'loading' };

  function buildMenu() {
    const s = current;
    const onOrOff = s.status === 'active' || s.status === 'closing';
    return Menu.buildFromTemplate([
      { label: statusLine(s), enabled: false },
      { type: 'separator' },
      { label: 'Open Dev Box panel', click: handlers.onOpen },
      {
        label: onOrOff ? 'Turn box off' : 'Turn box on',
        enabled: s.status !== 'signed_out' && s.status !== 'loading' && !s.busy
          && s.status !== 'provisioning' && s.status !== 'closing',
        click: handlers.onToggle,
      },
      {
        label: 'Open browser terminal',
        enabled: Boolean(s.terminal && s.terminal.url),
        click: handlers.onOpenTerminal,
      },
      { label: 'Open the builders’ hall', click: handlers.onOpenHall },
      { type: 'separator' },
      {
        label: 'Start at login',
        type: 'checkbox',
        checked: handlers.getLoginItem(),
        click: (item) => handlers.setLoginItem(item.checked),
      },
      { type: 'separator' },
      { label: 'Quit', click: handlers.onQuit },
    ]);
  }

  // Left-click opens the panel; right-click (and mac ctrl-click) the menu.
  tray.on('click', handlers.onOpen);
  tray.on('right-click', () => tray.popUpContextMenu(buildMenu()));

  return {
    update(snapshot) {
      current = snapshot;
      tray.setImage(loadIcon(iconVariant(snapshot.status)));
      tray.setToolTip(statusLine(snapshot));
      // Keep a context menu reachable on platforms that route both buttons to
      // 'click' — popUpContextMenu handles the rest.
      if (!IS_MAC) tray.setContextMenu(buildMenu());
    },
    bounds() { return tray.getBounds(); },
    destroy() { tray.destroy(); },
  };
}

module.exports = { createTray, iconVariant, statusLine };
