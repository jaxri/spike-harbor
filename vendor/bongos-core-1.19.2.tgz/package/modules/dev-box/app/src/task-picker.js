// devbox-app/src/task-picker.js — BV1.R100 (goal 1000051): the "What are you
// working on?" pick + confirm logic, kept PURE so test/unit.mjs can pin it
// without Electron (the same pattern as box-controller's decision helpers).
//
// The flow this backs: the panel lists the builder's claimable tasks, the builder
// picks one, the app claims it over the GDS API (server-mediated — no SSH), then
// reads the resulting box scope (GET /box/scope, credential-free) to CONFIRM, in
// plain words, exactly what code the box will now hold. The re-scope itself is
// R94 + R96 machinery (the claim re-points /box/source-access; /builder-sync on the
// box pulls it) — this module only shapes the list and writes the confirmation.

// shapeClaimableTasks — normalize the GET /tasks/claimable payload into the small
// row shape the panel renders. Caps the list (the panel is a menu-bar popover, not
// a full queue — "show all" lives in the hall). Tolerant of a missing/using body.
function shapeClaimableTasks(payload, { limit = 6 } = {}) {
  const rows = payload && Array.isArray(payload.claimable) ? payload.claimable : [];
  const capped = limit > 0 ? rows.slice(0, limit) : rows;
  return capped.map((t) => ({
    id: String(t.id),
    title: t.title || `Task ${t.id}`,
    kind: t.kind || 'task',
    estMinutes: Number.isFinite(t.est_minutes) ? t.est_minutes : null,
  }));
}

// boxScopeMessage — the confirmation shown after a successful pick+claim. `task`
// is { id }; `scope` is the GET /box/scope body ({ scope, modules, task_scope }) or
// null when that read failed (best-effort — the claim still succeeded). The three
// shapes mirror decideSourceAccess / scopeMetadata on the server:
//   - modules non-empty  → TASK scope: name exactly the modules the box will hold.
//   - modules === []      → BASE-only: the task needs nothing beyond the base box.
//   - modules === null    → rank fallback (no task→module mapping): generic refresh.
//   - scope === null      → the scope read failed: claim landed, still direct to sync.
const SYNC_HINT = 'On the box, run /builder-sync to pull it now — or it auto-syncs within ~10 minutes.';

function boxScopeMessage({ task, scope } = {}) {
  const n = task && task.id ? `task ${task.id}` : 'your task';
  if (!scope) {
    return `Claimed ${n}. Your box will re-scope to it. ${SYNC_HINT}`;
  }
  const mods = Array.isArray(scope.modules) ? scope.modules : null;
  if (mods && mods.length) {
    return `Claimed ${n}. Your box is now scoped to: ${mods.join(', ')} — and nothing else. ${SYNC_HINT}`;
  }
  if (mods && mods.length === 0) {
    return `Claimed ${n}. It needs only the base instance already on your box — nothing extra to pull.`;
  }
  // modules === null → the rank fallback (no lifecycle port / no per-module scope).
  return `Claimed ${n}. Your box keeps its ${scope.scope || 'rank'} scope. ${SYNC_HINT}`;
}

// claimErrorMessage — map a GdsError from POST /claims to plain, actionable copy.
// The common refusals (deps, one-claim-per-session, not-ready, touches conflict)
// each get a specific line; anything else falls back to the server message/code.
function claimErrorMessage(err) {
  const body = (err && err.body) || {};
  const code = body.error || body.code || (err && err.message) || 'claim_failed';
  const known = {
    DEPS_NOT_SHIPPED: 'That task is waiting on other work to ship first. Pick another one.',
    session_already_has_active_claim: 'You already have a task in flight — ship or release it first.',
    task_not_ready: 'That task isn’t ready to claim yet. Pick another.',
    not_ready: 'That task isn’t ready to claim yet. Pick another.',
    touches_conflict: 'Another builder is touching the same files right now. Pick a different task.',
    already_claimed: 'Someone just claimed that one. Refresh and pick another.',
    newcomer_claim_forbidden: 'That task is above your current rank. Pick a newcomer-friendly one.',
  };
  return known[code] || body.message || `Couldn’t claim it (${code}).`;
}

module.exports = { shapeClaimableTasks, boxScopeMessage, claimErrorMessage, SYNC_HINT };
