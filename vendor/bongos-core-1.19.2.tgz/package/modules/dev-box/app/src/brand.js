// modules/dev-box/app/src/brand.js — the app's brand strings, in ONE place.
//
// GENERATED, not hardcoded: scripts/gen-brand.js writes src/brand.generated.json
// from the instance's config/branding.json at build time (prestart / pretest /
// predist), so the SAME source tree renders a "Cloud Bongos Dev Box" here and an
// "Amazonprimea Dev Box" on the OTB instance — no instance name is baked into
// code (the ADR 0004 posture, generalised to every instance). The generated file
// is committed (the Cloud Bongos default) so a fresh checkout runs without a
// generate step; every build regenerates it from the local branding.
//
// Keys: CIV_NAME (world/instance name, runtime display only), PRODUCT_NAME,
// DESKTOP_ENV_NAME, PUBLIC_ORIGIN, BUILDERS_ORIGIN, PRODUCT_SLUG (artifact
// filenames), APP_ID, COPYRIGHT, CONFIG_DIR (matches the CLI session dir),
// BG_COLOR (pre-CSS window bg), TAGLINE (panel epigraph).

module.exports = require('./brand.generated.json');
