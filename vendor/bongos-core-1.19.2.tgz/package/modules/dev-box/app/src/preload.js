// devbox-app/src/preload.js — the renderer's ONLY door into the main process.
// Sandboxed + contextIsolated; every capability is a named verb (no raw URLs,
// no arbitrary IPC) so a compromised renderer can do nothing the panel UI
// couldn't already do.

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('otb', {
  getState: () => ipcRenderer.invoke('state:get'),
  signIn: () => ipcRenderer.invoke('auth:signIn'),
  cancelPairing: () => ipcRenderer.invoke('auth:cancelPairing'),
  signOut: () => ipcRenderer.invoke('auth:signOut'),
  boxOn: () => ipcRenderer.invoke('box:on'),
  boxOff: () => ipcRenderer.invoke('box:off'),
  claimable: () => ipcRenderer.invoke('tasks:claimable'),
  pickTask: (taskId) => ipcRenderer.invoke('tasks:pick', taskId),
  openTerminal: () => ipcRenderer.invoke('open:terminal'),
  openHall: () => ipcRenderer.invoke('open:hall'),
  openPairPage: () => ipcRenderer.invoke('open:pairPage'),
  openUpdate: () => ipcRenderer.invoke('open:update'),
  copy: (what) => ipcRenderer.invoke('copy', what),
  installSettings: () => ipcRenderer.invoke('settings:install'),
  retryHostKeys: () => ipcRenderer.invoke('hostkeys:retry'),
  retryKey: () => ipcRenderer.invoke('key:retry'),
  hide: () => ipcRenderer.invoke('panel:hide'),
  onState: (cb) => {
    ipcRenderer.on('state', (_e, payload) => cb(payload));
  },
});
