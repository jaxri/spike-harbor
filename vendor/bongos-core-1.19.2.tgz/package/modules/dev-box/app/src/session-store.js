// devbox-app/src/session-store.js — the app shares the GDS CLI's session file.
//
// ~/.config/<instance>/gds-session.json is the same file scripts/gds/cli-lib.js and
// paste-token.js read/write: { token, builder, api_base, ... }. Sharing it is
// a deliberate UX decision (ADR 0045): pairing the app also signs in every
// /builder-* skill on this machine, and a builder who already ran
// /builder-setup opens the app already signed in. Writes are merge-preserving
// (unknown fields like gemini_api_key survive, mirroring paste-token.js) and
// 0600 like the CLI's.

const fs = require('node:fs');
const path = require('node:path');
const os = require('node:os');
const brand = require('./brand');

// The instance's CLI config dir (branding configDir) — so the app shares the
// exact session file the /builder-* CLI uses on this machine.
const DIR = path.join(os.homedir(), '.config', brand.CONFIG_DIR);
const FILE = path.join(DIR, 'gds-session.json');
// Read-side legacy name only (pre-GDS rename) — never written.
const FILE_LEGACY = path.join(DIR, 'pms-session.json');

function read() {
  for (const f of [FILE, FILE_LEGACY]) {
    try {
      const data = JSON.parse(fs.readFileSync(f, 'utf8'));
      if (data && typeof data.token === 'string' && data.token) return data;
    } catch { /* missing or unparsable → keep looking */ }
  }
  return null;
}

function write({ token, builder, apiBase }) {
  const existing = read() || {};
  const next = {
    ...existing,
    token,
    builder: builder ?? existing.builder ?? null,
    api_base: apiBase ?? existing.api_base ?? null,
  };
  fs.mkdirSync(DIR, { recursive: true });
  fs.writeFileSync(FILE, `${JSON.stringify(next, null, 2)}\n`, { mode: 0o600 });
  // Re-assert the mode for pre-existing files (chmod is a no-op on Windows,
  // where the home-dir ACL is the protection — same posture as the CLI).
  try { fs.chmodSync(FILE, 0o600); } catch { /* best-effort */ }
  return next;
}

// Sign-out: drop ONLY our credential fields; preserve everything else
// (gemini_api_key etc.) so the app never destroys CLI-adjacent config.
function clear() {
  const existing = read();
  if (!existing) return;
  const { token: _t, builder: _b, ...rest } = existing;
  fs.writeFileSync(FILE, `${JSON.stringify(rest, null, 2)}\n`, { mode: 0o600 });
}

module.exports = { read, write, clear, FILE };
