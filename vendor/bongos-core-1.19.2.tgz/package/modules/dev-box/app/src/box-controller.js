// devbox-app/src/box-controller.js — the app's state machine.
//
// Owns: the polled view of GET /box/me (+ /box/terminal), the on/off actions,
// poll cadence, and transition events (for notifications + tray updates). The
// pure decision helpers are exported separately so test/unit.mjs can pin them
// without Electron.
//
// Status vocabulary the UI/tray consume (derived, NOT the raw box.state):
//   signed_out | loading | none | provisioning | active
//   | closing | error
//
// Cost posture (deliberate, with one narrow exception): the app NEVER sends
// claude_active heartbeats, so the droplet's idle sweep stays authoritative — a
// box nobody is using is reclaimed in ~10–15 min and the app just reflects that.
// The exception (leg 3): while the app is ACTIVELY pointed at the box (panel open,
// or within HEARTBEAT_WINDOW_MS of a connect action) it sends BODY-LESS heartbeats
// that bump last_activity_at only — never claude_active. That stops the box reaping
// out from under a builder who is mid-connect (the vicious cycle where a failing
// connect lets the box rebuild with fresh host keys) WITHOUT keeping a genuinely
// idle box (app closed, no recent connect) alive. See shouldHeartbeat().

// Derive the UI status from a GET /box/me payload.
function deriveStatus(payload) {
  if (!payload || !payload.box) return 'none';
  const state = payload.box.state || 'none';
  const intent = payload.open_intent || null;
  if (intent && intent.action === 'deprovision') return 'closing';
  if (intent && (intent.action === 'provision' || intent.action === 'wake')) return 'provisioning';
  if (state === 'active') return 'active';
  if (state === 'provisioning' || state === 'waking') return 'provisioning';
  if (state === 'parking') return 'closing';
  // parked = off-but-resumable; surfaced as plain "off" — the switch wakes it.
  if (state === 'parked' || state === 'none' || state === 'destroyed') return 'none';
  if (state === 'error') return 'error';
  return 'none';
}

// Poll cadence by status (ms). Transitions poll fast; settled states slow.
function pollDelayMs(status) {
  switch (status) {
    case 'provisioning':
    case 'closing': return 5_000;
    case 'active': return 60_000;
    case 'error': return 60_000;
    default: return 120_000; // none / signed_out idle tick
  }
}

// Leg 3 — connect-window keep-alive. The heartbeat timer ticks at this cadence,
// well under the box-side cron (5 min) and the idle threshold (10 min), so even a
// short connect window defers a reap.
const HEARTBEAT_TICK_MS = 120_000;     // 2 min
// Keep beating for this long after a deliberate connect action (box on / terminal
// open) so retries during a flaky connect stay covered even if the panel is hidden.
const HEARTBEAT_WINDOW_MS = 600_000;   // 10 min

// PURE (unit-tested): should the app send a keep-alive heartbeat right now? Only
// when the box is active AND the app is actively pointed at it — panel visible, or
// within HEARTBEAT_WINDOW_MS of a connect action. An idle box (app closed, no
// recent connect) returns false, so it still reaps on schedule (cost posture).
function shouldHeartbeat({ status, panelVisible, lastConnectActionAt, now }) {
  if (status !== 'active') return false;
  if (panelVisible) return true;
  return Boolean(lastConnectActionAt) && (now - lastConnectActionAt) < HEARTBEAT_WINDOW_MS;
}

// Map a status transition to a user-facing notification (or null).
// `ctx.envName` = the Claude Desktop environment name.
function transitionNotification(prev, next, ctx = {}) {
  if (prev === next) return null;
  if (next === 'active') {
    return {
      title: 'Your dev box is ready',
      body: ctx.settingsInstalled
        ? `Restart Claude Desktop, then Code → Environment → “${ctx.envName}”. The browser terminal works too.`
        : 'Connect from the app panel — browser terminal or SSH.',
    };
  }
  if (prev === 'active' && next === 'none') {
    return {
      title: 'Your dev box closed',
      body: 'It shut down (boxes rest after ~10 idle minutes, or when closed). Flip the switch to raise it again.',
    };
  }
  if (next === 'error') {
    return {
      title: 'Your dev box hit an error',
      body: 'Flip the switch to try again, or ask in #support on Discord.',
    };
  }
  return null;
}

// createBoxController({ client, signedIn, onChange, onNotify, sleep? })
// onChange(snapshot) fires on every refresh; onNotify({title, body}) on
// meaningful transitions. Snapshot shape is what ipc.js ships to the renderer.
function createBoxController({ client, signedIn, onChange, onNotify, envName }) {
  let status = 'loading';
  let box = null;
  let terminal = null;          // { url, credential } when active+ready
  let lastError = null;
  let settingsInstalled = false; // set by main.js after ssh-setup runs
  let hostKeys = null;           // { ok, reason?, attempt? } — #909 pinning status
  let keyRegistered = null;      // { ok, reason, fingerprint, attempts } — task 1002509
  let busy = false;              // an ensure/close request is in flight
  let timer = null;
  let stopped = false;
  let panelVisible = false;      // leg 3: main.js pushes BrowserWindow show/hide
  let lastConnectActionAt = 0;   // leg 3: stamped on box-on / terminal-open
  let hbTimer = null;            // leg 3: keep-alive timer (separate from the poll)

  function snapshot() {
    return {
      status: signedIn() ? status : 'signed_out',
      busy,
      box: box && {
        state: box.state,
        hostname: box.hostname,
        size: box.size_slug,
        provisionedAt: box.provisioned_at,
        // task 1187 / idea 235: the box's GDS-reported PUBLIC host keys
        // (`<keytype> <base64>` per line). main.js pins known_hosts from these
        // (authoritative — no keyscan/TOFU) when present, else falls back to keyscan.
        hostKeysText: box.host_keys || null,
        // When those keys were reported, and when the CURRENT droplet came up. A
        // report older than the activation belongs to a box that no longer exists,
        // so main.js keyscans instead of pinning a dead identity (task 1002509).
        hostKeysAt: box.host_keys_at || null,
        activeSince: box.active_since || null,
      },
      terminal,
      lastError,
      settingsInstalled,
      hostKeys,
      keyRegistered,
    };
  }

  function emit() { onChange(snapshot()); }

  function schedule(ms) {
    if (stopped) return;
    clearTimeout(timer);
    timer = setTimeout(() => refresh().catch(() => {}), ms ?? pollDelayMs(status));
    // Don't hold the process open for a poll timer.
    if (timer.unref) timer.unref();
  }

  // Leg 3: body-less keep-alive while the app is actively pointed at the box (see
  // the cost-posture note up top). Best-effort — a failed beat just retries next
  // tick; it never blocks or surfaces an error to the user.
  function heartbeatTick() {
    if (stopped || !signedIn()) return;
    if (!shouldHeartbeat({ status, panelVisible, lastConnectActionAt, now: Date.now() })) return;
    Promise.resolve(client.boxHeartbeat()).catch(() => {});
  }

  async function refresh() {
    if (stopped) return snapshot();
    if (!signedIn()) {
      status = 'signed_out';
      box = null; terminal = null;
      emit();
      return snapshot();
    }
    try {
      const payload = await client.boxMe();
      const prev = status;
      box = payload.box && payload.box.state !== 'none' ? payload.box : null;
      status = deriveStatus(payload);
      lastError = null;
      // Terminal link only matters when active; warming_up → keep polling.
      if (status === 'active') {
        try {
          const t = await client.boxTerminal();
          terminal = t && t.url ? { url: t.url, credential: t.credential } : null;
        } catch { terminal = null; }
      } else {
        terminal = null;
        hostKeys = null; // re-pinned on next activation (#909)
      }
      const note = transitionNotification(prev, status, { envName, settingsInstalled });
      if (note && prev !== 'loading') {
        onNotify(note);
      }
      if (note && status === 'active') {
        // 'ready' fires even from a cold start (prev === 'loading') if the
        // box JUST became active from this app's own ensure — handled by main.
      }
    } catch (err) {
      if (err && err.status === 401) {
        status = 'signed_out';
      } else {
        lastError = err.message || 'unreachable';
        if (status === 'loading') status = 'error';
      }
    }
    emit();
    schedule();
    return snapshot();
  }

  return {
    snapshot,
    refresh,
    setSettingsInstalled(v) { settingsInstalled = v; emit(); },
    setHostKeys(v) { hostKeys = v; emit(); },
    // Registration outcome from ssh-setup.registerKeyWithVerify. Unlike hostKeys it
    // is NOT cleared when the box goes inactive: the key lives on the builder's
    // account, so a failure stays visible (and retryable) until it verifies.
    setKeyRegistered(v) { keyRegistered = v; emit(); },
    // Leg 3: main.js pushes panel visibility; connect actions stamp a window.
    setPanelVisible(v) { panelVisible = !!v; },
    markConnectAttempt() { lastConnectActionAt = Date.now(); },

    // Flip ON: POST /box/ensure, then poll fast. Returns the server message.
    async turnOn() {
      lastConnectActionAt = Date.now(); // leg 3: turning the box on is a connect action
      busy = true; lastError = null; emit();
      try {
        return await client.boxEnsure();
      } catch (err) {
        lastError = err.body && err.body.error === 'BOX_PROVISION_DENIED'
          ? `Not allowed: ${err.body.reason || 'provision denied'}`
          : (err.message || 'request failed');
        throw err;
      } finally {
        busy = false;
        await refresh();
      }
    },

    // Flip OFF: POST /box/close (active only — the API 409s otherwise).
    async turnOff() {
      busy = true; lastError = null; emit();
      try {
        return await client.boxClose();
      } catch (err) {
        lastError = err.body && err.body.error === 'box_not_active'
          ? 'The box is mid-change — wait for it to settle, then try again.'
          : (err.message || 'request failed');
        throw err;
      } finally {
        busy = false;
        await refresh();
      }
    },

    start() {
      stopped = false;
      refresh().catch(() => {});
      // leg 3: a separate, unref'd keep-alive timer (gated by shouldHeartbeat).
      if (!hbTimer) { hbTimer = setInterval(heartbeatTick, HEARTBEAT_TICK_MS); if (hbTimer.unref) hbTimer.unref(); }
    },
    stop() {
      stopped = true;
      clearTimeout(timer);
      if (hbTimer) { clearInterval(hbTimer); hbTimer = null; }
    },
  };
}

// ttyd's HTTP-basic username is the fixed `otb` user (box-terminal.service:
// --credential "otb:<pass>"); the password is the long hex `credential`.
const TERMINAL_USER = 'otb';

// Browser-terminal URL with the basic-auth userinfo embedded, so opening it
// lands signed-in (browsers still honor user:pass@host for top-level
// navigation; ttyd auth is plain HTTP basic). Falls back to the bare URL if
// there's no credential or the URL doesn't parse.
function terminalAuthUrl(terminal) {
  if (!terminal || !terminal.url) return null;
  if (!terminal.credential) return terminal.url;
  try {
    const u = new URL(terminal.url);
    u.username = TERMINAL_USER;
    u.password = terminal.credential;
    return u.toString();
  } catch {
    return terminal.url;
  }
}

module.exports = {
  createBoxController, deriveStatus, pollDelayMs, transitionNotification,
  terminalAuthUrl, TERMINAL_USER, shouldHeartbeat,
};
