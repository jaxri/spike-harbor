// devbox-app/src/pairing.js — browser-clicks-only sign-in (#904, ADR 0045).
//
// start() asks the GDS for a pairing, opens the approve page in the default
// browser, and polls until the builder clicks Approve. The minted token comes
// back over the app's own secret poll channel — it never transits the browser.
// Counterpart server logic: src/bongos/app-pair.js + routes/auth.js.

const os = require('node:os');
const brand = require('./brand');

function platformKey() {
  if (process.platform === 'darwin') return 'mac';
  if (process.platform === 'win32') return 'windows';
  return 'linux';
}

function deviceName() {
  const host = os.hostname().replace(/\.(local|lan|home)$/i, '');
  return `${brand.PRODUCT_NAME} on ${host}`.slice(0, 80);
}

// createPairing({ client, openExternal, sleep }) — deps injected for tests.
// run(onUpdate) resolves { token, builder, expires_at } or throws
// Error('expired'|'cancelled').
function createPairing({ client, openExternal, sleep }) {
  const wait = sleep || ((ms) => new Promise((r) => setTimeout(r, ms)));
  let cancelled = false;

  return {
    cancel() { cancelled = true; },
    async run(onUpdate = () => {}) {
      cancelled = false;
      const start = await client.pairStart(deviceName(), platformKey());
      onUpdate({ phase: 'waiting', pairCode: start.pair_code, verifyUrl: start.verify_url });
      await openExternal(start.verify_url);
      const intervalMs = Math.max(2, start.interval || 5) * 1000;
      const deadline = Date.now() + (start.expires_in || 600) * 1000;
      while (!cancelled && Date.now() < deadline) {
        await wait(intervalMs);
        if (cancelled) break;
        let out;
        try {
          out = await client.pairPoll(start.poll_token);
        } catch {
          continue; // transient network blip — the deadline bounds us
        }
        if (out.status === 'approved') {
          return { token: out.token, builder: out.builder, expires_at: out.expires_at };
        }
        if (out.status === 'expired') throw new Error('expired');
      }
      throw new Error(cancelled ? 'cancelled' : 'expired');
    },
  };
}

module.exports = { createPairing, platformKey, deviceName };
