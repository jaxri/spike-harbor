// devbox-app/src/config.js — runtime configuration resolution.

const brand = require('./brand');

function apiBase(sessionApiBase) {
  // Priority: explicit env (dev/staging) → the base recorded in the session
  // file at sign-in → production default. Trailing slashes are stripped so
  // path concatenation stays uniform.
  const raw = process.env.OTB_DEVBOX_API_BASE || sessionApiBase || brand.PUBLIC_ORIGIN;
  return String(raw).replace(/\/+$/, '');
}

function appVersion() {
  // package.json is inside the asar in production; require() resolves it both
  // packed and in dev.
  return require('../package.json').version;
}

module.exports = { apiBase, appVersion };
