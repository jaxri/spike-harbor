// devbox-app/src/gds-client.js — authenticated client over the GDS API.
//
// Backed by the GENERATED typed client (task 1996 / R09), vendored in verbatim at
// src/vendor/bongos-client.cjs (scripts/vendor-client.js copies it from the repo's
// clients/bongos-client/ so it ships inside the asar — see ADR 0045: the app is a
// zero-dep, separately-packaged subproject). This module keeps the SAME method
// surface + GdsError contract its callers (box-controller, main) rely on, so the
// only thing that changed is the transport: the endpoint paths are now the
// spec-derived generated methods, which can never drift from the routes.
//
// Endpoints stay on the PERMANENT unversioned /api/gds alias (ADR 0117) so shipped
// binaries keep working; the generated methods are relative to that base.

const createGeneratedClient = require('./vendor/bongos-client.cjs');
const { apiBase } = require('./config');

class GdsError extends Error {
  constructor(status, body) {
    super((body && (body.message || body.error)) || `HTTP ${status}`);
    this.status = status;
    this.body = body || {};
  }
}

// createClient({ getToken, getApiBase, fetchImpl }) — getToken/getApiBase are read
// per call so a re-auth or a base change is picked up immediately (the generated
// client captures them at construction, so we construct per call — cheap closures).
// fetchImpl is a seam for tests; it defaults to the platform fetch.
function createClient({ getToken, getApiBase, fetchImpl } = {}) {
  // Build a generated client bound to the current origin + token. `root` is the
  // base path under the origin ('/api/gds' for the API, '' for same-origin static
  // assets like the release manifest). throwOnError:false → result-mode, which we
  // translate back into the GdsError contract callers expect.
  function gen(root) {
    return createGeneratedClient({
      baseUrl: apiBase(getApiBase ? getApiBase() : null) + root,
      token: getToken ? getToken() : null,
      throwOnError: false,
      fetch: fetchImpl || undefined,
    });
  }
  const gds = () => gen('/api/gds');

  // Unwrap a result-mode { status, ok, data } into the legacy contract: return the
  // parsed body on 2xx, throw GdsError(status, body) otherwise — byte-identical to
  // the old hand-written `call()` behavior (callers read err.status + err.body).
  async function unwrap(promise) {
    const res = await promise;
    if (!res.ok) throw new GdsError(res.status, res.data);
    return res.data;
  }

  return {
    // Generic escape hatch, kept for parity with the old surface. `path` is the full
    // path under the origin (e.g. '/api/gds/box/me'), so it routes through baseUrl:''.
    call: (method, path, body) => unwrap(gen('').request(method, path, body !== undefined ? { body } : {})),
    // identity
    logout: () => unwrap(gds().auth.postAuthLogout()),
    // pairing (public)
    pairStart: (deviceName, platform) =>
      unwrap(gds().auth.postAuthAppPairStart({ body: { device_name: deviceName, platform } })),
    pairPoll: (pollToken) =>
      unwrap(gds().auth.postAuthAppPairPoll({ body: { poll_token: pollToken } })),
    // box
    boxMe: () => unwrap(gds().box.getBoxMe()),
    boxEnsure: () => unwrap(gds().box.postBoxEnsure()),
    boxClose: () => unwrap(gds().box.postBoxClose()),
    // Leg 3: body-less keep-alive. No body → the server bumps last_activity_at only
    // and leaves claude_active untouched, so an idle box still reaps (cost posture).
    boxHeartbeat: () => unwrap(gds().box.postBoxHeartbeat()),
    boxTerminal: () => unwrap(gds().box.getBoxTerminal()),
    registerSshKey: (publicKey, label) =>
      unwrap(gds().box.postBoxSshKey({ body: { public_key: publicKey, label } })),
    // The VERIFY half of registration (task 1002509): a 201 is not proof the key is
    // on the account, so ssh-setup re-reads the list and looks for the fingerprint.
    listSshKeys: () => unwrap(gds().box.getBoxSshKey()),
    managedSettings: () => unwrap(gds().box.getBoxManagedSettings()),
    // task pick + confirm (BV1.R100 / goal 1000051). These ride the generic
    // request() escape hatch (like latestRelease) rather than a named generated
    // method, so the shipped binary keeps working regardless of whether the
    // vendored client has been regenerated for the new /box/scope route yet.
    claimableTasks: () => unwrap(gen('').request('GET', '/api/gds/tasks/claimable')),
    claimTask: (taskId) => unwrap(gen('').request('POST', '/api/gds/claims', { body: { task_id: taskId } })),
    boxScope: () => unwrap(gen('').request('GET', '/api/gds/box/scope')),
    // update check (public static asset at the origin root, not under /api/gds)
    latestRelease: () => unwrap(gen('').request('GET', '/downloads/devbox/latest.json')),
  };
}

module.exports = { createClient, GdsError };
