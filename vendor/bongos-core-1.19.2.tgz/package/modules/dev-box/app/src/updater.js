// devbox-app/src/updater.js — pure update-check logic (#924). No Electron, no
// network: deciding "is a newer release available?" and "which installer target
// do I need?" are pure functions so test/unit.mjs proves them without a GUI. The
// Electron wiring (poll the endpoint, download, launch the installer) is in main.js.

// Parse "X.Y.Z" → [X, Y, Z] numbers, or null for anything that isn't a clean
// three-part numeric version (the same shape devbox-downloads.js enforces on the
// server), so a malformed value can never be mistaken for an upgrade.
function parseVersion(v) {
  if (typeof v !== 'string') return null;
  const m = /^(\d+)\.(\d+)\.(\d+)$/.exec(v.trim());
  return m ? [Number(m[1]), Number(m[2]), Number(m[3])] : null;
}

// -1 if a<b, 0 if equal, 1 if a>b. An unparseable side sorts BELOW a parseable
// one (and two bad ones are equal), so a malformed version never reads as newer.
function compareVersions(a, b) {
  const pa = parseVersion(a);
  const pb = parseVersion(b);
  if (!pa || !pb) {
    if (!pa && !pb) return 0;
    return pa ? 1 : -1;
  }
  for (let i = 0; i < 3; i++) {
    if (pa[i] !== pb[i]) return pa[i] < pb[i] ? -1 : 1;
  }
  return 0;
}

// The load-bearing decision: the "update available" banner shows ONLY when the
// published release is STRICTLY newer than what's running. This replaces the
// naive `latest !== current` check, which would advertise a DOWNGRADE whenever
// the published config trails the installed app (the live state today: app 1.0.6
// vs config 1.0.5). Returns false on any unparseable version — never a
// false-positive.
function isUpdateAvailable(currentVersion, latestVersion) {
  if (!parseVersion(currentVersion) || !parseVersion(latestVersion)) return false;
  return compareVersions(latestVersion, currentVersion) > 0;
}

// Map the running (platform, arch) to a config/devbox-app.json asset target key.
// Mirrors the four built targets. Anything else (e.g. linux) → null = no
// in-app installer for this platform (the banner simply won't offer one).
function resolveTarget(platform, arch) {
  if (platform === 'darwin') return arch === 'arm64' ? 'mac-arm64' : 'mac-x64';
  if (platform === 'win32') return arch === 'arm64' ? 'win-arm64' : 'win-x64';
  return null;
}

// The exact banner copy the task specifies: "Update available — v1.0.6".
function updateBannerText(latestVersion) {
  return `Update available — v${latestVersion}`;
}

module.exports = { parseVersion, compareVersions, isUpdateAvailable, resolveTarget, updateBannerText };
