# dmgbuild settings for the OTB Dev Box install window (task 1235).
#
# WHY dmgbuild and not electron-builder's own DMG styling:
# electron-builder writes a .DS_Store whose background reference includes a
# modern security-scoped bookmark (`pBBk`). Finder on macOS >= Sonoma/Sequoia
# (verified white on 15.7.4) cannot resolve that bookmark, so it falls back to a
# solid white window — the embedded Greek-coast backdrop (task 912) is present
# but never drawn. dmgbuild writes an alias-only `.DS_Store` (no `pBBk`) that
# Finder DOES resolve, so the backdrop renders. The OS is not the problem; the
# bookmark electron-builder emits is. scripts/apply-dmg-backdrop.sh re-packages
# electron-builder's signed+notarized .app into a dmgbuild DMG using this file.
#
# Coordinates MUST match the icon-well centers drawn by gen-dmg-backdrop.py
# (LEFT 180,198 / RIGHT 480,198) and the 660x400 art — change one, change all.
# `app` and `bg` are passed in via dmgbuild -D defines.

import os.path

# -D app=<path to OTB Dev Box.app>  -D bg=<path to the hidpi backdrop tiff>
application = defines["app"]
backdrop = defines["bg"]
appname = os.path.basename(application)  # "OTB Dev Box.app"

# Contents of the disk image.
files = [application]
symlinks = {"Applications": "/Applications"}

# Window + icon layout — matched to the backdrop art's two marble wells.
background = backdrop
window_rect = ((150, 150), (660, 400))  # ((x, y), (w, h)); w/h match the 660x400 art
icon_size = 100
text_size = 12
icon_locations = {
    appname: (180, 198),       # the container (app) — left well
    "Applications": (480, 198),  # Applications — right well
}

# Compressed, read-only final image (same distribution format as before).
format = "UDZO"
