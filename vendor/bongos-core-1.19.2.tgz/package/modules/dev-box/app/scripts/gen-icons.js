// modules/dev-box/app/scripts/gen-icons.js — generate the app + tray icons from
// pixel grids (no binary sources to maintain; re-run after edits: npm run icons).
//
// The MOTIF is a bongo pair — a large drum and a small one, joined, the emblem
// the neutral pack already draws in its favicon and the DMG backdrop. It is
// brand-NEUTRAL geometry: it says "this is the Dev Box", not "this is one
// particular host's world". (It replaces a shipping-container + wave-footer motif
// that belonged to one instance's lore and shipped into every build.)
//
// The COLOURS are a build input, not baked in — the posture gen-brand.js holds for
// the app's strings and gen-dmg-backdrop.py holds for the install screen (ADR 0145).
// The palette comes from the resolved pack's `theme.ui.colors`, so ONE source tree
// renders the vanilla Cloud Bongos icons here and a host instance's own icons there.
//
// ONE source, resolved exactly as gen-brand.js resolves it (docs/branding-contract.md):
//     BONGOS_BRANDING_FILE -> config/branding.json -> config/branding.neutral.json
//
// Uses sharp from the REPO ROOT's node_modules (the art pipeline already
// depends on it) so this subproject keeps zero runtime deps of its own.
//
// Outputs (committed):
//   build-resources/icon.png             1024×1024 app icon (electron-builder
//                                        derives .icns/.ico from it)
//   assets/tray/mac-<state>Template.png  16px mono template (+@2x 32px)
//   assets/tray/win-<state>.png          32px colored
// States: off | on | busy | alert

const path = require('node:path');
const fs = require('node:fs');

// sharp is a repo-root devDep (the art pipeline already needs it), not a dep
// of this subproject — so resolve it from a few candidate roots rather than a
// single brittle relative path: normal resolution (NODE_PATH / a local
// install) first, then the repo root walked up from here. Fail with an
// actionable message instead of a raw MODULE_NOT_FOUND.
function resolveSharp() {
  const candidates = [
    'sharp',
    path.join(__dirname, '..', 'node_modules', 'sharp'),
    path.join(__dirname, '..', '..', 'node_modules', 'sharp'),
  ];
  for (const c of candidates) {
    try { return require(c); } catch { /* try the next root */ }
  }
  throw new Error(
    "gen-icons: cannot find 'sharp'. Run `npm install` at the repo root " +
    '(sharp is a root devDep shared with the art pipeline), then retry.'
  );
}
const sharp = resolveSharp();

const APP_DIR = path.resolve(__dirname, '..');             // modules/dev-box/app
const REPO_ROOT = path.resolve(APP_DIR, '..', '..', '..'); // repo root
const OUT_TRAY = path.join(APP_DIR, 'assets', 'tray');
const OUT_BUILD = path.join(APP_DIR, 'build-resources');

// theme.ui.colors key → the value used when a pack omits it. Every fallback here
// is the NEUTRAL pack's own colour, so a literal in this file is never a brand.
//
// Every role MUST be one gen-brand.js's buildThemeCss emits into the app's :root —
// that CSS block is the surface a host pack author actually fills. A role outside
// it has nothing prompting a host to define it, so its "fallback" would paint a
// Cloud Bongos colour into a fully-specified host build.
const COLOR_ROLES = {
  bgCard: '#ffffff', bgDeep: '#ffedd5', ink: '#2a1f17',
  rule: '#fdba74', ruleSoft: '#fed7aa',
  accent: '#f97316', accentDeep: '#ea580c', terracotta: '#fb7185',
};

// The pack, resolved exactly as gen-brand.js resolves it (env → instance → neutral).
//
// Deliberately NOT read from src/brand.generated.json, which also carries colours:
// that artifact is TRACKED holding the neutral values and nothing on the icon path
// regenerates it, so preferring it would let a stale checked-in file outrank the
// host's own pack. The pack decides, every time.
function readBranding() {
  const candidates = [
    process.env.BONGOS_BRANDING_FILE,
    path.join(REPO_ROOT, 'config', 'branding.json'),
    path.join(REPO_ROOT, 'config', 'branding.neutral.json'),
  ].filter(Boolean);
  for (const f of candidates) {
    try { return { file: f, branding: JSON.parse(fs.readFileSync(f, 'utf8')) }; } catch { /* try next */ }
  }
  throw new Error('gen-icons: no branding file found (looked for config/branding.json, config/branding.neutral.json)');
}

// A pack colour, or the neutral fallback when the pack omits it or writes junk —
// one malformed hex must not abort a build over an icon.
function palette(branding) {
  const colors = (((branding.theme || {}).ui) || {}).colors || {};
  const out = {};
  for (const [role, fallback] of Object.entries(COLOR_ROLES)) {
    const v = String(colors[role] || '').trim();
    out[role] = /^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$/.test(v) ? v : fallback;
  }
  return out;
}

// ---------------------------------------------------------------------------
// 16×16 tray grids. Legend: '.' transparent · '#' rim/shell · 'h' head · 'f' shell
// fill · 'm' state mark
//
// The bongo pair, three-quarter view: a large drum left, the small one joined at
// its right with its head sitting two rows lower. Two things make it read as DRUMS
// at 16px rather than boxes: the head is an oval that OVERHANGS the narrower shell
// (a flat top of the same size reads as a crate), and the profile is SQUAT — a
// bongo is about as wide as it is tall, so a tall shell reads as a jar.
//
// Every state keeps that silhouette and differs in SHAPE as well as colour,
// because the macOS template icons are monochrome: hollow (off) · filled (on) ·
// struck heads + beats overhead (busy) · a corner badge (alert).
// ---------------------------------------------------------------------------
const GRIDS = {
  off: [
    '................',
    '................',
    '................',
    '................',
    '..#######.......',
    '.#.......#......',
    '..#######.......',
    '...#...#.#####..',
    '...#...##.....#.',
    '...#...#.#####..',
    '...#...#.#...#..',
    '...#...#.#...#..',
    '...#####.#####..',
    '................',
    '................',
    '................',
  ],
  on: [
    '................',
    '................',
    '................',
    '................',
    '..#######.......',
    '.#hhhhhhh#......',
    '..#######.......',
    '...#fff#.#####..',
    '...#fff##hhhhh#.',
    '...#fff#.#####..',
    '...#fff#.#fff#..',
    '...#fff#.#fff#..',
    '...#####.#####..',
    '................',
    '................',
    '................',
  ],
  busy: [
    '................',
    '................',
    '....m...m...m...',
    '................',
    '..#######.......',
    '.#hhhhhhh#......',
    '..#######.......',
    '...#...#.#####..',
    '...#...##hhhhh#.',
    '...#...#.#####..',
    '...#...#.#...#..',
    '...#...#.#...#..',
    '...#####.#####..',
    '................',
    '................',
    '................',
  ],
  alert: [
    '............mmm.',
    '............mmm.',
    '............mmm.',
    '................',
    '..#######.......',
    '.#.......#......',
    '..#######.......',
    '...#...#.#####..',
    '...#...##.....#.',
    '...#...#.#####..',
    '...#...#.#...#..',
    '...#...#.#...#..',
    '...#####.#####..',
    '................',
    '................',
    '................',
  ],
};

function gridToSvg(grid, pal, cell = 1) {
  const h = grid.length;
  const w = grid[0].length;
  const rects = [];
  for (let y = 0; y < h; y++) {
    for (let x = 0; x < w; x++) {
      const color = pal[grid[y][x]];
      if (!color) continue;
      rects.push(`<rect x="${x * cell}" y="${y * cell}" width="${cell}" height="${cell}" fill="${color}"/>`);
    }
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${w * cell}" height="${h * cell}" shape-rendering="crispEdges">${rects.join('')}</svg>`;
}

async function renderPng(svg, size, file) {
  await sharp(Buffer.from(svg)).resize(size, size, { kernel: 'nearest' }).png().toFile(file);
  console.log('wrote', path.relative(process.cwd(), file));
}

// The app icon: the pack's field + border, the bongo pair, a beat line at the foot.
// Built as a 32×32 grid then nearest-upscaled to 1024 so it keeps the pixel look at
// every size electron-builder derives.
function buildAppGrid() {
  const rows = [];
  for (let y = 0; y < 32; y++) rows.push('.'.repeat(32).split(''));
  const put = (x, y, c) => { if (rows[y] && rows[y][x] !== undefined) rows[y][x] = c; };
  // Radii are nudged by half a cell so the boundary row/column lands ON the grid
  // instead of being clipped away — otherwise a 3-row oval renders as 1.
  const oval = (cx, cy, rx, ry, c) => {
    for (let y = cy - ry; y <= cy + ry; y++) for (let x = cx - rx; x <= cx + rx; x++) {
      const dx = (x - cx) / (rx + 0.5);
      const dy = (y - cy) / (ry + 0.5);
      if (dx * dx + dy * dy <= 1) put(x, y, c);
    }
  };

  for (let y = 2; y < 30; y++) for (let x = 2; x < 30; x++) put(x, y, 'p');
  for (let x = 2; x < 30; x++) { put(x, 2, 'b'); put(x, 29, 'b'); }
  for (let y = 2; y < 30; y++) { put(2, y, 'b'); put(29, y, 'b'); }

  // One drum: a shell hanging from the head's centre line, then the head oval
  // drawn over it — so the head overhangs the shell, the cue that reads as a drum.
  const drum = (cx, cy, rx, ry, shellRx, yBase, shell) => {
    for (let y = cy; y <= yBase; y++) for (let x = cx - shellRx; x <= cx + shellRx; x++) put(x, y, 'k');
    for (let y = cy; y < yBase; y++) for (let x = cx - shellRx + 1; x < cx + shellRx; x++) put(x, y, shell);
    oval(cx, cy, rx, ry, 'k');
    oval(cx, cy, rx - 1, ry - 1, 'h');
  };
  drum(11, 12, 7, 3, 5, 24, 't');  // the large drum
  drum(22, 15, 5, 3, 3, 24, 's');  // the small one, drawn second so it sits in front

  // The beat: four even strokes across the foot — rhythm without a world-specific
  // motif, echoing the DMG backdrop's beat line. Spanning the full width (rather
  // than sitting under each shell) keeps them reading as a strip, not as legs.
  for (let x = 5; x <= 23; x += 6) for (let dx = 0; dx < 3; dx++) { put(x + dx, 26, 'd'); put(x + dx, 27, 'd'); }

  return rows.map((r) => r.join(''));
}

async function main() {
  fs.mkdirSync(OUT_TRAY, { recursive: true });
  fs.mkdirSync(OUT_BUILD, { recursive: true });

  const { file, branding } = readBranding();
  const p = palette(branding);

  // macOS template: pure black + alpha, for EVERY state. This is an OS
  // requirement, not a brand choice — the system recolours a *Template.png itself
  // (menu-bar light/dark, inverted when selected), and any colour in the source
  // is discarded. Branding one of these would be a bug, not a feature.
  const MAC = { '#': '#000000', f: '#000000', h: '#000000', m: '#000000' };
  // Windows: state via colour on a taskbar we don't control — it may be light OR
  // dark, so every state outlines in the pack's DEEP accent, the one tone that
  // holds contrast against both. The pale tints only ever appear as fill inside
  // that outline, where the shape is already legible.
  const WIN = {
    off: { '#': p.accentDeep },
    on: { '#': p.accentDeep, f: p.accent, h: p.bgDeep },
    busy: { '#': p.accentDeep, h: p.accent, m: p.accent },
    alert: { '#': p.accentDeep, m: p.terracotta },
  };

  for (const state of Object.keys(GRIDS)) {
    const macSvg = gridToSvg(GRIDS[state], MAC);
    await renderPng(macSvg, 16, path.join(OUT_TRAY, `mac-${state}Template.png`));
    await renderPng(macSvg, 32, path.join(OUT_TRAY, `mac-${state}Template@2x.png`));
    await renderPng(gridToSvg(GRIDS[state], WIN[state]), 32, path.join(OUT_TRAY, `win-${state}.png`));
  }

  const APP_PALETTE = {
    p: p.bgCard, b: p.rule, k: p.ink,
    t: p.accent, s: p.terracotta, h: p.ruleSoft, d: p.accentDeep,
  };
  await renderPng(gridToSvg(buildAppGrid(), APP_PALETTE), 1024, path.join(OUT_BUILD, 'icon.png'));
  console.log(`gen-icons: palette ← ${path.relative(REPO_ROOT, file)}`);
}

main().catch((e) => { console.error(e); process.exit(1); });
