// devbox-app/scripts/vendor-client.js — vendor the generated CJS API client
// into src/vendor/ so it ships INSIDE the packaged asar.
//
// The devbox app is a self-contained, zero-dependency subproject (ADR 0045): it
// is never `npm install`ed and electron-builder packages `src/**` only, so it
// cannot require() the repo's clients/bongos-client/ at runtime. This copies the
// committed CJS build in verbatim (byte-for-byte) so gds-client.js can require
// './vendor/bongos-client.cjs'. Vendoring a generated FILE (not an npm dep) keeps
// the subproject dependency-free. The main repo's api_client test asserts this
// copy stays byte-identical to the canonical build, so drift fails CI.
//
// Run: npm run vendor  (also invoked before `start`, `test`, and `dist:*`).

const fs = require('node:fs');
const path = require('node:path');

const SRC = path.resolve(__dirname, '../../../../clients/bongos-client/index.cjs');
const DEST = path.resolve(__dirname, '../src/vendor/bongos-client.cjs');

const bytes = fs.readFileSync(SRC);
fs.mkdirSync(path.dirname(DEST), { recursive: true });
fs.writeFileSync(DEST, bytes);
console.log(`vendor-client: ${path.relative(process.cwd(), DEST)} (${bytes.length} bytes) ← clients/bongos-client/index.cjs`);
