#!/usr/bin/env python3
"""Draw the DMG install-window backdrop from the INSTANCE BRANDING (task 912, 1002372).

The Mac .dmg install window shows two icons — the app on the left and an
Applications-folder alias on the right — and the user drags one onto the other.
This draws the Finder-window BACKDROP behind that gesture.

Branding is a BUILD INPUT, not baked in — the same posture gen-brand.js already
holds for the app's strings (ADR 0145). The palette comes from the pack's
`theme.ui.colors`, the headline names the product the build actually ships, the
subhead is the pack's tagline, and the type is the pack's own font stack. So ONE
source tree renders the vanilla Cloud Bongos sunrise here and a host instance's
palette + voice there: no hex, motif, or sentence belongs to a single brand.

ONE source, resolved exactly as gen-brand.js resolves it (docs/branding-contract.md):
    BONGOS_BRANDING_FILE → config/branding.json → config/branding.neutral.json
Palette, type, product name and tagline all come from that file, so a render can
never mix one pack's colours with another's words.

A pack that wants different words states them outright as `copy.dmgHeadline` /
`copy.dmgSubhead`; otherwise both lines are derived, so a new instance needs no
extra config to get a correct install screen.

Draws DIRECTLY with Pillow (no SVG renderer needed in CI/headless) and
supersamples 2x then LANCZOS-downscales so text + edges read crisply at Retina.
Outputs:
    build-resources/dmg-background.png      660x400  (@1x)
    build-resources/dmg-background@2x.png  1320x800  (@2x; electron-builder auto-picks)

The icon SLOTS are left clear — electron-builder / dmgbuild place the real app +
Applications icons over them at the coords mirrored in scripts/dmgbuild-settings.py;
this art only draws the guidance AROUND them (wells, the beat line, copy).

Pillow is an ad-hoc dependency: the repo declares no Python manifest (the sibling
scripts/apply-dmg-backdrop.sh installs its own `dmgbuild` the same way), so run
this from a throwaway venv with `pip install Pillow`.

Run:  python3 modules/dev-box/app/scripts/gen-dmg-backdrop.py
Re-run after any branding/layout/copy change; commit the two PNGs. Text renders in
the first face of the pack's stack that is INSTALLED on the rendering machine, so
a re-render on a different OS may substitute a different fallback face.
"""
from __future__ import annotations  # `X | None` hints must not run on macOS's system python 3.9

import json
import os
from dataclasses import dataclass
from typing import Union

from PIL import Image, ImageDraw, ImageFont

RGB = tuple[int, int, int]
Face = Union[ImageFont.FreeTypeFont, ImageFont.ImageFont]  # a truetype face, or Pillow's built-in

APP_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))  # modules/dev-box/app
REPO_ROOT = os.path.abspath(os.path.join(APP_DIR, "..", "..", ".."))

W, H = 660, 400            # the DMG window size (must match electron-builder.yml dmg.window)
SS = 2                     # supersample factor for crisp anti-aliased output
LEFT = (180, 198)          # app-icon slot center (matches dmg.contents[0])
RIGHT = (480, 198)         # Applications slot center (matches dmg.contents[1])
ICON = 100                 # dmg.iconSize

# theme.ui.colors keys → the roles this art draws, with the neutral pack's values
# as fallbacks so a partial instance pack still renders something coherent.
# Every role here MUST be one the app's own brand surface emits (gen-brand.js's
# buildThemeCss) — a role outside it has nothing prompting a host pack to define
# it, so its "fallback" would paint a Cloud Bongos colour into a fully-specified
# host build. That is exactly what `sea` did to the Applications-well rim.
COLOR_ROLES = {
    "bg": "#fff7ed", "bgDeep": "#ffedd5", "bgCard": "#ffffff",
    "ink": "#2a1f17", "inkSoft": "#6b5d52", "ruleSoft": "#fed7aa",
    "accent": "#f97316", "accentDeep": "#ea580c", "terracotta": "#fb7185",
}

FONT_DIRS = (
    "/System/Library/Fonts/Supplemental", "/Library/Fonts", "/System/Library/Fonts",
    os.path.join(os.environ.get("WINDIR", "C:/Windows"), "Fonts"),
    "/usr/share/fonts/truetype/dejavu",
)
# Tried only when none of the pack's own families is installed — a web-font stack
# ("Baloo 2", "Quicksand") usually isn't present on the machine doing the render.
GENERIC_BOLD = ("Arial Bold.ttf", "Helvetica.ttc", "segoeuib.ttf", "arialbd.ttf", "DejaVuSans-Bold.ttf")
GENERIC_REGULAR = ("Arial.ttf", "Helvetica.ttc", "segoeui.ttf", "arial.ttf", "DejaVuSans.ttf")
# CSS keywords name no file, so they fall through to the generic faces above.
CSS_GENERIC_FAMILIES = {"system-ui", "-apple-system", "sans-serif", "serif", "monospace", "ui-sans-serif"}


@dataclass(frozen=True)
class Art:
    """Everything the render pulls from the instance pack — resolved once, then drawn."""
    palette: dict[str, RGB]
    headline: str
    subhead: str
    display_stack: str
    body_stack: str


def read_json(path: str) -> dict | None:
    try:
        with open(path, encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def read_branding() -> dict:
    """The pack, resolved exactly as gen-brand.js resolves it (env → instance → neutral)."""
    for path in (os.environ.get("BONGOS_BRANDING_FILE"),
                 os.path.join(REPO_ROOT, "config", "branding.json"),
                 os.path.join(REPO_ROOT, "config", "branding.neutral.json")):
        pack = read_json(path) if path else None
        if pack is not None:
            return pack
    raise SystemExit("gen-dmg-backdrop: no branding pack found (is config/branding.neutral.json missing?)")


def brand_strings(branding: dict) -> dict:
    """Product name + tagline, derived from the resolved pack exactly as gen-brand.js's
    buildBrand derives them (`<worldName> Dev Box`, `copy.tagline`).

    Deliberately NOT read out of gen-brand.js's src/brand.generated.json, which carries
    the same two fields: that artifact is COMMITTED holding the neutral values and
    nothing on this path regenerates it, so preferring it would let a stale checked-in
    file outrank the host's own pack — the render would draw the host palette and type
    under the neutral product's name. The pack decides, every time."""
    identity = branding.get("identity") or {}
    world = identity.get("worldName") or identity.get("productName") or "Cloud Bongos"
    return {
        "product": f"{world} Dev Box",
        "tagline": (branding.get("copy") or {}).get("tagline") or "",
    }


def copy_lines(branding: dict, brand: dict) -> tuple[str, str]:
    """Headline + subhead. Derived from the instance's own name and tagline; a pack
    whose voice needs different words states them as copy.dmgHeadline/dmgSubhead."""
    copy = branding.get("copy") or {}
    headline = copy.get("dmgHeadline") or f"Drag {brand['product']} to Applications"
    subhead = copy.get("dmgSubhead")
    return headline, brand["tagline"] if subhead is None else subhead


def hexrgb(value: str | None, fallback: str) -> RGB:
    """A pack colour, or the neutral fallback when the pack omits it or writes junk —
    one malformed hex must not abort a build over a decorative backdrop."""
    for candidate in (value, fallback):
        raw = str(candidate or "").lstrip("#")
        if len(raw) == 3:
            raw = "".join(c * 2 for c in raw)
        if len(raw) == 6:
            try:
                return (int(raw[0:2], 16), int(raw[2:4], 16), int(raw[4:6], 16))
            except ValueError:
                continue
    return (0, 0, 0)


def palette(branding: dict) -> dict[str, RGB]:
    ui = (branding.get("theme") or {}).get("ui") or {}
    colors = ui.get("colors") or {}
    return {role: hexrgb(colors.get(role), fallback) for role, fallback in COLOR_ROLES.items()}


def font_files(stack: str, bold: bool) -> list[str]:
    """A CSS family stack → font FILENAMES to try, in the pack's own preference order.
    Covers both the macOS ("Georgia Bold.ttf") and Windows ("georgiab.ttf") naming."""
    names: list[str] = []
    for raw in str(stack or "").split(","):
        family = raw.strip().strip("\"'")
        if not family or family in CSS_GENERIC_FAMILIES:
            continue
        flat = family.replace(" ", "").lower()
        if bold:
            names += [f"{family} Bold.ttf", f"{flat}b.ttf", f"{flat}bd.ttf"]
        names += [f"{family}.ttf", f"{flat}.ttf"]
    return names + list(GENERIC_BOLD if bold else GENERIC_REGULAR)


def font(stack: str, size: int, bold: bool = False) -> Face:
    for name in font_files(stack, bold):
        for directory in FONT_DIRS:
            path = os.path.join(directory, name)
            if os.path.exists(path):
                return ImageFont.truetype(path, size)
    return ImageFont.load_default(size)


def lerp(a: RGB, b: RGB, t: float) -> RGB:
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def vgradient(draw: ImageDraw.ImageDraw, x0: int, y0: int, x1: int, y1: int, c_top: RGB, c_bot: RGB) -> None:
    h = max(1, y1 - y0)
    for y in range(y0, y1):
        draw.line([(x0, y), (x1, y)], fill=lerp(c_top, c_bot, (y - y0) / h))


def text_width(draw: ImageDraw.ImageDraw, text: str, fnt: Face) -> float:
    left, _, right, _ = draw.textbbox((0, 0), text, font=fnt)
    return right - left


def centered(draw: ImageDraw.ImageDraw, cx: float, y: float, text: str,
             fnt: Face, fill: RGB) -> None:
    draw.text((cx - text_width(draw, text, fnt) / 2, y), text, font=fnt, fill=fill)


def fitted_font(draw: ImageDraw.ImageDraw, text: str, stack: str, size: int, max_w: float) -> Face:
    """Shrink the headline until it fits — an instance's product name is arbitrary
    length, and a name that runs off the 660px art would ship a broken installer."""
    fnt = font(stack, size, bold=True)
    while size > 12 and text_width(draw, text, fnt) > max_w:
        size -= 1
        fnt = font(stack, size, bold=True)
    return fnt


def cloud_band(draw: ImageDraw.ImageDraw, base_y: float, scale: int, fill: RGB) -> None:
    # A soft cloud shelf across the foot: a flat fill topped by overlapping discs,
    # so the band reads as one puffy silhouette and grounds the two icon wells.
    y = base_y * scale
    draw.rectangle([0, y, W * scale, H * scale], fill=fill)
    x = -12.0 * scale
    i = 0
    while x < (W + 40) * scale:
        r = (11 + 5 * ((i * 3) % 4)) * scale
        draw.ellipse([x - r, y - r, x + r, y + r], fill=fill)
        x += r * 1.15
        i += 1


def bongo_mark(draw: ImageDraw.ImageDraw, center: tuple[float, float], scale: int,
               big: RGB, small: RGB, head: RGB) -> None:
    # The mark: a drum pair seen from above, mirroring the neutral pack's favicon
    # geometry but coloured FROM the resolved pack — so it recolours per instance
    # rather than stamping one brand's emblem into every build.
    cx, cy = center[0] * scale, center[1] * scale
    for dx, radius, body in ((-8.0, 13.0, big), (9.0, 10.0, small)):
        x = cx + dx * scale
        r = radius * scale
        draw.ellipse([x - r, cy - r, x + r, cy + r], fill=body)
        inner = r * 0.44
        draw.ellipse([x - inner, cy - inner, x + inner, cy + inner], fill=head)


def well(draw: ImageDraw.ImageDraw, center: tuple[int, int], scale: int, face: RGB, rim: RGB) -> None:
    # A soft raised disc the icon sits on — a filled card with concentric rings
    # fading into it, so the placed icon reads as resting ON the surface.
    cx, cy = center[0] * scale, center[1] * scale
    rad = (ICON / 2 + 18) * scale
    draw.ellipse([cx - rad, cy - rad, cx + rad, cy + rad], fill=face)
    for i in range(6):
        r = rad - i * 1.6 * scale
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=lerp(rim, face, i / 5),
                     width=max(1, int(1.5 * scale)))


def beat_line(draw: ImageDraw.ImageDraw, p0: tuple[float, float], p1: tuple[float, float],
              scale: int, dot: RGB, tip: RGB) -> None:
    # The drag guidance: beats swelling toward a chevron. Direction without a
    # world-specific motif — it reads the same whatever the instance is building.
    x0, y0 = p0[0] * scale, p0[1] * scale
    x1, y1 = p1[0] * scale, p1[1] * scale
    beats = 6
    for i in range(beats):
        t = i / (beats - 1)
        x, y = x0 + (x1 - x0) * t, y0 + (y1 - y0) * t
        r = (2.0 + 2.4 * t) * scale
        draw.ellipse([x - r, y - r, x + r, y + r], fill=dot)
    a = 12 * scale
    draw.polygon([(x1 + a * 1.5, y1), (x1 + a * 0.2, y1 - a * 0.8), (x1 + a * 0.2, y1 + a * 0.8)], fill=tip)


def render(scale: int, art: Art) -> Image.Image:
    p = art.palette
    img = Image.new("RGB", (W * scale, H * scale), p["bg"])
    d = ImageDraw.Draw(img)
    # the pack's field: its deep tint at the top easing into its base tone
    vgradient(d, 0, 0, W * scale, H * scale, p["bgDeep"], p["bg"])
    cloud_band(d, 344, scale, p["bgCard"])
    bongo_mark(d, (W / 2, 34), scale, p["accent"], p["terracotta"], p["bg"])
    centered(d, W * scale / 2, int(56 * scale), art.headline,
             fitted_font(d, art.headline, art.display_stack, int(25 * scale), (W - 72) * scale), p["ink"])
    if art.subhead:
        centered(d, W * scale / 2, int(94 * scale), art.subhead,
                 font(art.body_stack, int(13 * scale)), p["inkSoft"])
    # Wells + guidance. The destination rim takes the pack's accent — the same tone
    # the beats arrive in — so the drop target is distinguishable from the source's
    # soft rule at a glance.
    well(d, LEFT, scale, p["bgCard"], p["ruleSoft"])
    well(d, RIGHT, scale, p["bgCard"], p["accent"])
    beat_line(d, (LEFT[0] + ICON / 2 + 24, LEFT[1]), (RIGHT[0] - ICON / 2 - 36, RIGHT[1]),
              scale, p["accent"], p["accentDeep"])
    # NB: no under-slot labels — Finder renders each icon's own name beneath it,
    # so drawing our own would double them.
    return img


def main() -> None:
    branding = read_branding()
    brand = brand_strings(branding)
    headline, subhead = copy_lines(branding, brand)
    fonts = ((branding.get("theme") or {}).get("ui") or {}).get("fonts") or {}
    art = Art(
        palette=palette(branding),
        headline=headline,
        subhead=subhead,
        display_stack=fonts.get("display") or "",
        body_stack=fonts.get("body") or "",
    )

    out_dir = os.path.join(APP_DIR, "build-resources")
    # @1x: render at SS then downscale for anti-aliasing.
    render(SS, art).resize((W, H), Image.LANCZOS).save(os.path.join(out_dir, "dmg-background.png"))
    # @2x: native double-size canvas (so it is genuinely 2x detail), supersampled.
    render(SS * 2, art).resize((W * 2, H * 2), Image.LANCZOS).save(os.path.join(out_dir, "dmg-background@2x.png"))
    print(f'gen-dmg-backdrop: "{headline}" / "{subhead}"')
    print(f"  wrote {out_dir}/dmg-background.png ({W}x{H}) + dmg-background@2x.png ({W * 2}x{H * 2})")


if __name__ == "__main__":
    main()
