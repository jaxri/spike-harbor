#!/usr/bin/env bash
# Re-package electron-builder's mac DMGs so the install-window backdrop renders
# (task 1235). See scripts/dmgbuild-settings.py for the root cause: Finder on
# macOS >= Sonoma can't resolve the `pBBk` bookmark electron-builder writes, so
# its DMG shows a white window; dmgbuild's alias-only .DS_Store resolves and the
# backdrop (task 912) draws.
#
# For each dist/<ProductSlug>-<ver>-<arch>.dmg this:
#   1. mounts it read-only and copies the .app out with `ditto` (preserves the
#      Developer ID signature + the stapled notarization ticket verbatim),
#   2. rebuilds the DMG with dmgbuild + the on-brand backdrop,
#   3. overwrites the original in place.
# The .app is byte-identical, so it stays notarized; the DMG is an unsigned
# carrier either way (verified: the published DMGs were never DMG-signed, only
# the app inside is). dmgbuild needs no GUI/Finder, so this is CI-safe (headless).
#
# Run from the devbox-app/ directory:  bash scripts/apply-dmg-backdrop.sh [distDir]
set -euo pipefail

DIST="${1:-dist}"
RES="build-resources"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

if [ ! -f "$RES/dmg-background.png" ] || [ ! -f "$RES/dmg-background@2x.png" ]; then
  echo "ERROR: backdrop art missing in $RES (run scripts/gen-dmg-backdrop.py)" >&2
  exit 1
fi

# Crisp on Retina: fold the 1x + 2x PNGs into a single multi-rep hidpi TIFF.
tiffutil -cathidpicheck "$RES/dmg-background.png" "$RES/dmg-background@2x.png" \
  -out "$WORK/backdrop.tiff" >/dev/null

# Isolated, headless dmgbuild (writes .DS_Store directly; no Finder dependency).
python3 -m venv "$WORK/venv"
"$WORK/venv/bin/pip" install --quiet --disable-pip-version-check dmgbuild

# Brand comes from the generated brand (ADR 0145) so this re-packages whatever
# the branding-driven build produced — Cloud-Bongos-Dev-Box-*.dmg here, any
# instance's slug elsewhere — never a hardcoded product name.
SLUG="$(python3 -c 'import json;print(json.load(open("src/brand.generated.json"))["PRODUCT_SLUG"])')"
PNAME="$(python3 -c 'import json;print(json.load(open("src/brand.generated.json"))["PRODUCT_NAME"])')"

shopt -s nullglob
count=0
for DMG in "$DIST"/"$SLUG"-*.dmg; do
  base="$(basename "$DMG" .dmg)"             # e.g. Cloud-Bongos-Dev-Box-1.0.10-arm64
  suffix="${base#"$SLUG"-}"                  # e.g. 1.0.10-arm64
  volname="$PNAME $suffix"                   # e.g. Cloud Bongos Dev Box 1.0.10-arm64

  mnt="$WORK/mnt-$suffix"
  mkdir -p "$mnt"
  hdiutil attach "$DMG" -nobrowse -readonly -mountpoint "$mnt" -owners off >/dev/null

  app="$(/bin/ls -d "$mnt"/*.app 2>/dev/null | head -1)"
  if [ -z "$app" ]; then
    echo "ERROR: no .app inside $DMG" >&2
    hdiutil detach "$mnt" >/dev/null 2>&1 || true
    exit 1
  fi
  appname="$(basename "$app")"
  ditto "$app" "$WORK/$appname"
  hdiutil detach "$mnt" >/dev/null

  out="$WORK/out-$suffix.dmg"
  "$WORK/venv/bin/dmgbuild" \
    -s scripts/dmgbuild-settings.py \
    -D app="$WORK/$appname" \
    -D bg="$WORK/backdrop.tiff" \
    "$volname" "$out" >/dev/null

  mv -f "$out" "$DMG"
  rm -rf "$WORK/$appname"
  echo "  backdrop applied: $(basename "$DMG")  (volume \"$volname\")"
  count=$((count + 1))
done

if [ "$count" -eq 0 ]; then
  echo "ERROR: no ${SLUG}-*.dmg found in $DIST" >&2
  exit 1
fi
echo "Re-packaged $count DMG(s) with the install-window backdrop."
