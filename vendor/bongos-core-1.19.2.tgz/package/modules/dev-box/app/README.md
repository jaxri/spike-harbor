# OTB Dev Box — the desktop switch for a builder's hosted box

A menu-bar (macOS) / system-tray (Windows) app that turns a builder's hosted
dev box on and off with one switch. Built for the newcomer who should never
see a terminal: sign in with browser clicks (app pairing, ADR 0045), flip the
switch, and connect from Claude Desktop or the browser terminal.

What it does beyond the switch — each fixing a failure observed in the
2026-06-10 onboarding sessions that killed the old `curl | bash` flow:

- **Pairing sign-in** — opens the builders' hall, one Approve click, token
  delivered over the app's own secret channel (`/api/gds/auth/app-pair/*`).
  The session is written to `~/.config/otb/gds-session.json`, the same file
  the `/builder-*` CLI uses — pairing the app signs in the CLI too.
- **SSH key done right** — generates `~/.ssh/otb_builder` (ed25519) with real
  600 perms (icacls ACL on Windows) and registers it via `POST /box/ssh-key`.
- **known_hosts kept fresh** — Claude Desktop's embedded ssh2 reads ONLY
  `~/.ssh/known_hosts`, and host keys change on every re-provision; the app
  re-scans and replaces entries each time the box turns active.
- **Claude Desktop connection file** — installs the managed-settings file to
  the system path with a native elevation prompt (osascript / UAC), the step
  the agent-driven flow could never finish.
- **Native notifications** — box ready, rested while idle.
- **No heartbeats** — the app never sends `claude_active`; the droplet's idle
  sweep stays authoritative so an unused box still reclaims itself (~10 min).

## Layout

- `src/main.js` — Electron main: tray, window, IPC, wiring.
- `src/brand.js` — every brand string (ADR 0004: the civ name lives here only).
- `src/{pairing,box-controller,gds-client,session-store,ssh-setup,updater}.js` — the
  logic, Electron-free and unit-tested in `test/unit.mjs`.
- `src/updater.js` — in-app update check (#924): semver compare + platform→target
  resolution. `main.js` polls `GET /downloads/devbox/version` on open + every 12h
  and, when the published release is strictly newer, shows the Update banner; the
  Update button downloads the installer and hands it to the OS (browser-download
  fallback on any error). **Bumping `config/devbox-app.json` version is what makes
  the banner appear in the field** — see [`docs/recipes/devbox-app-release.md`](../docs/recipes/devbox-app-release.md).
- `renderer/` — the panel UI (sandboxed, contextIsolated; preload exposes
  named verbs only).
- `scripts/gen-icons.js` — regenerates all icons from pixel grids (`npm run
  icons`; borrows `sharp` from the repo root's node_modules).

## Develop

```
cd devbox-app
npm install
npm test          # hermetic unit tests, no Electron needed
npm start         # run against prod (or OTB_DEVBOX_API_BASE=http://… npm start)
```

Dev/test env hooks: `OTB_DEVBOX_API_BASE` (point at a stub/staging GDS),
`OTB_DEVBOX_NO_ELEVATE=1` (skip the managed-settings elevation prompt),
`OTB_DEVBOX_SCREENSHOT_DIR` (write a PNG of the panel on every state change —
how CI/verification captures proof).

## Build & release

```
npm run dist:mac   # dmg, arm64 + x64 (unsigned → ad-hoc)
npm run dist:win   # NSIS one-click installer, x64 + arm64
```

CI builds both on every push that touches `devbox-app/**`
(`.github/workflows/build-devbox-app.yml`) and uploads them as artifacts.
Publishing = attach the artifacts to a release on the PUBLIC releases repo
named in `config/devbox-app.json`, then bump that config and ship — the
branded `/downloads/devbox/*` redirects follow the config. Full recipe:
`docs/recipes/devbox-app-release.md`.

This subproject is self-contained on purpose: its `package.json` never feeds
the droplet's `npm ci`, and nothing under `devbox-app/` runs server-side.
