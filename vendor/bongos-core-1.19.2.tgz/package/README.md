# Cloud Bongos

**Cloud Bongos is an AI-first software build platform.** A human owner sets scope, direction, and the hard gates (rank, approval, deploy); AI agents claim tasks and do the day-to-day building — code, docs, migrations, reviews. This repository is the **portable core**: the methodology, the Game Development System (GDS) that tracks all work, the platform engine, and a neutral branding template each instance fills in.

Cloud Bongos is free software under the **GNU AGPL-3.0** (see [`LICENSE`](./LICENSE)), with non-profit, AI-first governance ([`GOVERNANCE.md`](./GOVERNANCE.md)).

> **Provenance.** This core was extracted with fresh history from **Example** — the reference instance, built by Hermeslines, and the first project to run on Cloud Bongos. Example now consumes this core as a pinned dependency, the same shape as any other instance. The extraction is a redacted subtree (no instance secrets, IPs, or private identity); the exact pin — `core_version`, `source_commit`, `tree_sha256` — is recorded in [`.cloudbongos-core.json`](./.cloudbongos-core.json).

The durable framing for AI agents — methodology, working rules, session protocol, architecture — lives in [`CLAUDE.md`](./CLAUDE.md). Read it before editing code.

## What's in here

- **The GDS** (`src/`, `modules/`, `scripts/gds/`) — the build state machine: tasks, claims, versions, goals, dependencies, the claim→ship→grade→credit lifecycle, and the `/builder-*` CLI.
- **Platform modules** (`modules/`) — lifecycle, grading, economy, memory, onboarding, ideas, sessions, autonomy, security, the builders' hall + status dashboard, dev-box, and Discord integration. Each is configurable (and most are toggleable) per instance.
- **Neutral branding template** (`config/*.neutral.json`, `docs/project-context.template.md`) — the identity scaffold a new instance fills in ([`docs/branding-contract.md`](./docs/branding-contract.md)). The vanilla pack in `config/branding.neutral.json` is the identity Cloud Bongos itself runs on.
- **Methodology + decisions** (`CLAUDE.md`, `docs/adr/`, `docs/recipes/`, `.claude/skills/`).

> **This is the core, not a ready-to-run instance.** An instance layers its own content, branding, and product modules on top of a pinned core (that is the whole point of the two-repo model). `server.js` and some entrypoints still reference the reference instance's product layer; standing the core up standalone — a clean vanilla boot — is deliberately the job of the consumer path, proven first by the next instance to install it.

## New builder? Start here

### Before you start (prerequisites)

You'll need three things on your machine first:

- **Git** — the tool that copies the code down. Check with `git --version`; install from [git-scm.com](https://git-scm.com/downloads) if it's missing.
- **Claude Code** — your pair-programmer for every session. Download the desktop app at [claude.com/download](https://claude.com/download) (Mac and Windows).
- **A GitHub account with access to this repo.** While the repo is private, the owner must invite you first; accept the invitation before cloning. (The bootstrap below also checks for Node ≥ 22 and Python ≥ 3.10, and prints the install command if either is missing.)

### Step 0 — get the project onto your machine

Clone the repo, then `cd` into it. Everything below runs from inside that folder.

### Step 1 — bootstrap

One command bootstraps a fresh clone end-to-end — toolchain checks, JS deps, local env file, and a GDS session via GitHub:

```sh
# macOS / Linux:
./scripts/setup-builder.sh
# Windows — or any OS (node is the one guaranteed runtime):
node scripts/setup-builder.js
```

It checks Node ≥ 22 and Python ≥ 3.10 (prints the install command if either is missing), runs `npm ci`, copies `.env.local.example` to `.env.local`, and hands off to `node scripts/gds/setup.js` to authenticate against the GDS via the GitHub Device Flow. The script is idempotent: re-running on an already-set-up checkout reports "already done" rather than clobbering.

When it finishes, open Claude Code and run `/builder-start` to see what tasks are claimable.

## Secrets scanning

We keep secrets (`.env` files, API keys, private keys) out of the repo with two layers. Both are **instance topology** — the git hook (`.husky/`) and CI (`.github/`) are provided when you stand up an instance and are not shipped in the portable core; the pattern below is the recommended posture:

- **Pre-commit hook** (`.husky/pre-commit`) — scans your *staged* changes before each commit and aborts if it finds a secret. On an instance that ships `.husky/`, activate it **once per clone**:

  ```sh
  node scripts/gds/install-git-hooks.js
  ```

  Prefer that over setting `core.hooksPath` by hand: it no-ops cleanly on a checkout without a `.husky/` (the portable core), whereas pointing `core.hooksPath` at a directory that isn't there leaves git with a dangling hooks path and no gate. `node scripts/gds/doctor.js` reports which case you're in.

  It always runs a built-in guard (blocks `.env`, `*.pem`, credential files, obvious key patterns). If [TruffleHog](https://github.com/trufflesecurity/trufflehog) is installed (`brew install trufflehog` on macOS; `scoop install trufflehog` / `choco install trufflehog` or the GitHub release on Windows) it also runs a deep scan; if not, it warns and lets the commit through — CI is the real gate.

  > **Windows:** git runs the `.husky/pre-commit` hook through the Git-Bash `sh` bundled with Git for Windows, so the hook works if you installed Git for Windows (the usual case). If you don't have a `sh` available, the local hook silently no-ops — CI's full-history TruffleHog scan is then your only gate (and it always runs regardless of platform).

- **CI scan** (`.github/workflows/secrets-scan.yml`) — every PR to `main` runs TruffleHog over the **full git history**. This must pass before merge.

### If a commit is blocked, here's how to investigate

1. **Read the output.** The hook prints the offending file(s) and why.
2. **Is it a real secret?** Then it must never be committed. Remove it from the commit (`git restore --staged <file>`), and move the value out of the repo — local secrets go in `.env.local` (gitignored; run `/builder-setup`); production secrets live in your instance's secret store, never in the tree. If it was *already committed in an earlier commit*, the history scan will keep failing until the history is scrubbed — flag this to the owner, since rewriting shared history needs care.
3. **Is it a false positive?** (e.g. an example key in docs, a test fixture, a Stripe `pk_test_` publishable key.) Add a path regex — one per line — to [`.husky/secrets-allowlist.txt`](./.husky/secrets-allowlist.txt). Both the hook and CI read that allowlist. Keep entries narrow and only add them after confirming the match is genuinely not a secret.
4. **Genuine emergency commit** (you're sure it's clean and need to move now): `git commit --no-verify` skips the local hook — but CI will still scan the PR, so this only defers the check, it doesn't bypass it.

## If your CLI starts 401'ing

GDS CLI calls (`node scripts/gds/start.js`, `claim.js`, `ship.js`, etc.) authenticate against your instance's GDS host using a session token stored under `~/.config/<configDir>/gds-session.json` (the neutral core uses `cloudbongos`; an instance may pin its own). Sessions carry a rolling TTL — every authenticated request resets it, so an active session never silently expires — but after a long idle, a token revocation, or an auth-changing deploy, the local token can stop working.

`apiCall` in `scripts/gds/cli-lib.js` detects HTTP 401 and exits with a clear recovery message rather than letting the failure cascade. When you see it:

1. **Re-auth via Device Flow:**

   ```sh
   node scripts/gds/setup.js --force
   ```

   It pre-flights `GET /api/gds/me` against your existing session first. If the token is valid, it tells you who you're authenticated as and exits. If the token is dead (401), it falls through to the Device Flow automatically — browser opens to `github.com/login/device`; paste the printed code, authorize as the right GitHub account, you're back.

2. **If something feels off and you're not sure what,** run the doctor:

   ```sh
   node scripts/gds/doctor.js
   ```

   It checks session validity (`/me` returns 200, identity + rank), git plumbing (`core.hooksPath` resolves), repo state (on a branch, working-tree status), and environment files. Green/red checklist, no arguments. Exits 0 if every check passes, 1 if any red.
